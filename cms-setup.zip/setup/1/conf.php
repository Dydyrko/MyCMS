<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};
$Conf=array(
'TITLE'=>'test',
'Langs'=>array('uk','ru','en'),
'adminLang'=>'',
'HOST'=>'localhost',
'NAME_BD'=>'test',
'USER'=>'root',
'PASSWORD'=>'root',
'geoLoc'=>'0'
);