'use strict';

function r(n, top, left) {
  var p = document.getElementById('r' + n),
  e = p.style,
  rect = p.getBoundingClientRect();
  if (e.opacity == 0) {
    e.opacity = 1
  } else if (e.left == left + '%' && e.top == top + '%') {
    e.opacity = 0;
	event.target.blur();
  }
  e.top = top + '%';
  e.left = left + '%';
  if (e.opacity != 0 && (rect.top < 0 || rect.bottom > document.documentElement.clientHeight)) {
    p.scrollIntoView({
      block: 'center',
      behavior: 'smooth'
    });
  }
  return false;
}