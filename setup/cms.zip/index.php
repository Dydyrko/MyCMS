<?php	//date_default_timezone_set: Europe/Kiev, Europe/Moscow… (www.php.net/manual/ru/timezones.europe.php)

if($_SERVER['SERVER_ADDR']!='127.0.0.1'){	//не локально
	$file=$_SERVER['DOCUMENT_ROOT'].'/robots.txt';	//При отсутствии файла или коротком (Disallow) — авторизация: для поисковиков
	if(!file_exists($file) || filesize($file)<30){
		if(empty($_SERVER["PHP_AUTH_USER"]) || $_SERVER["PHP_AUTH_USER"]!='1'
		 || empty($_SERVER["PHP_AUTH_PW"]) || $_SERVER["PHP_AUTH_PW"]!='1'){
			header('WWW-Authenticate: Basic realm="I am not a robot"');
			header('HTTP/1.0 401 Unauthorized');
			exit('Ошибка авторизации!');
		}
	}
}

if(substr($_SERVER["REQUEST_URI"],0,3)=='/t/'){exit('-');}	//обращение к отсутствующему файлу в папке t уведомлений

define('MICRO_TIME_START',microtime(true));	//отображение времени исполнения в /1/public.php, /1/core/echoCSS.php, /1/core/echoJS.php

//$root=$_SERVER["DOCUMENT_ROOT"];if($root[strlen($root)-1]=='/'){$root=substr($root,0,-1);}	//удаляем закрывающий "/" если есть (на хостинге есть, в openServer нет)
$root=__DIR__;

$host=$_SERVER["SERVER_NAME"];
$host='//'.$host;

if(!date_default_timezone_set('Europe/Kiev')){exit('date_default_timezone_set?');}	//установленная зона применяется и в classDB.php

if(!empty($_GET['img'])){require $root.'/1/img.php';exit;}	//использует $root

if(strpos($_SERVER["REQUEST_URI"],'/sitemap.xml')!==false){require $root.'/1/core/sitemap.php';exit;}

if(isset($_GET['ae'])){require $root.'/1/core/a/e.php';exit;}	//инструменты редактирования страниц
if(isset($_GET['ap'])){require $root.'/1/core/a/p.php';exit;}
if(isset($_GET['css'])){require $root.'/1/core/a/css.php';exit;}
if(isset($_GET['js'])){require $root.'/1/core/a/js.php';exit;}
if(isset($_GET['htm'])){require $root.'/1/core/a/htm.php';exit;}
if(isset($_GET['robots'])){require $root.'/1/core/a/robots.php';exit;}
if(isset($_GET['inHead'])){require $root.'/1/core/a/inHead.php';exit;}
if(isset($_GET['inBody'])){require $root.'/1/core/a/inBody.php';exit;}

$n=strrpos($_SERVER['REQUEST_URI'],'.css');	//при отсутствии файла "*.css"
if($n>0){					//подключается css.ini (цветовой набор),
	require $root.'/1/core/echoCSS.php';	//выполняется "*.css.php" в буфер (удаляются комментарии)
	exit;					//возвращается с заголовками CSS и кэширования
}

$n=strrpos($_SERVER['REQUEST_URI'],'.js');	//при отсутствии файла "*.js"
if($n>0){					//вывод текста файла в "/1/js/*.js"
	require $root.'/1/core/echoJS-func.php';
	require $root.'/1/core/echoJS.php';	//если нет COOKIE "js" — удаляются комментарии и лишние пробелы
	exit;
}

if(isset($_COOKIE['PHPSESSID'])){	//была авторизация в login.php или по ссылке userLink.php,
	session_set_cookie_params([
		'lifetime' => 0,
		'path' => '/',
		'domain' => $_SERVER['HTTP_HOST'],
		'secure' => false,
		'httponly' => false,
		'samesite' => 'strict'
	]);
	session_start();		
}else{					//кэш браузера
	header('Expires: '.gmdate('D, d M Y H:i:s',date('U')+3600).' GMT');	//на час
	header('Cache-control: public, must-revalidate');
}

if(strpos($_SERVER['HTTP_USER_AGENT'],'Mobile')!==false){$mobile=1;}

require $root.'/1/core/class.db.php';
DB::getInstance();

	//Указание языка
$t=substr($_SERVER["REQUEST_URI"],1,3);
$n=count($Langs);	//количество языков сайта (config). Если в URL указан язык страницы, то применить
for($i=$n-1;$i>=0;$i--){
	if($t==$Langs[$i].'/'){
		$lang=$Langs[$i];
		unset($n);break;
	}
}
if(isset($n)){	//если цикл не дал результата
	$REQUEST=$_SERVER["REQUEST_URI"];
	$lang=$Langs[0];	//=основному языку
}else{$REQUEST=substr($_SERVER["REQUEST_URI"],3);}

if(!empty($_SERVER["HTTP_REFERER"])&& strpos($_SERVER["HTTP_REFERER"],$_SERVER["SERVER_NAME"])===false){
	$file=$root.'/1/log/log.txt';
	if(file_exists($file) && filesize($file)>5000000){rename($file,$file.'.bak');}
	file_put_contents(
		$file,
		date("Y.m.d H:i:s")
		."\t".$_SERVER["REMOTE_ADDR"]
		."\t".$_SERVER["HTTP_REFERER"]
		."\t".$_SERVER["REQUEST_URI"]
		."\t".$_SERVER["HTTP_USER_AGENT"]
		."\n",
		FILE_APPEND
	);
}

require $root.'/1/core/sUrl.php';	//функции текстовых URL
require $root.'/1/core/functions.php';

if(isset($_GET['ajx'])){
	require $root.'/1/ajx.php';
	if(!empty($DbLog)){dblog();}
	exit;
}
if(isset($_GET['admin'])){require $root.'/1/core/admin.php';exit;}

$headerStr='';

require $root.'/1/core/urlAr.php';	//текстовые URL
require $root.'/1/core/page.php';	//массив Page

if(isset($_SESSION['editMode']) &&				//режим редактирования и
	(
		isset($_SESSION['user']['admin']) ||		//админ или
		(
			isset($_SESSION['user']['id']) &&
			$_SESSION['user']['id']==$owner		//владелец страницы
			|| $_SESSION['user']['final']==-120	//или менеджер
		)
	)
){$editMode=1;}

require '1/public.php';
if(!empty($DbLog)){dblog();}