'use strict';	//для редактирования в отдельном окне браузера файлов CSS или JS — страницы (editBar) или вложенных страниц (редактирование списка)

	if(!opener || opener.closed){document.body.innerHTML="You need to close this browser window"}

	(function(){
		var s=location.search,id,t;	//s='?p=7&child=5'
		if(!s){return false}
		s=s.split('=');			//['?p','7&t',title&child','5']	//['?p','7&child','5']
		if(s.length){id=s[1]}
		if(!id){return false}
		id=id.split('&');		//[7,t]
		document.body.id=id[0];
		//console.log(s.length,s);
		if(s.length>2){	//child
			document.body.dataset.c=s[2];
			document.querySelector('h1').firstChild.textContent+=' subpages'
		}
	})();

	function txtPos(evt,a){
 		if(evt && evt.keyCode==9){	//tab
			var p=a.selectionStart,s=a.value;
			a.value=s.substr(0,p)+"\t"+s.substr(p);
			a.selectionStart=p+1;
			a.selectionEnd=a.selectionStart;
		}else if(evt && evt.keyCode==113){saveFile()}	//F2
		var p=a.selectionStart,A=a.value.split('\n'),B=[],i=0,m=0,n;
		for(i;i<A.length;i++){
			n=A[i].length;m+=n+1;
			if(m>p){
				g('txtPos').textContent=(i+1)+':'+(n-(m-p)+1)+' /'+n;
				break
			}
		}
	}

	function files(evt,a){	//filesBtn: показать/скрыть список файлов
		var e=document.querySelector('.files');
		if(e.className=='files'){
			e.className='files a';
			if(!e.firstChild || evt.shiftKey){
				ajx(evt,'core_css','dir&id='+document.body.id
				+'&ft='+a.form.dataset.ft		//fileType=css|js
				+(document.body.dataset.c?'&c=':'')	//признак вложенных страниц
				,e
				)
			}
		}else{
			e.className='files'
		}

	}
	function getFile(evt){	//onclick в списке файлов
		var e=evt.target,form=e.parentNode.parentNode.firstChild.firstChild.form;
		if(e.className=='delFile'){
			var t=e.parentNode.previousSibling.previousSibling.firstChild.textContent;
			if(!confirm('Delete a file «'+t+'»? \n\nTo disable a file - specify the order «0»')){return false}
			ajx(evt,'core_css','delFile&ft='+form.dataset.ft+'&t='+encodeURIComponent(t),e.parentNode);
			return false
		}else if(e.dataset.t=='makeTmp'){
			var t=e.parentNode.previousSibling.previousSibling.previousSibling.firstChild.textContent;
			ajx(evt,'core_css',e.className+'&t='+t+'&ft='+form.dataset.ft,e
			,[`var A=txt.split('|');txt=A[0];div.title=A[1];div.className=(div.className=='makeTmp'?'delTmp':'makeTmp')`]
			);
		}else{
			if(e.tagName!='A'){return}
			document.querySelector('.files').className='files';
			var r=g('r');	//textarea
			g('filesBtn').nextSibling.value=e.textContent;
			ajx(evt,'core_css',e.textContent+'&ft='+form.dataset.ft,r);
		}
	}
	function saveFile(){
		var e=g('filesBtn').nextSibling,fileName=e.value;	//css в списке без ".php"
		if(fileName==''){e.focus();return false}
		ajx(0,'core_css',encodeURIComponent(fileName)+'&ft='+e.form.dataset.ft+'&saveFile='+encodeURIComponent(g('r').value));
	}