<?php
session_start();
/*
if(empty($_SESSION['user']['admin'])
 && (empty($_SESSION['user']['final']) || $_SESSION['user']['final']!=-120)
){
	exit('<a href=/admin>Требуется авторизация</a>');
}
*/
$root=$_SERVER["DOCUMENT_ROOT"];
$content=$root.'/help/content.txt';
if(isset($_GET['ajx'])){
	if(isset($_POST['saveFile'])){
		if($_POST['saveFile']==''){$_POST['saveFile']='index';}
		echo file_put_contents('1/'.$_POST['saveFile'].'.htm',$_POST['s']);
	}else if(isset($_POST['content'])){
		echo content();
	}else if(isset($_POST['files']) && $_POST['files']==-26){
		require $root.'/1/core/class.db.php';
		DB::getInstance();
		$lang=$Langs[0];
		require $root.'/1/core/files.php';
	}
	exit;
}


if(empty($_GET['p'])){$_GET['p']='index';}
echo
'<!doctype html><html lang="help">
<title>Справка по сайту «'.$_SERVER["SERVER_NAME"].'»</title>
<script src=/js/ajx.js></script>
<script src=/js/f.js></script>
<script src=/js/editMode.js></script>
<link type="image/png" rel="shortcut icon" href="/favicon.png">
<link rel="stylesheet" type="text/css" href="/css/ajx.css">
<style>
*{box-sizing: border-box;outline:none}
#edit{border-style: outset;}
#edit.a{border-style: inset;}
a{cursor: pointer;}
</style>
<body style="margin:5px;padding:0">'

	.'<div style="background-color:#777;padding-left:2em;margin:-5px -5px 5px -5px">
		<a style="color:#fff;text-decoration:none" href=index.php>Справка по сайту «'.$_SERVER["SERVER_NAME"].'»</a>
	</div>';

if(isset($_SESSION['user']['admin']) && $_SESSION['user']['admin']=='dev'){	//для разработчика
	echo
	'<div style="position:fixed;background-color:rgba(255,255,255,.9);box-shadow: 0 0 5px #aaa;">'
		.'<div class="editBar" data-id="-26"><span>'
			.'<button id=edit onclick="
				var e=parentNode.parentNode.parentNode.nextSibling;
				if(className!=\'a\'){
					e.contentEditable=true;className=\'a\';
					e.focus();
					nextSibling.style.display=\'\'
				}else{
					e.contentEditable=false;className=\'\';
					nextSibling.style.display=\'none\'
				}
			" title="Редактировать текст">Edit</button><span style="padding: 0 10px;background-color: #ffd;display:none">';
				require $_SERVER["DOCUMENT_ROOT"].'/1/core/editTools.php';
			echo
			'</span> '
			.'<button onclick="imgSrc(this)" title="Проверка картинок'
				.' (если желаете хранить картинки в тексте (base64) — не используйте эту кнопку).'
				."\n".' Если код картинки в тексте или на другом сервере'
				.' — то переместить картинку в галерею файлов страницы.'
				.' Если путь к файлу абсолютный — то изменить путь на относительный: отобразится количество изменений.'
				."\n".' Так как картинок может быть несколько — повторите до сообщения «OK».'
				.'">imgSrc</button> '

		.' <button onclick="ajx(event,\'files\',\'-26&t=help\',0,\'jsAppend(\\\'screenfull\\\')\')"'
			.' title="Галерея файлов страниц «справки»">&#10048;</button> '

			.'<button onclick="
			parentNode.parentNode.dataset.id=\''.$_GET['p'].'\';
			var e=window.open(\'/?htm&p='.$_GET['p'].'\',\'edit'.$_GET['p'].'\',\'resizable,scrollbars,status\');
			e.focus();" title="Открыть редактор кода">HTML</button>'
	
			.' <tt contenteditable data-p="'.$_GET['p'].'" style="cursor:help" title="Имя файла — без расширения (htm).'."\n"
				.' Если изменить — сохранение будет в новый файл, нажатием кнопки «content» создастся новое оглавление">'.$_GET['p'].'</tt>'
	
			.'<button id="editBarSave" class="Save" onclick="
				var	e=parentNode.parentNode.parentNode.nextSibling,	//text
					n=nextSibling,		//куда
					p=previousSibling,	//fileName
					t=p.textContent,
					b=(t!=p.dataset.p);	//new file
				n.textContent=\'Запись в файл…\';
				window.lang=\'help\';
				ajx(0,\'saveFile\'
					,t+\'&b=\'+b+\'&s=\'+encodeURIComponent(e.innerHTML)
					,n
				)
	
				//alert(e.innerHTML)
			" title="Сохранить в файл'."\n"
			.'[F2] при курсоре в тексте">Save</button>'
			.'<tt style="cursor:help" title="Байт"></tt>'
		.'</span></div>'
	.'</div><div style="padding-top:30px"';

	echo ' onkeyup="if(event.keyCode==113){
		event.stopPropagation();event.preventDefault();
		document.getElementById(\'editBarSave\').onclick();
		return false}"';
}else{echo '<div';}


if(empty($_GET['p'])){
	echo '>';
	//require '1/index.htm';
	$file=$_SERVER["DOCUMENT_ROOT"].'/help/1/index.htm.htm';
}else{
	echo ' data-id="'.$_GET['p'].'">';
	$file=$_SERVER["DOCUMENT_ROOT"].'/help/1/'.$_GET['p'].'.htm';
	//if(file_exists($file)){include $file;}
}
if(file_exists($file)){
	$A=file($file);
	$A[0]='';
	echo implode("\n",$A);
}
echo
'</div>'
.'<hr>';

if(!file_exists($content) && isset($_SESSION['user']['admin'])){echo '<p>Создание файла оглавления: '.content().' Байт</p>';}
require $content;
if(isset($_SESSION['user']['admin'])){	//для разработчика
	echo
	'<div style=float:right>'
		.'<button onclick="window.lang=\'help\';ajx(0,\'content\',0,nextSibling)" title="Создать/обновить оглавление">content</button>'
		.'<div></div>'
	.'</div>';
}

function content(){
	global $root,$content;
	$A=scandir($root.'/help/1');
	$B=array('<ol><a href=/help/>CMS</a>');
	$M=array(
		'<!doctype html><title>Справка по сайту «'.$_SERVER["SERVER_NAME"].'»</title>'
		.'<style>'
			.'html,body{height: 100%;}'
			.'a{cursor:pointer}'
		.'</style>'
		.'<base target=main>'
		.'<body style="margin: 1px 5px 1px 1px;overflow:hidden">'
		.'<div style="position: absolute;z-index:1;top:-3px;left:10px;overflow:auto;height:20px;">'
		.'<div style="text-align:right"><a onclick="'
		.'var p=parentNode.parentNode;'
		.'if(p.offsetHeight<30){'
			.'p.style.height=p.scrollHeight+\'px\';'
			.'p.style.border=\'solid 1px #ccc\';p.style.borderTop=0;'
			.'p.style.backgroundColor=\'#fff\';'
		.'}else{'
			.'p.style.height=\'20px\';'
			.'p.style.borderWidth=0;'
			.'p.style.backgroundColor=\'transparent\';'
		.'}" style="background-color:#99f;color:#fff;font-size:12px;padding:0 2px;margin-right:1px">&darr; Меню'
		.'</a></div><ol style="padding-right:5px" onclick="previousSibling.lastChild.onclick()">'	
		.'<li><a href="index.htm">CMS</a>'
	);
	foreach($A as $v){
		$ext=substr($v,strrpos($v,'.'));
		if($ext=='.htm' && $v!='index.htm'){
			$C=file('1/'.$v);
			if(empty($C[1])){$C[1]='<h1>Бланк</h1>';}
			$name=substr($v,0,strrpos($v,'.'));
			$B[]='<li><a href="?p='.$name.'">'.strip_tags($C[1]).'</a>';
			$M[]='<li><a href="'.$name.'.htm">'.strip_tags($C[1]).'</a>';
		}
	}
	$B[]='</ol>';
	$M[]='</ol></div><iframe name=main frameborder=0 src="index.htm" style="width:100%;height:100%;position:relative;z-index:0"></iframe>';
	$s1=file_put_contents($content,$B);
	$s2=file_put_contents($root.'/help/1/index.html',$M);
	return $s1.'<br>'.$s2;
}
