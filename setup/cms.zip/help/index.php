<?php
session_start();
/*
if(empty($_SESSION['user']['admin'])
 && (empty($_SESSION['user']['final']) || $_SESSION['user']['final']!=-120)
){
	exit('<a href=/admin>Требуется авторизация</a>');
}
*/
$root=$_SERVER["DOCUMENT_ROOT"];
$content='content.t';
if(isset($_GET['ajx'])){
	if(isset($_POST['saveFile'])){
		if($_POST['saveFile']==''){$_POST['saveFile']='index';}
		echo file_put_contents('1/'.$_POST['saveFile'].'.txt',$_POST['s']);
	}else if(isset($_POST['content'])){
		echo content();
	}else if(isset($_POST['files']) && $_POST['files']==-26){
		require $root.'/1/core/class.db.php';
		DB::getInstance();
		$lang=$Langs[0];
		require $root.'/1/core/files.php';
	}
	exit;
}


if(empty($_GET['p'])){$_GET['p']='index';}
echo
'<!doctype html><html lang="help">
<title>Справка для менеджера сайта '.$_SERVER["SERVER_NAME"].'</title>
<script src=/js/ajx.js></script>
<script src=/js/f.js></script>
<script src=/js/editMode.js></script>
<link type="image/png" rel="shortcut icon" href="/favicon.png">
<link rel="stylesheet" type="text/css" href="/css/ajx.css">
<style>
*{box-sizing: border-box;outline:none}
#edit{border-style: outset;}
#edit.a{border-style: inset;}
</style>
<body style="margin:5px;padding:0">'

	.'<div style="background-color:#777;padding-left:2em;margin:-5px -5px 5px -5px">
		<a style="color:#fff;text-decoration:none" href=index.php>Справка для менеджера сайта '.$_SERVER["SERVER_NAME"].'</a>
	</div>';

if(isset($_SESSION['user']['admin']) && $_SESSION['user']['admin']=='dev'){	//для разработчика
	echo
	'<div style="position:fixed;background-color:rgba(255,255,255,.9);box-shadow: 0 0 5px #aaa;">'
		.'<div class="editBar" data-id="-26"><span>'
			.'<button id=edit onclick="
				var e=parentNode.parentNode.parentNode.nextSibling;
				if(className!=\'a\'){
					e.contentEditable=true;className=\'a\';
					e.focus();
					nextSibling.style.display=\'\'
				}else{
					e.contentEditable=false;className=\'\';
					nextSibling.style.display=\'none\'
				}
			" title="Редактировать текст">Edit</button><span style="padding: 0 10px;background-color: #ffd;display:none">';
				require $_SERVER["DOCUMENT_ROOT"].'/1/core/editTools.php';
			echo
			'</span> '
			.'<button onclick="imgSrc(this)" title="Проверка картинок'
				.' (если желаете хранить картинки в тексте (base64) — не используйте эту кнопку).'
				."\n".' Если код картинки в тексте или на другом сервере'
				.' — то переместить картинку в галерею файлов страницы.'
				.' Если путь к файлу абсолютный — то изменить путь на относительный: отобразится количество изменений.'
				."\n".' Так как картинок может быть несколько — повторите до сообщения «OK».'
				.'">imgSrc</button> '

		.' <button onclick="ajx(event,\'files\',\'-26&t=help\',0,\'jsAppend(\\\'screenfull.min\\\')\')"'
			.' title="Галерея файлов страниц «справки»">&#10048;</button> '

			.'<button onclick="
			parentNode.parentNode.dataset.id=\''.$_GET['p'].'\';
			var e=window.open(\'/?htm&p='.$_GET['p'].'\',\'edit'.$_GET['p'].'\',\'resizable,scrollbars,status\');
			e.focus();" title="Открыть редактор кода">HTML</button>'
	
			.' <tt contenteditable data-p="'.$_GET['p'].'" style="cursor:help" title="Имя файла — без расширения (txt).'."\n"
				.' Если изменить — сохранение будет в новый файл, нажатием кнопки «content» создастся новое оглавление">'.$_GET['p'].'</tt>'
	
			.'<button id="editBarSave" class="Save" onclick="
				var	e=parentNode.parentNode.parentNode.nextSibling,	//text
					n=nextSibling,		//куда
					p=previousSibling,	//fileName
					t=p.textContent,
					b=(t!=p.dataset.p);	//new file
				n.textContent=\'Запись в файл…\';
				window.lang=\'help\';
				ajx(0,\'saveFile\'
					,t+\'&b=\'+b+\'&s=\'+encodeURIComponent(e.innerHTML)
					,n
				)
	
				//alert(e.innerHTML)
			" title="Сохранить в файл'."\n"
			.'[F2] при курсоре в тексте">Save</button>'
			.'<tt style="cursor:help" title="Байт"></tt>'
		.'</span></div>'
	.'</div><div style="padding-top:30px"';

	echo ' onkeyup="if(event.keyCode==113){
		event.stopPropagation();event.preventDefault();
		document.getElementById(\'editBarSave\').onclick();
		return false}"';
}else{echo '<div';}


if(empty($_GET['p'])){
	echo '>';
	require '1/index.txt';
}else{
	echo ' data-id="'.$_GET['p'].'">';
	$file=$_SERVER["DOCUMENT_ROOT"].'/help/1/'.$_GET['p'].'.txt';
	if(file_exists($file)){include $file;}
}
echo
'</div>'
.'<hr>';

if(!file_exists($content)){echo '<p>Создание файла оглавления: '.content().' Байт</p>';}
require $content;
if(isset($_SESSION['user']['admin'])){	//для разработчика
	echo
	'<div style=float:right>'
		.'<button onclick="window.lang=\'help\';ajx(0,\'content\',0,nextSibling)" title="Создать/обновить оглавление">content</button>'
		.'<div></div>'
	.'</div>';
}

function content(){
	global $content;
	$A=scandir($_SERVER["DOCUMENT_ROOT"].'/help/1');
	$B=array('<ol><a href=/help/>Справка для менеджера</a>');
	foreach($A as $v){
		$ext=substr($v,strrpos($v,'.'));
		if($ext=='.txt' && $v!='index.txt'){
			$C=file('1/'.$v);
			if(empty($C[0])){$C[0]='<h1>Бланк</h1>';}
			$name=substr($v,0,strrpos($v,'.'));
			$B[]='<li><a href="?p='.$name.'">'.strip_tags($C[0]).'</a>';
		}
	}
	$B[]='</ol>';
	return file_put_contents($content,$B);
}
