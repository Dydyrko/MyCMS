<?php	//public.php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(isset($editMode)){
	//$noedit=0;	//"1" для запрета редактирования
	$editBarId=-30;
	$editBarAdt=1;	//анонс
	$editBarPos='top:0px;position:absolute;';	//или fixed
	$editBarTitle='Header';
	require $root.'/1/core/editBar.php';
	//$noedit=0;	//отменить запрет редактирования
}

function menu($id){
	global $Parents;
	$i=0;
	$q='select id,'.DB::qL('name').',c from cat where v=1 and parent='.$id.' and ord>=0 order by ord limit 0,20';
	$r=DB::q($q);
	if(DB::num_rows($r)){
		$s=
		'<nav>';
		while($row=DB::f($r)){
			$s.=
			'<div><a href="/'.sUrl($row['id']).'"'
				.(isset($Parents) && in_array($row['id'],$Parents)?' class="cur"':'')
				.'>'
				//.'<div>'
					.$row['name']
				//.'</div>'
				.'</a>';
				if(
					$row['c']>0
					//&& $id==0	//если показывать вложенные только для корневых страниц (один уровень)
					//&& 0	//0=без вложенных
				){$s.=menu($row['id']);}
			$s.='</div>';
		}
		$s.=
		'</nav>';
		return $s;
	}
}