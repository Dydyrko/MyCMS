<?php	//public.php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(isset($editMode)){
	$noedit=0;
	$editBarId=-30;
	$editBarAdt=1;
	$editBarPos='position:fixed;top:0px';
	$editBarTitle='Шапка сайта';
	require $root.'/1/core/editBar.php';
	$noedit=0;
}

function menu($id){
	global $Parents;
	$i=0;
	$q='select id,'.DB::qL('name').',c from cat where v=1 and parent='.$id.' and ord>=0 order by ord limit 0,9';
	$r=DB::q($q);
	if(DB::num_rows($r)){
		$s=
		'<nav>';
		while($row=DB::f($r)){
			$s.=
			'<div><a href="/'.sUrl($row['id']).'"'
				.(isset($Parents) && in_array($row['id'],$Parents)?' class="cur"':'')
				.'>'
				//.'<div>'
					.$row['name']
				//.'</div>'
				.'</a>';
				if(
					$row['c']>0
					//&& $id==0	//если показывать вложенные только для корневых страниц (один уровень)
				){$s.=menu($row['id']);}
			$s.='</div>';
		}
		$s.=
		'</nav>';
		return $s;
	}
}