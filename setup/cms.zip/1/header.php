<?php	//public.php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(isset($editMode)){
	$noedit=1;
	$editBarId=-30;
	$editBarAdt=1;
	$editBarPos='position:fixed;top:0px';
	$editBarTitle='Шапка сайта';
	require $root.'/1/core/editBar.php';
	$noedit=0;
}
echo
'<div class="container" style="position:relative">'
	.$headInfo
.'</div>';

echo
'<div class="menu">'
	.'<div class="container" style="padding:0 15px">'
		.'<span class=menuBtn>'
			.'<a onclick="var e=parentNode;
				if(e.className!=\'menuBtn\'){
					e.className=\'menuBtn\'
				}else{
					e.className=\'menuBtn a\';
					e=document.querySelector(\'.ii.a\');
					if(e){e.className=\'ii\'}
				}
			"></a>'
			.'<div class=cat1>'
				.menu(0)
			.'</div>'
		.'</span>'
	.'</div>'
.'</div>';

function menu($id){
	global $Parents;
	$i=0;
	$q='select id,'.DB::qL('name').',c from cat where v=1 and parent='.$id.' and ord>=0 order by ord limit 0,9';
	$r=DB::q($q);
	if(DB::num_rows($r)){
		$s=
		'<nav>';
		while($row=DB::f($r)){
			$s.=
			'<div><a href="/'.sUrl($row['id']).'"'
				.(isset($Parents) && in_array($row['id'],$Parents)?' class="cur"':'')
				.'>'
				//.'<div>'
					.$row['name']
				//.'</div>'
				.'</a>';
				if($row['c']>0 /*&& $id==0*/){$s.=menu($row['id']);}
			$s.='</div>';
		}
		$s.=
		'</nav>';
		return $s;
	}
}