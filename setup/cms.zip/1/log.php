<?php	//admin.php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if($_POST['log']=='mail'){
	//var_dump($_POST['log']);
	$file=$_SERVER["DOCUMENT_ROOT"].'/1/log/send.log';
	if(!file_exists($file)){exit('Нет файла '.$file);}
	$lines = file($file);
	$lines=array_reverse($lines);
	foreach($lines as $i=>$v){
		$A=explode("\t",$v);
		$v=str_replace("\t",'<hr>',$v);
		echo '<dt><a onclick="var e=nextSibling;e.style.display=(e.offsetHeight?\'none\':\'block\')">'.$A[0].' | '.$A[1].' | '.$A[2].'</a>'
		.'<div style="display:none;position:absolute"><div style="border:solid 1px #bbb;background-color:#fff;padding:5px">'.$v.'</div></div>';
	}
	exit;
}
?>

<style>
	/*
	a{color:blue}
	a:hover{color:red;cursor:pointer}
	*/
	.log1 {float:left;border-collapse:collapse;margin-left:20px}
	.log .o {max-width:400px;max-height:60px;overflow:auto}
</style>
<?php
//$h=(empty($_GET['h'])?24:intval($_GET['h']));
//$d=date("Y.m.d H:i:s",time()-3600*$h);
//echo $d;

$d1=empty($_POST['d1'])?date("Y-m-d"):$_POST['d1'];

echo 'Переходы с других сайтов (REFERER)';

echo '<form onsubmit="return ajxFormData(event,this,0,parentNode)" style=display:inline><input name=log value="'.$_POST['log'].'" type=hidden>'
.'<input name=t class=v type=checkbox'.(isset($_POST['t'])?' checked':'').' onclick=form.onsubmit()><a onclick="previousSibling.click()"
title="Показать кроме статистики таблицу">журнал</a>';

	if($_POST['log']){
		require_once '1/core/sUrl.php';
		$url=sUrl($_POST['log']);
		echo
		' <input name=b class=v type=checkbox'.(isset($_POST['b'])?' checked':'').' onclick=form.onsubmit()>'
		.'<a onclick="previousSibling.click()"
			title="Фильтр по текущей странице">'
		.'Текущая</a>';
	}
echo
' с <input name=d1 value="'.(empty($_POST['d1'])?$d1:$_POST['d1']).'" size=9>'
	.'<a data-v="" onclick="calendar(this,1,3)" title="Начальная дата"><img src=/i/data.png></a><div class="calendar"></div>'
.' до <input name=d2 value="'.(empty($_POST['d2'])?'':$_POST['d2']).'" size=9>'
	.'<a data-v="" onclick="calendar(this,1,3)" title="Конечная дата"><img src=/i/data.png></a><div class="calendar"></div>'
.'<input type=submit value=&gt; title="Фильтр списка с начальной даты до конечной даты '."\n"
.'(Год-Месяц-День. Если начальная дата не задана — сегодня, если конечная дата не задана — без ограничения)">'
.'</form>';

$d1=str_replace('-','.',$d1);
if(!empty($_POST['d2'])){$d2=str_replace('-','.',$_POST['d2']);}

$file=$_SERVER["DOCUMENT_ROOT"].'/1/log/log.txt';
if(file_exists($file)){
	$lines = file($file);$B=array();$C=array();$IP=array();$i=0;
	foreach($lines as $v){
		if($v==''){continue;}
		$A=explode("\t",$v);
		if($A[0]>=$d1 && (empty($d2)||$A[0]<=$d2)){

			if($_POST['log'] && isset($_POST['b']) && !in_array($A[3],array('/?p='.$_POST['log'],'/'.$url))){continue;}

			$T=explode('/',$A[2]);
			$T[2]=str_replace('www.','',$T[2]);
			if(isset($C[$T[2]])){$C[$T[2]]++;}else{$C[$T[2]]=1;}
			if(isset($IP[$A[1]])){$IP[$A[1]]++;}else{$IP[$A[1]]=1;}
			$B[]='<tr><td>'.$A[0].'<td>'.$A[1].'<td>'
			.$T[2].'<div class=o>'
			.urldecode($A[2])
			.'</div>'
			.'<td>'.$A[3].'<td><div class=o>'.$A[4].'/div>';
			$i++;
		}
	}
	$B=array_reverse($B);
	echo ' записей:'.$i.' из '.count($lines);

	echo '<div>';
	arsort($C);
	echo '<table border style=float:left;border-collapse:collapse><tr><td colspan=3>'.count($C).' хостов | посещений';
	$j=0;
	foreach($C as $k=>$v){$j++;echo '<tr><td align=right style=color:#bbbbbb>'.$j.'<td>'.$k.'<td align=right>'.$v;}
	echo '</table>';

	arsort($IP);
	echo '<table class=log1 border><tr><td colspan=3>'.count($IP).' ip | посещений больше одного';
	$j=0;
	foreach($IP as $k=>$v){if($v>1){$j++;echo '<tr><td align=right style=color:#bbbbbb>'.$j.'<td>'.$k.'<td align=right>'.$v;}}
	echo '</table>';
	echo '</div>';
	if(isset($_POST['t'])){
		echo '<table class=log border style=clear:both;border-collapse:collapse>'
		.'<th>дата'
		.'<th>REMOTE_ADDR'
		.'<th>REFERER'
		.'<th>REQUEST_URI'
		.'<th>USER_AGENT'
		;
		echo implode('',$B);
		echo '</table>';
	}
}