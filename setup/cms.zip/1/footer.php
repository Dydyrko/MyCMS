<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(isset($editMode)){
	//$noedit=1;
	$editBarId=-31;
	$editBarAdt=1;
	$editBarPos='position:fixed;bottom:50px';
	$editBarTitle='Footer';
	require $root.'/1/core/editBar.php';
}
echo
'<div class="container">'
	.$footerInfo
.'</div>';


if(0){	
	//https://translate.google.com/manager/website/
	echo
	'<div id="google_translate_element" style="position:absolute;top:-30px;right:0;"></div>'
	.'<script type="text/javascript">'
	.'function googleTranslateElementInit(){'
		.'new google.translate.TranslateElement('
			.'{pageLanguage: "ru", layout: google.translate.TranslateElement.InlineLayout.SIMPLE},'
			.'"google_translate_element"'
		.');'
	.'}'
	.'</script><script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>';
}
	
	
