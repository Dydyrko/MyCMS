<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

//require_once $root.'/1/toFav.php';	//В избранное (есть в заголовке страницы p.php, но может быть нужно по аякс в карточке услуг мастера)
//require $root.'/1/itemComment.php';

function pubs($p,$where=''){
	if(!$p){return;}
	global $host,$subhost,$lang,$topParent,$parent,$root,$editMode,$LstParam
	,$P		//имена параметров для схем…
	;
$ord=$LstParam['ord'];
$w=$LstParam['w'];
$h=$LstParam['h'];if(empty($h)){$h=$w*3/4;}
$z=$LstParam['z'];
//var_dump($LstParam);

	//echo 'where='.$where;
	$N=(empty($LstParam['by'])?8:$LstParam['by']);	//статей на странице
	$now=date('Y-m-d H:i:s');

	$q='select count(*) as c from cat A'
	.' where '
	.' parent in ('.$p.')'
	.(isset($_SESSION['user']['my'])?'':' and v>0')	//В режиме "Мои" — и скрытые
	.' and ord>0'
	.(empty($where)?'':' and '.$where)
	;
	$row=DB::f(DB::q($q));
	$c=$row['c'];
	$pages=ceil($c/$N);
	if(isset($_GET['n'])){$_POST['n']=$_GET['n'];}
	$startRow=isset($_POST['n'])?intval($_POST['n']):0;

	$q='select A.id,'.DB::qL('name').','.DB::qL('adt').',img,owner,d'
	.' from cat A'
	.' where parent in ('.$p.')'
	.(isset($_SESSION['user']['my'])?'':' and v>0')
	.' and ord>0'
	.(empty($where)?'':' and '.$where)
	.' order by '.$ord;

	$q.=' limit '.$startRow.','.$N;

	$r=DB::q($q);
	$n=DB::num_rows($r);
	$m=$startRow+$n;	//порядковый номер последней строки
	if($n){
			//$w=($topParent==3 || $p==3?186:320);	//320;	//290;
			
			while($row1=DB::f($r)){
				if(0){		//особые варианты

				}else{
					echo
					'<div class=pub style="display:inline-block;vertical-align:top;padding:0 10px;width:'.($w+20).'px;height:'.($h+140).'px;text-align:center;overflow:hidden">'
						.'<a href="/'.sUrl($row1['id']).'">'
							.'<img src="'.$host.'/?img=/i/'.($row1['img']?'cat/'.$row1['img']:'0.jpg').'&w='.$w.'&h='.$h
								.($z?'&'.$z:'').'"><br>'
							.$row1['name']
						.'</a>';
						/*
						if(!(
							in_array($p, array(3)) || (isset($topParent) && in_array($topParent, array(3)))
						)){	//не Каталог товаров
							echo '<div>'.D1($row1['d'],0,1).'</div>';	//дата статьи
						}
						*/
						if($row1['adt']){
							if(isset($_SESSION['editMode'])){
								//$noedit=1;
								$editBarId=$row1['id'];
								$editBarAdt=1;
								$editBarPos='position:absolute;top:0px;left:0';
								$editBarTitle=$row1['name'].' (анонс)';
								require $root.'/1/core/editBar.php';
							}
							echo
							'<div class=adt style="border-top:solid 1px #bbb">'.$row1['adt'].'</div>';
						}else{echo '<br>';}
	
						//.toFav($row1['id'])
					echo '</div>';
				}
			}
		if($n<$c){
			if($lang=='ru'){
				$Lang=array('Страница','из');
			}else if($lang=='en'){
				$Lang=array('Page','from');
			}else{
				$Lang=array(
					//'Сторiнка'
					''
					,'з'
				);
			}
			$where=rawurlencode(base64_encode($where));
			$ord=rawurlencode($ord);
			echo
			'<div style=clear:both class="pager">'
				.($startRow-$N>=0?'<a href="'.($startRow-$N==0?'/'.sUrl($p):'?n='.($startRow-$N)).'" onclick="
					return ajx(event,\'pubs\',\''.$p.'&n='.($startRow-$N).'&by='.$N.'&where='.$where.'&ord='.$ord.'&w='.$w.'\'
					,parentNode.parentNode
					,\'/*ScrollUp();*/history.replaceState(null,null,Url(location.href)'.($startRow-$N==0?'':'+\\\'?n='.($startRow-$N).'\\\'').');\'
					,0,0,0,(document.cookie.indexOf(\'PHPSESSID\')>=0?0:\'GET\')
				)">&larr;</a>':'<a style-margin-right:65px></a>')
				.'<span title="'.$c.'">'.$Lang[0].' <input value="'.ceil($startRow/$N+1).'" type=number style="text-align:center;width:50px" min=1 max='.$pages
					.' onchange="focus()"'	//на случай изменения стрелками «type=number»
					.' onkeypress="if(event.keyCode==13){onblur()}"'
					.' onblur="if(value){ajx(event,\'pubs\',\''.$p.'&n=\'+(value-1)*'.$N.'+\'&by='.$N.'&where='.$where.'&ord='.$ord.'&w='.$w.'\',parentNode.parentNode.parentNode,\'ScrollUp();history.replaceState(null,null,Url(location.href)\'+(value==1?\'\':\'+\\\'?n=\'+(value-1)*'.$N.'+\'\\\'\')+\')\')}"> '.$Lang[1].' '.$pages.'</span>'
				.($m<$c?'<a href="?n='.$m.'" class="buttons_30" onclick="return ajx(event,\'pubs\',\''.$p.'&n='.$m.'&by='.$N.'&where='.$where.'&ord='.$ord.'&w='.$w.'\',parentNode.parentNode,\'/*ScrollUp();*/history.replaceState(null,null,Url(location.href)+\\\'?n='.$m.'\\\');\',0,0,0,(document.cookie.indexOf(\'PHPSESSID\')>=0?0:\'GET\'))">&rarr;</a>':'<a style-margin-left:65px></a>')
			.'</div>';
		}
	}else{
		if($lang=='ru'){
			$Lang='Не найдено';
		}else if($lang=='en'){
			$Lang='Not found';
		}else{
			$Lang='Не знайдено';
		}
		echo '<center>'.$Lang.'</center>';
	}
	//echo
	//'<div style=clear:both></div>';
}