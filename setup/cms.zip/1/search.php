<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

function search(){
	global $lang;
	$s=
	'<div class=search>'
		.'<input placeholder="Я ищу…"'
			.' onfocus="parentNode.style.opacity=1"'
			.' onblur="'
				.'var e=parentNode.lastChild.firstChild;if(!e || e.nodeType==3){parentNode.style.opacity=``}'
			.'"'
			.' onkeyup="if(value.length==0){parentNode.lastChild.innerHTML=``}else{qSearch(event,this,`'.$lang.'`)}"'
			.' onkeydown="clearTimeout(top.qSearchTimer)"'					
			.' data-cat=""'
			.($_GET['p']==-7 && !empty($_GET['q'])?' value="'.$_GET['q'].'"':'')
		.'><a onclick="var e=parentNode.lastChild.firstChild;console.log(e);'
			.'if(e && e.nodeType!=3){'
				.'href=`/'.sUrl(-7,'q=`+encodeURIComponent(previousSibling.value)')
			.'}else{previousSibling.focus();return false}"></a>'
		.'<div class=searchBlock style="position:absolute;right:0px;white-space:normal;;z-index:4;margin:15px 5px"></div>'
	.'</div>';

	return $s;
}