<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

function mailTo($mailto,$subject,$mes,$bcc=''){
	$from='info@'.$_SERVER["SERVER_NAME"];
	$header="MIME-Version: 1.0\nContent-Type: text/HTML;charset=UTF-8"
	//."\nFrom: ".$from
	."\nBcc: ".$bcc
	."\n".'X-Mailer: PHP/'. phpversion();
	$res=mail(
		$mailto,
		"=?UTF-8?B?".base64_encode($subject)."?=\n",
		//$mes,	//требуется разбиение при длине свыше 70
		wordwrap($mes, 70, "\r\n"),
		$header
	);

	$Path='1/log';
	if(!file_exists($Path)){mkdir($Path);}
	if($res){
		$fp = fopen($Path.'/send.log', 'a');
		fputs($fp, date("Y.m.d H:i:s")
			."\t".$mailto.($bcc?' Копия: '.$bcc:'')
			."\t".$subject
			."\t".str_replace(array("\r\n","\n","\r"),' ',$mes)
			."\t".$_SERVER['REMOTE_ADDR']
			."\n");
		fclose($fp);
	}
	return $res;
}