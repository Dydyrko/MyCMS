<?php
//Crop image to w & h, or resize only to w or to h. Example: "/?img=/i/1.jpg&w=300&h=500"
//&m - max w or h (без обрезания вписать картинку в размеры)
//&top — при обрезании оставить верх, иначе — центр
//&z - увеличивать (zoom)
//&gray
//&jpg преобразовать в jpeg (png для уменьшения размера)
//&p=1 вторая страница PDF
//&fit
//&b	border-color (1px)
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(isset($_GET["txt"])){
	if($_GET["img"]=='captcha'){
		$t=mt_rand(100,99999);
		session_start();
		$_SESSION['captcha'.(empty($_GET["id"])?'':intval($_GET["id"]))]=$t;	//id=1 для напоминания пароля (если на странице несколько капч)
	}else{$t=$_GET["txt"];}
	$image = new Imagick();
	$draw = new ImagickDraw();
	$pixel = new ImagickPixel('white');
	$image->newImage(100, 32, $pixel);
	$draw->setFillColor('black');

	//$draw->setFont($_SERVER["DOCUMENT_ROOT"].'/font/HelveticaNeueCyr-Roman.ttf');
	$draw->setFont($_SERVER["DOCUMENT_ROOT"].'/font/HARNGTON.TTF');	//CHILLER.TTF	BRADHITC.TTF

	$draw->setFontSize(28);

	//$draw->setGravity(Imagick::GRAVITY_CENTER);
	$draw->setGravity(Imagick::GRAVITY_WEST);

	$image->annotateImage($draw, 0, 0, 0, $t);

	$image->setImageFormat('png');

	//$image->motionBlurImage(3,3,-45);	//($radius, $sigma, $angle)
	$image->swirlImage(-15);

	header('Content-type: image/png');
	echo $image;
	exit;
}

if(empty($_GET["p"])){$_GET["p"]=0;}else{$_GET["p"]=intval($_GET["p"]);}	//первая страница файла pdf
$filename = urldecode($_GET["img"]);	//'/Data/Users/6/1.jpg';
$filename=$root.$filename;
if(!file_exists($filename)){	//файла нет
	header('Content-type: image/gif');
	$filename=$root.'/i/0.gif';
	readfile($filename);
	exit;
}
$size_img = @getimagesize($filename);	//@ подавляет вывод ошибки
if(!$size_img){
	$finfo = finfo_open(FILEINFO_MIME_TYPE);
	$t=finfo_file($finfo, $filename);
	//echo $t;exit;
	//echo (strpos($t,'text/plain')!==false);exit;
	if($t=='application/zip'){
		$filename=$root.'/i/zip.png';
	}else if($t=='application/x-rar'){
		$filename=$root.'/i/rar.png';

	}else if(strpos($t,'excel')!==false){
		$filename=$root.'/i/xls.png';
	}else if(strpos($t,'word')!==false){
		$filename=$root.'/i/doc.png';
	}else if(strpos($t,'presentation')!==false){
		$filename=$root.'/i/ppt.png';
	}else if(strpos($t,'office')!==false){
		$filename=$root.'/i/office.png';
	/*
	}else if(strpos($t,'pdf')!==false){
		$filename=$root.'/i/pdf.png';
	*/
	}else if(strpos($t,'text/plain')!==false){
		$image = new Imagick();
		$draw = new ImagickDraw();
		$pixel = new ImagickPixel('white');
		$image->newImage(80, 28, $pixel);
		$draw->setFillColor('black');
		$draw->setFontSize(28);
		$draw->setGravity(Imagick::GRAVITY_CENTER);
		$image->annotateImage($draw, 0, 0, 0, substr($filename,strrpos($filename,'.')));
		$image->setImageFormat('png');
		header('Content-type: image/png');
		echo $image;
		exit;
	}else if($t=='image/svg+xml' || $t=='text/html'){
		header('Content-type: image/svg+xml');	//svg+xml
		readfile($filename);
		exit;
	}else	
		if(
			strpos($t,'pdf')===false
			&&
			strpos($t,'text/plain')===false
		)
		
	{
		$filename=$root.'/i/q.png';
	}
	$size_img = @getimagesize($filename);
}
//var_dump($size_img);exit;
/*
if($size_img[2]==1){	//gif
	header('Content-type: image/gif');
	readfile($filename);
	exit;
}
*/
$imgtype=array('','gif','jpeg','png');
$tmpFile=$filename
	.(empty($_GET["w"])?'':'.w'.$_GET["w"])
	.(empty($_GET["h"])?'':'.h'.$_GET["h"])
	.(empty($_GET["b"])?'':'.b'.$_GET["b"])	//border
	.(isset($_GET["m"])?'.m':'')
	.(isset($_GET["z"])?'.z':'')
	.(isset($_GET["top"])?'.top':'')
	.(isset($_GET["gray"])?'.gray':'')
	.(isset($_GET["mark"])?'.mark':'')
	.(empty($_GET["p"])?'':'.p'.$_GET["p"])
	.(isset($_GET["fit"])?'.fit':'')
	.'.tmp';
if(
	!isset($_GET['new']) &&
	file_exists($tmpFile) && filectime($tmpFile)>filectime($filename)
){

	if(empty($size_img[2])){$size_img[2]=2;}
	header("Expires: ".gmdate("D, d M Y H:i:s",date("U")+3600*6)." GMT");
	header("Cache-control: public");
	if(!empty($_GET["name"])){
		header("Content-Type: application/download; charset=utf-8");
		header("Content-Disposition: attachment; filename='".str_replace(' ','_',urldecode($_GET["name"]))."'");
	}
	header('Content-type: image/'.$imgtype[$size_img[2]]);
	readfile($tmpFile);
	exit;
}
if(isset($_GET["mark"])){
	if(!empty($_GET["mark"])){
		$mark=urldecode($_GET["mark"]);
	}else{$mark='/i/wmark2.png';}
	$mark=$root.$mark;
	$im2 = new imagick($mark);
}

//$im = new imagick($filename);
//$n=$im->getNumberImages();
//echo $n;exit;
//if($_GET['p']>$n-1){$_GET['p']=$n-1;}
try{
	$im = new imagick($filename.'['.$_GET['p'].']');
}catch(Exception $e){
	exit;
}

//$image_iterations = $im->getImageIterations();
//echo $filename.'<br>';
//echo $image_iterations;exit;
/*
if($image_iterations){
	header('Content-type: image/'.$imgtype[$size_img[2]]);
	$h=fopen($filename,'r');
	echo fread($h,filesize($filename));
	fclose($h);
	exit;
}
*/

$W=$im->getImageWidth();$H=$im->getImageHeight();
if(!$size_img){$size_img=array($W,$H);}	//PDF
$src_ratio=$W/$H;

$w=(empty($_GET['w']))?0:$_GET['w'];
$h=(empty($_GET['h']))?0:$_GET['h'];
if($w || $h){
	if(!isset($_GET['z']) && ($W<$w && $H<$h)){	//иначе без увеличения
		//echo $w;exit;
	}else{
		$h1=$w/$src_ratio;
		$w1=$h*$src_ratio;
		if(isset($_GET['m'])){	//пропорционально вписать в размеры $w, $h
			if(!isset($_GET['z'])){		//без увеличения
				if(!$w){$w=$h;}
				if(!$h){$h=$w;}
				if($W<$w){$w=$W;}
				if($H<$h){$h=$H;}
			}
			if($h1>$h){$w=$h*$src_ratio;}
			if($w1>$w){$h=($w/$src_ratio);}
		}else{
			if(!$h){$h=($w/$src_ratio);}
			if(!$w){$w=$h*$src_ratio;}
			$r=$w/$h;
			$x=$y=0;
			if(isset($_GET['top'])){$x=0;$y=0;}else{$x=($W-$H*$r)/2;$y=($H-$W/$r)/2;}
			$x=($x<0?0:round($x));$y=$y<0?0:round($y);
			$im->cropImage(ceil($H*$r),ceil($W/$r),$x,$y);
		}
	
		//if(!$w||!$h){$bestfit=0;}else{$bestfit=1;}
		$bestfit=(isset($_GET['fit'])?0:1);
		//$bestfit=0;	//0=точно по размеру, 1=вписать в размер без исажений
		$fill=(empty($size_img[2])?1:0);	//белый фон для PDF
		$im->thumbnailImage(intval($w+.5),intval($h+.5),$bestfit,$fill);
		//$im->scaleImage($w,$h,$bestfit);
		//$im->resizeImage($w,$h,imagick::FILTER_LANCZOS,1,$bestfit);
		//$im->sampleImage($w,$h);	//наихудшее
	}
}

if(isset($_GET['z']) && !empty($_GET['w']) && !empty($_GET['h'])){
	$x=$_GET['w'] - $im->getImageWidth();
	$y=$_GET['h'] - $im->getImageHeight();
	$bg = new Imagick();
	$bg->newImage($_GET['w'], $_GET['h'], new ImagickPixel('transparent'));
	$bg->setImageFormat('png');
	$bg->compositeImage($im, Imagick::COMPOSITE_DEFAULT, intval($x/2+.5), intval($y/2+.5));
	$bg->mergeImageLayers(Imagick::LAYERMETHOD_FLATTEN);
	$im=$bg;
}

if(!empty($im2)){	//watermark
	//$im2->thumbnailImage(100,100,true,false);

	$x=$im->getImageWidth()-$im2->getImageWidth();
	$y=$im->getImageHeight()-$im2->getImageHeight();
	$im->compositeImage($im2, Imagick::COMPOSITE_DEFAULT, $x, $y); 
	//$im->flattenImages();
	$im->mergeImageLayers(Imagick::LAYERMETHOD_FLATTEN);
}

if(isset($_GET["b"])){$im->borderImage($_GET["b"], 1, 1);}	//border

//$im->setImageCompressionQuality(90);
if(isset($_GET["gray"])){$im->setImageColorspace(2);}
if(isset($_GET["jpg"]) || empty($size_img[2])){$size_img[2]=2;$im->setImageFormat("jpeg");}	//for PDF to jpg

$im->commentImage("servisvsem.com");

header("Expires: ".gmdate("D, d M Y H:i:s",date("U")+3600*6)." GMT");
header("Cache-control: public");
	if(!empty($_GET["name"])){
		header("Content-Type: application/download; charset=utf-8");
		header("Content-Disposition: attachment; filename='".str_replace(' ','_',urldecode($_GET["name"]))."'");
	}
header('Content-type: image/'.$imgtype[$size_img[2]]);
echo $im;
//$im->writeImage($tmpFile);
file_put_contents($tmpFile,$im);