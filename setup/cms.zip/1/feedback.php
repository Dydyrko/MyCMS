<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

//if(isset($_POST['tel'])){
if(isset($_POST['mail'])){
	if($_SESSION['captcha3']!=$_POST['captcha']){exit(' Captcha?');}

	$q='select name,note,'.DB::qL('adt').' from cat where id=-20';	//Форма обратной связи
	$row=DB::f(DB::q($q));
	$A=explode("\n",$row['note']);
	$mailto=trim($A[0]);
	if(!$mailto || strpos($mailto,'@')<2){
		$q='select mail from person where id=-201';
		$r=DB::q($q);
		if(DB::num_rows($r)){
			$row1=DB::f($r);
			$mailto=$row1['mail'];
		}else{exit(' mail to?');}
	}

	if(!empty($_FILES['file']['name'])){				//резюме в stomadent.pro
		$mime=mime_content_type($_FILES['file']["tmp_name"]);
		$time=time();
		$Path='/1/vacancy';
		if(!file_exists($root.$Path)){mkdir($root.$Path);}
		$Path.='/'.$time;	//date('Y-m-d.His');
		if(!file_exists($root.$Path)){mkdir($root.$Path);}
		require $root.'/1/translit.php';
		$fileName=translit(mb_strtolower($_FILES['file']['name'],'UTF-8'));
		if(!move_uploaded_file($_FILES['file']["tmp_name"],$root.$Path.'/'.$fileName)){
			$E=error_get_last();
			echo '<p>Err: '.$E['message'].'</p>';
			exit;
		}

	}

	require '1/mailTo.php';
	$d=date('Y-m-d H:i:s');
	$subject=	//'Feedback from '.
		$_SERVER["SERVER_NAME"].': '.(empty($_POST['feedback'])?$row['name']:$_POST['feedback']);
	$mes=	(empty($_POST['name'])?'':'<p>Имя: '.$_POST['name'])
		.(empty($_POST['surname'])?'':'<p>Прізвище: '.$_POST['surname'])
		.(empty($_POST['patronymic'])?'':'<p>По батькові: '.$_POST['patronymic'])

		//.'<p>Телефон: '.$_POST['tel']
		.(empty($_POST['tel'])?'':'<p>Телефон: '.$_POST['tel'])
		.(empty($_POST['mail'])?'':'<p>E-mail: '.$_POST['mail'])
		.(empty($_POST['t'])?'':'<p>'.$_POST['t'])			//radio Руки/Ноги
		.(empty($_POST['date'])?'':'<p>Дата: '.$_POST['date'])
		.(empty($_POST['text'])?'':'<p>'.strip_tags($_POST['text']))
		.(empty($_POST['select'])?'':'<p>'.(is_array($_POST['select'])?implode(', ',$_POST['select']):$_POST['select']))
		.(empty($fileName)?'':'<p><a href="https://'.$_SERVER['SERVER_NAME'].'/?viewVacancy='.rawurlencode($time.'/'.$fileName).'&t='.rawurlencode($mime).'">'.$fileName.'</a>')
		.'<p><a class=referer title="Страница — откуда сообщение (REFERER)" href="'.$_SERVER['HTTP_REFERER'].'" style="font-size:10px">'.$_SERVER['HTTP_REFERER'].'</a>'
		;
	$bcc='';
	if(!empty($fileName)){file_put_contents($root.$Path.'/mes.txt',$mes);}	//текст письма резюме в файл (stomadent.pro)

	if(mailTo($mailto,$subject,$mes,$bcc)){
		echo
		'<div style="font-size:initial;/*color:#fff;min-height:430px*/">'
			//.'<h2 style="display:block">'.(empty($_POST['feedback'])?$row['name']:$_POST['feedback']).'</h2>'
			.'<span style="display:block;padding:15px;/*background-color:rgba(0,0,0,.5);*/max-width:360px;margin: auto;">'.$row['adt'].'</span>'	//текст на экране после отправки сообщений менеджерам
			.'<div style="display:none;/*background-color:rgba(0,0,0,.5);margin: 10px auto 0 auto;*/padding:0 15px;max-width: 360px;">'.$mes.'</div>'
		.'</div>';
	}

}else{
	/*	//Выбор темы сообщения
	$q='select '.DB::qL('name').' from cat where parent=1 and v=1 order by ord,name';
	$r=DB::q($q);
	$A=array();
	while($row=DB::f($r)){$A[]='<li><label><input name=select[] value="'.$row['name'].'" type=checkbox> '.$row['name'].'</label>';}
	*/

	$q='select '.DB::qL('name').','.DB::qL('text').' from cat join url on cat.id=url.id where cat.id=-20';
	$Feedback=DB::f(DB::q($q));

	//$row['text']=str_replace('{select}',implode('',$A),$row['text']);	//Выбор темы сообщения

	$Feedback['text']=str_replace('{captcha}',captcha(3),$Feedback['text']);	//functions.php

	if(!empty($_POST['feedback'])){		//текст особого заголовка формы передаётся аяксом для темы email
		$Feedback['text']=str_replace('name=feedback','name=feedback value="'.trim($_POST['feedback']).'"',$Feedback['text']);
	}

	echo'<link rel="stylesheet" type="text/css" href="/css/feedback.css">'
	.'<h2'
		.(isset($_SESSION['editMode'])?' title="'
			.'Отправка сообщения на email, указанный в комментарии раздела «Внутренние страницы / Обратный звонок».'
			."\n".'Текст посетителю после отправки — в анонсе, текст формы — в описании этого раздела.'
			."\n".'Выполнение формы — в функции js/feedback.js.'
			."\n".'Вёрстка формы — в css/feedback.css.'
			."\n".'Выполняется аякс к «1/ajx/feedback.php», POST[feedback] может содержать текст заголовка формы, указываемый и в теме email'
		.'" style="cursor:help"':'')
		.(isset($_POST['p'])?' class=p':'')	//возможность скрыть поля формы (для "Перезвонить" оставить только телефон)
	.'>'
		.(empty($_POST['feedback'])?$row['name']:$_POST['feedback'])	//заголовок формы может быть любым
	.'</h2>';
	echo $Feedback['text'];
}