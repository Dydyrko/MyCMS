<?php echo '
.ajxT{margin:5px}'	/*t.gif*/.'
.ajxAlert h2{
	position: absolute;
	padding: 5px 30px 5px 5px;
	margin: 0;
	width: 100%;min-height: 30px;
	top: 0;
	left: 0;
	background-color: '.$C[1].';
	color: #fff;
	font-size: 18px;
	border-radius: 15px 15px 0 0;
}
.ajxAlert h2 a{color:#bff}
.ajxAlert h2 a:hover{color:#fff}

.ajxAlert h2+div{margin-top:30px}

.ajxAlert .h{height:30px;background-color:'.$C[1].';font-size:24px;text-align:center;padding-right:40px;border-radius: 15px 15px 0 0;}
.ajxAlert .h a{color:#ddd}
.ajxAlert .h>a:hover{color:#fff}
.ajxAlert .h>a:nth-child(2){
    display: inline-block;
    vertical-align: middle;
    max-width: calc(100% - 120px);
    text-align: center;
    overflow: hidden;
    margin: 0 10px;
    min-width: 50%;
}

.ajxAlert h2 small{color:#fff}

.ajxAlert .ajxAlertQ{background:url(/i/q.png) no-repeat 0 0 white;color:red;padding-left:110px;min-height:70px}

.ajxAlert{position:absolute;top:0;left:0;height:100%;width:100%;z-index:10;opacity:0;transition:all .7s}
.ajxAlert>DIV{position:fixed;top:0;left:0;width:100%;height:100%;background-color:rgba(99,99,99,.8);}
.ajxAlert>aside{
	position:absolute;top:-99px;left:-99px;
	background-color:rgba(255,255,255,1);
	min-width:300px;border-radius: 15px;
	padding:60px 1em 1em 1em;border: solid 1px #fff;
	text-align:center;
	transition:all .5s;
}

.ajxAlert .close{
	position:absolute;right:5px;top:16px;
	font-family: sans-serif;font-size:40px;line-height:0;text-decoration:none;
	color:#ddd;transition:all .3s
}
.ajxAlert .close:hover{color:#fff;cursor:pointer}

.ajxAlert .close1{position: absolute;right: 30px;top: 30px;font-size:0;transition:all .5s;transform-origin:center}
.ajxAlert .close1:hover{transform:rotate(90deg)}
.ajxAlert .close1:before{
	content:"";position:absolute;right:-15px;top:-15px;
	width:30px;height:30px;
	background:url(/i/cat/-30/close.png) no-repeat;
}


.ajxSibling{position:absolute;z-index:1;background-color:#fff;box-shadow:0 0 5px #777 inset;padding:20px 10px 5px 10px;min-width:360px}
';