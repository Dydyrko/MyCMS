<?php echo '
footer{background-color: #000;color:#ccc}
footer>.container a{color:#999;}
footer>.container a:hover{color:#fff;}
footer .logo{display:inline-block;padding:20px 20px 0 20px}
';