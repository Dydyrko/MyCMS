<?php echo '
footer{background-color: '.$C[1].';color:#ccc}
@media(min-width:600px){
	footer>.container{display: flex;flex-flow: row;justify-content: space-between;align-items: center;}
}
@media(max-width:600px){
	footer>.container{text-align:center}
}
footer>.container a{color:#ccc;}
footer>.container a:hover{color:#fff;}
footer .logo{padding:20px 0}
footer a.btn{margin: 10px 0;border-color:#ccc}
footer a.btn:hover{border-color:#fff}
';