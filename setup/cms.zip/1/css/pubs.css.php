<?php /* Публикации (статьи…) */ echo'
/*.pubs{width:calc(100% + 20px);margin-left:-10px}*/
.pubs{padding-top:60px;padding-bottom:30px}
.adt{
	overflow-y: hidden;
	/*max-*/height: 80px;
	/*text-align:left;*/
	padding:0 5px;
	/*color:#999;font-size: 16px;*/
}
.adt>div{position:relative;padding-bottom: 30px;max-height: 80px;}
.adt>div::after{content:"";display:block;position:absolute;bottom:0;left:0;right:0;height:30px;
	background:linear-gradient(transparent,rgba(255,255,255,1))
}
.adt[contenteditable]>div::after{display:none}
.pub{
	position:relative;display:inline-block;vertical-align:top;
	padding:0 10px;text-align:center;overflow:hidden;
	max-width: 100%;
}
.pub img{max-width:calc(100% - 20px);}

.pager{margin-bottom:30px;}
.pager .btn,.ilb{padding: 5px;margin:10px}
.pager .ilb{
	width: 40px;text-align: center;font-size: 22px;
	border: solid 1px '.$C[1].';border-radius: 50%;
}
';