input[type="checkbox"].v{display: none;}
input[type="checkbox"].v + a::before {
  content: "";
  display: inline-block;
  vertical-align: middle;
  width: 20px;
  height: 20px;
  border: solid 1px #ddd;
  margin-right: 5px;
  background-color: #fff;
}
input:checked.v + a::before {
    content: "✓";
    text-align: center;
    font-size: 24px;
    line-height: 16px;
    font-weight: bold;
    color: #e40;
}