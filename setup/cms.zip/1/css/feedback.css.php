<?php echo '
.ajxAlert .feedback{
	margin-left:-5px;margin-top:-5px;margin-right: -5px;
}

.feedback>label{
	position:relative;display:block;
	border:solid 1px #ccc;margin-bottom: 15px;border-radius: 10px;
}
.feedback>label>input+div{
	position:absolute;left:10px;top:8px;right:0;font-size: 18px;text-align:left;
	background-color:#fff;color:#aaa;padding:0 5px;
	transition:top .5s;
}
.feedback>label>input+div.a{top:-9px;right:auto;font-size:14px;color:#aaa}
.feedback>label>input{
	width:100%;border: none;
	height: 30px;
	margin-top: 5px;
	margin-bottom: 3px;
	padding-left:10px;
	background-color: transparent;
	font-size: 16px;outline:none;
}

.feedback>label>textarea+div{
	position:absolute;left:10px;top:0px;font-size: 18px;
	background-color:#fff;color:#aaa;padding:0 5px;
	transition:top .5s;
}
.feedback>label>textarea+div.a{top:-10px;font-size:14px;color:#aaa}
.feedback>label>textarea{
	width:100%;border: none;
	height: 42px;
	margin-top: 5px;
	margin-bottom: 0px;
	padding-left:10px;
	background-color: transparent;
	font-size: 16px;outline:none;
	resize: vertical;
}

.feedback .tel.err{color:#faa}

.select{min-height:60px;border:solid 1px #fff;background-color:rgba(0,0,0,.5);text-align: left;}
.select > a{
	display: block;position:relative;margin-top:13px;margin-left:15px;padding-right:40px;color:#fff;cursor:pointer;
	transition:margin-top .5s;
}
.select > a.a{margin-top: 2px;font-size:12px;color:#ddd;cursor:default}
.select > a::before {
	content: "";
	display: block;
	position: absolute;
	width: 10px;
	height: 10px;
	right: 10px;
	top: 8px;
	border: solid 1px #fff;
	border-width: 0 1px 1px 0;
	transform: rotate(45deg);
	transform-origin: center;
	transition: all .5s;
}
.select > a.a::before {transform: rotate(135deg);}
.select>ul{display:none;list-style: none;margin: 10px 0;padding: 0 12px;color:#fff}
.select>a.a+ul{display:block}
.select li{height:30px}

.feedback button{margin:15px auto 0;}
.faqblock .feedback button{background-color:rgba(255,255,255,.8);}
.faqblock .feedback button:hover, .feedback button:focus{background-color:'.$C[2].'}
.feedback button:hover, .feedback button:focus{color:#fff;border:solid 1px #fff}

.feedback a.referer:hover{/*color:#fff*/}

';