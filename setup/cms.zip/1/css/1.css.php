<?php	echo '

*{box-sizing: border-box;outline:none}

html,body{height:100%;margin:0;padding:0}

body{
	font-family:sans-serif;
	font-size:14px;/*line-height:120%;*/
	color:'.$C[3].';
}
body>div{
	min-height: 100%;
	display: flex;
	flex-direction: column;
}
main{flex: auto;/*margin-top: 80px;*/}

.container{
	margin:0 auto;
	max-width:'.$C[0].';
	padding:0 30px;
}
@media all and (max-width: 400px){
	.container{padding:0 15px}
}

img{vertical-align:middle;max-width:100%}

a{
	text-decoration:none;color:'.$C[1].';cursor:pointer;
	-moz-user-select: none;
	-webkit-user-select: none;
	-ms-user-select: none;
	user-select:none;
}
a:hover{color:'.$C[2].';text-decoration:none}

a[name]{cursor:default}

a.btn{
	display:inline-block;padding:13px 40px;border:solid 1px '.$C[1].';text-align:center;
	transition:all .5s;
}
a.btn:hover,a.btn.a{background-color:'.$C[1].';color: #fff;}
a.btn:hover>img{filter: brightness(5);transition:all .5s;}
a.btn.a:hover{background-color:#fff;color: initial;}

div[contenteditable="true"] a{
	-moz-user-select: initial !important;
	-webkit-user-select: initial !important;
	-ms-user-select: initial !important;
	user-select:initial !important
}

.noselect{
	-webkit-user-select: none;
	-ms-user-select: none;
	user-select: none;
}

small{color:#999}

input::placeholder{opacity: .4;}
textarea{font-family: inherit;font-size: inherit;}

details{box-shadow: 0 0 5px #ccc;padding: 5px;margin: auto -5px 1em -5px;}
summary{font-size: 120%;font-weight: bold;cursor:pointer}
summary:hover{color:'.$C[2].'}

form button{
	background-color:'.$C[1].';color:#fff;
	font-family: inherit;
	font-size:14px;font-weight:600;padding:10px 20px;
	width:100%;
	border:solid 1px '.$C[1].';
	border-radius:25px;
	cursor:pointer;
	transition: all .5s linear;
}
form button:hover{background-color:'.$C[2].';}
form button:disabled{background-color:#bbb;cursor:not-allowed}

select.select{
	height: 40px;border:solid 2px '.$C[1].';/*border-radius:10px;*/appearance: none;
	background:url(/i/cat/4/select.png) no-repeat right center;padding-right: 30px;
	margin: 10px 0;
}

'/* = линия прогресса аякс - внизу страницы = */.'
progress{
	display:block;width:calc(100% - 10px);height:14px;
	overflow:hidden;position:fixed;z-index:11;bottom:1px;left:5px;
	transition:bottom .5s;
}
progress[value="0"]{bottom:-50px}

.editBar{z-index:9;background:rgba(255,255,220,.95);padding: 10px 5px;text-align:left}
.editBar>a{position:relative;z-index:1}
.editBar[data-m="1"]:after{
	content:"";position:absolute;top:0;left:0;right:0;bottom:0;
	background-color:rgba(255,255,255,.3);cursor:ns-resize;
}

'/* = диалог запроса формы нового пароля = */.'
	.newPsw input[name="login"]{width:100% !important;margin:5px 0}
	.newPsw button{font-size:18px;min-width:200px;margin-top:15px}

'/* = диалог авторизации = */.'
	.LogIn input[type="text"],
	.LogIn input[type="password"],
	.reg input,
	input[name="captcha"]
	{
		border:solid 1px #ccc;
		height:40px;margin-bottom:10px;width:100%;text-align:center;
		background-color: #fbfbfb;
		border-radius:10px;
		font-size:16px;
	}
	input[name="captcha"]{margin:0}

	.LogIn input[type="text"]:focus,
	.LogIn input[type="password"]:focus,
	.reg input:focus,
	input[name="captcha"]:focus
	{
		border-color: #ccf;
		background-color:#fefefe;
	}

	.LogIn button{font-size:18px;min-width:200px;border-color: transparent;}
	
	.psw{position:relative}
	.psw:hover{cursor:pointer}
	.psw::before{
	    content: "";
	    display: block;
	    position: absolute;z-index: 1;
	    top: 10px;
	    left: 5px;
	    width: 20px;
	    height: 20px;
	    background: url(/i/cat/-10/hide.svg) no-repeat center /cover;
	}
	.psw.t::before{
	    background-image: url(/i/cat/-10/view.svg);
	}
	.a>.psw::after {
		content: "?";
		position: absolute;z-index: 1;
		top: 10px;
		right: 0;
		padding: 0 5px;
		color:green;
	}
	img[alt="Captcha"]{cursor: pointer;}
	input[name="captcha"]{width:90px !important;text-align:center;}

@media(min-width: 800px){
	.home p,pText p,
	.home li,pText li
	{text-align:justify;}
}


';