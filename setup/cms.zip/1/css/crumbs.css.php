<?php echo '
.crumbs {
	padding: 10px 0;font-size: 14px;
}

.crumbs ul {
    margin: 0;
    padding: 0;
}

.crumbs li {
    list-style: none;
    color: #999;
    float: left;
    margin: 0 60px 0 0;
    position: relative;

}

.crumbs li:last-of-type {
    margin: 0;
}

.crumbs li:after {
    content: "";
    width: 10px;
    height: 10px;
    background: #c4c4c4;
    position: absolute;
    bottom: 3px;
    right: -35px;
}

.crumbs li:last-of-type:after {
    width: 0;
    height: 0;
}

.crumbs a {color: #999;}
.crumbs a:hover {color: '.$C[2].';}
';