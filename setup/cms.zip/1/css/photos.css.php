<?php echo'
.photos{position:relative;clear:both;float:left;overflow:hidden;max-width:100%;margin:15px 30px 15px 0}
.photos>img{max-width:100%;border: solid 1px #f1f1f1;cursor:zoom-in;transition:all .1s;opacity:0}
.photos>.block{overflow-x:auto;width:100%;border:solid 1px #f1f1f1;border-width:0px 1px;border-top:solid 1px #fff}
.photos>.block img{border-right:solid 1px #eee}
.photos>.block img:last-child{border:none}
@media (max-width: 800px){
	.photos{float:none;margin:15px auto}
	.photos>img{cursor:default}
}
';