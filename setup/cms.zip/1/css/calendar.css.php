.calendar{position:absolute;z-index:1;box-shadow:0 0 8px #777;background-color:#ffe;margin:8px}
.calendar table{border-collapse:separate;margin:5px;width:250px}
.calendar thead{color:#bbb;font-size:14px}
.calendar tbody td{text-align:center;border:solid 1px transparent;color:#777}
.calendar tbody td:hover{border-color:#777;color:#111;cursor:pointer}

.calendar .d{background-color:#fff;border-color:#000;color:#000;font-weight:bold}
/*.calendar .d:hover{cursor:default}*/

.calendar .null{text-align:center;font-size:30px;line-height:0;color:#777;transition:all .5s}
.calendar .null:hover{background-color:#000;color:#fff;cursor:pointer}

.calendar .close{position:absolute;line-height:0;right:0;top:2px;transition:all .5s}
.calendar .close:hover{transform:scale(3);cursor:pointer}

body .calendar h1{margin:5px;padding:0;text-align:center;font-size:120%}

.calendar a{text-decoration:none}