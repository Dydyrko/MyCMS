<?php	echo '

.cabinet input
{
	border:solid 1px #bbb;border-width:0;
	height:40px;margin-bottom:10px;width:100%;text-align:center;
	background-color: #f3f3f3;
	border-radius:10px;
	font-size:16px;
}
.cabinet .tel input{width: calc(100% - 24px);}
.cabinet button{font-size:16px;}

';