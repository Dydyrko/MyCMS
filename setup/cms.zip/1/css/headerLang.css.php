<?php echo '
header .lang{
	position:relative;display:inline-block;vertical-align: middle;
	/*background-color:#fff;*/
}
header .lang>a{
	display:block;position: relative;
	width: 50px;margin:5px;padding:5px;letter-spacing: 1px;
}
header .lang>a:hover{font-weight: bold;letter-spacing: 0px;}
header .lang>a:after{
	content: "";
	display: block;
	position: absolute;
	width: 20px;height: 20px;
	right: 0;top:5px;
	background: url(/i/down-but.png) no-repeat center transparent;
}
header .lang>ul{position:absolute;z-index: 10;left:0;right:0;margin:0;padding:0;list-style: none;box-shadow: 0 0 2px #bbb;}
header .lang li{padding:5px}
header .lang li:hover{color:'.$C[2].';cursor:pointer}
header .lang img{border:solid 1px #ddd;height: 16px;}

';