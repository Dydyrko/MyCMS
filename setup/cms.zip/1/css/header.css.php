<?php	echo '

#arrowUp{
	position: fixed;top:-40px;right: 2px;transition:all .5s;
	font-size: 200%;color: #fff;text-shadow: -1px -1px 3px #000;
}
#arrowUp.a{top:52%}
#arrowUp:hover{text-shadow: 1px 1px 3px #000;}

'/* = блок меню = */.'
	header .menu{/*height:40px;*/background-color:'.$C[1].';font-size:14px;}
	header .menu a{color:#fff}
	'/* - кнопка ("бургер") отображения меню при узком экране - */.'	
	.menuBtn>a{position:relative;top:1px;left:-5px;display:none;height:38px;width:38px}
	.menuBtn>a::before{
		content:"";position:absolute;top:12px;left:5px;
		display:block;height:15px;width:25px;
		border:solid 1px #fff;
		border-width:1px 0 1px 0;
		transition: all .5s;
		z-index:0;
	}
	.menuBtn>a::after{
		content:"";position:absolute;top:20px;left:5px;
		display:block;height:1px;width:25px;
		border-top:solid 1px #fff;
		transition: all .5s;
	}
	.menuBtn.a>a::before{
		height:0px;border-bottom-width:0;
		top:20px;
		transform:rotate(-45deg);
	}
	.menuBtn.a>a::after{
		top:20px;
		transform:rotate(45deg);
	}
	.menuBtn:hover>a::before,.menuBtn:hover>a::after{/*border-color:'.$C[2].'*/;}
	'/* - список пунктов меню - */.'
	header .menu nav{display:block;/*margin:0 -10px;*/}

	header nav>div{padding:12px 15px;}
	/*header .menu nav>a:last-child{float:right;}*/
	header .menu nav>div:hover{background-color:'.$C[2].'}
	/*header .menu nav>a:hover>a{color:#fff}*/
	
	header .menu nav>a>div{display:inline-block;vertical-align:middle}
	/*header .menu nav>a.cur>div{text-decoration:underline}*/
	header .menu nav>div>a.cur{text-decoration:underline}
	header .menu a:hover>div{text-decoration:underline}' /* текст ссылки в div для верт. выравнивания с a:after */.'
	header .menu nav>a:after{
		content:"";display:inline-block;vertical-align:middle;height:40px;
	}
	
	.menuBtn>.cat1{display:inline}

	header .menu nav>div>nav{display:none}
	header .menu nav>div:hover>nav{
		display:block;position:absolute;z-index:2;
		background-color:'.$C[1].';margin-top: 12px;
		/*margin-left: -15px;*/
		border-top:solid 1px #fff;border-left:solid 1px #fff;border-bottom: solid 1px #fff;
	}

'/* = блок, заполняемый аяксом = */.'
	#headerDiv{display:inline-block}
	header .login{min-width:40px;min-height:40px;}
	header .login>a{
		display:block;text-align: right;max-width: 150px;
	}
	header .loginDiv{width:223px;position:absolute;z-index:4;right:0;background-color:#fff;}
	.loginDiv ul{list-style:none}
	.loginDiv li{margin:10px 0}


@media (max-width: 800px){
	.menuBtn>a{display: block;margin: 0 auto;}'	/* меню */.'

	.menuBtn a{color:#ddd}
	.menuBtn a:hover{color:#fff}

	.menuBtn>.cat1>nav{/*display:none;*/padding:0;list-style:none;/*float:right;max-width:50%;*/
		background-color:'.$C[1].';
	}

	.menuBtn.a .cat1>nav{display:block;}
	.menuBtn.a nav>div{display:block;}

	.menuBtn.a nav>a{display:block;float: none !important;}

	.menuBtn>.cat1{
		display:block;
		position: absolute;z-index: 3;
		/*top: 171px;*/
		width:100%;
		height: calc(100% - 50px);
		left:-100%;
		/*background-color:'.$C[1].';*/
		transition:left .5s;
	}

	.menuBtn.a>.cat1{
		left:0px;
		color: #fff;
		/*padding: 10px;*/
	}

	header .menu nav > div:hover > nav{margin-left:20px}
}

@media (min-width:400px){
	.menuBtn.a nav>div{
		padding-left: 30px;
	}
}
@media (min-width:800px){
	.menuBtn.a nav>div{
		padding-left: 15px;
	}
	header .cat1>nav>div{display:inline-block;}
}

';