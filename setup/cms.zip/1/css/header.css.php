<?php	echo '

.logo{display:inline-block}
@media (max-width: 340px){
 header.fix .logo{display:none}
}
header .menu{display:inline-block}

header .logo>img{margin: 20px;height:117px}
header a.logo:hover>img,a.logo:focus>img{filter: hue-rotate(-90deg);;}

header.fix .logo>img{height:42px;margin:5px 20px 5px 5px;}
@media (max-width: 701px){
 header .logo>img{height:42px;margin:5px 20px 5px 5px;}
}

header.fix + main{margin-top:52px} '/* высота шапки узкой страницы */.'
@media (min-width: 700px){
 header.fix + main{margin-top:197px} '/* высота шапки широкой страницы */.'
}

#headerDiv{margin-left:10px}
#headerDiv>.login{
	position: relative;
	display: inline-block;
	vertical-align: middle;
}

header nav{display: flex;/*border-radius:22px;*/background-color:'.$C[1].';}
header nav nav{/*border-radius: 0 22px 22px 22px;*/}
header nav a{display: inline-block;padding: 10px 15px;color:#fff;line-height: 24px;}
header nav a:hover,nav a.cur{
	color:#fff;text-shadow: 0px 0px 1px #ccc;
	background-color:'.$C[1].';/*border-radius: 22px;*/
}
header nav nav a:hover,nav nav a.cur{/*border-radius: 0 22px 22px 22px;*/}
header nav a:hover{background-color:'.$C[2].';}

header nav a:focus,.login a:focus{text-decoration:underline;}

header nav>div{width: fit-content;}

header .menu nav > div > nav {
  display: none;text-align:left;
}

header .menu nav > div:hover > nav {
  display: block;
  position: absolute;
  z-index: 2;
  border: solid 1px #fff;
  margin-left: 30px;margin-right: 5px;
}

.menu>a{vertical-align:middle}

header{
 position: relative;z-index: 2;text-align: center;
 background-color: rgba(256,256, 256, .9);
}

header.fix {
  position: fixed;width: 100%;
  border-bottom-color: #ddd;
}

/*.headerDiv{margin:0 10px}*/

header .login > a {
  display: block;
  text-align: right;
  max-width: 80px;
  padding: 10px 0;
  overflow: hidden;
  white-space: nowrap;
}
header .login svg {
  height: 20px;
  width: 20px;
  vertical-align: middle;
}

header .menu>div{display:inline-block;vertical-align: middle;cursor: default;}

header .menuBtn{
 position:relative;top:1px;left:-5px;display:none;height:36px;width:36px;
 background-color:'.$C[1].';
}
header .loginDiv>ul{
 min-width: 180px;
 border: solid 1px #ddd;
 padding: 5px;
 margin: 0;
 position: absolute;
 background: #fff;
 list-style: none;
 text-align: left;
}
header .loginDiv>ul>li{margin-top: 20px;}

header .login>a:hover>svg,.login>a:focus>svg{transform: scale(1.1);}

@media (min-width: 701px){
 header .menu{
  background-color:'.$C[1].';
  width: fit-content;
  margin: auto;
  /*border-radius: 20px;*/
 }

 header .logo{display:block;width: fit-content;margin:auto;}
 header.fix .logo{display:none}

 header .login>a,.lang>a{color:#fff}
 header .login>a:hover,.lang>a:hover{color: #fff;text-shadow: 0px 0px 1px #ccc;}
}


@media (min-width: 900px){
 header.fix .logo{display:inline-block}
}

@media (max-width: 700px){
	header .menuBtn{display: inline-block;/*border-radius:10px;*/}
	header .menuBtn:hover{opacity:.7}
	header .menuBtn+div{
		position: absolute;top: 50px;width:0;left:5%;
		opacity:0;overflow-x:clip;
		transition:all .2s;
	}
	header .menu.a > .menuBtn+div{width:90%;opacity:1;}
	header .menu nav{display:block}
}
	header .menuBtn::before{
		content:"";position:absolute;top:10px;left:5px;
		display:block;height:15px;width:25px;
		border:solid 1px #fff;
		border-width:1px 0 1px 0;
		transition: all .2s;
		z-index:0;
	}
	header .menuBtn::after{
		content:"";position:absolute;top:18px;left:5px;
		display:block;height:1px;width:25px;
		border-top:solid 1px #fff;
		transition: all .2s;
	}
	header .menu.a>.menuBtn::before{
		height:0px;border-bottom-width:0;
		top:18px;
		transform:rotate(-45deg);
	}
	header .menu.a>.menuBtn::after{
		top:18px;
		transform:rotate(45deg);
	}
/*
	.menuBtn:hover::before{border-width:2px 0 2px 0}
	.menu.a .menuBtn:hover::before{border-width:2px 0 0px 0}
	.menuBtn:hover::after{border-width:2px 0 0px 0}
*/

#arrowUp {
  position: fixed;
  top: -40px;
  right: 2px;
  transition: all .5s;
  font-size: 200%;
  color: #fff;
  text-shadow: -1px -1px 3px #000;
}
#arrowUp.a{top:52%}
#arrowUp:hover{text-shadow: 1px 1px 3px #000;}

';