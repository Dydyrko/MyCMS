<?php /* для admin.php */	echo '
body{
	font-family: "PT Sans", Trebuchet MS, Helvetica, sans-serif;
	font-size:16px;
	color: #000;
}

*{box-sizing: border-box;outline:none}

html,body{height:100%;margin:0;padding:0}

p{margin:0 0 1em 0}

fieldset{border:solid 1px '.$C[1].';}
legend{color:'.$C[1].'}

input:focus,button:focus{border-color:#aaf}

input[type=checkbox].v{display:none}'	/* чек-бокс птичкой шрифта в квадрате */.'
input[type=checkbox].v+a::before{
	content:"";display:inline-block;vertical-align:middle;width:20px;height:20px;
	border:solid 1px #ddd;margin-right:5px;background-color: #fff;
}
input:checked.v+a::before{
	content:"✓";'	/* https://www.toptal.com/designers/htmlarrows/symbols/ */.'
	text-align:center;font-size:24px;line-height:16px;
	/*font-weight:bold;*/
	color:'.$C[2].';
}
input:checked.v+a{color:'.$C[2].';}

input[value="2"]:checked.v+a::before{content:"\2606" !important;}'	/* star */.'
input[value="-1"]:checked.v+a::before{content:"\2716" !important;}'	/* Heavy Multiplication X */.'

.noselect{
	-webkit-user-select: none;
	-ms-user-select: none;
	user-select: none;
}

.clear{display:block !important;clear:both}

/*h1,h2,h3{margin:0;font-weight:normal}*/

h1{
	font-family: "Russo One";font-size:92px;font-weight:normal;margin:0 0 0 70px;
	-webkit-text-stroke: 1px #777;
}
@media (max-width: 800px){
	h1{font-size:30px;text-align:center;margin:0}
}


small{color:#999}
'	/* линия прогресса аякс - внизу страницы */.'
progress{display:block;width:calc(100% - 10px);height:14px;overflow:hidden;position:fixed;z-index:9;bottom:1px;left:0;transition:bottom .5s;}
progress[value="0"]{bottom:-50px}

a{
	text-decoration:none;
	color:'.$C[1].';cursor:pointer;
	-moz-user-select: none;
	-webkit-user-select: none;
	-ms-user-select: none;
	user-select:none;
}
div[contenteditable="true"] a{
	-moz-user-select: initial !important;
	-webkit-user-select: initial !important;
	-ms-user-select: initial !important;
	user-select:initial !important
}

a:hover{color:'.$C[2].';text-decoration:none}

a.w{color:#fff}
a.w:hover{color:'.$C[1].'};

/* подсветка строк */
	.highLighting dt:hover,.highLighting dd:hover,.highLighting li:hover,.highLighting tr:hover{background-color:#ffa}

div:fullscreen{background-color:#fff !important}
div:moz-fullscreen{background-color:#fff !important}

img{max-width: 100%;vertical-align:middle}

.sym{font-size:32px;line-height:0;vertical-align:middle}
.sym.exit{font-size:18px}
.sym.mailLog{font-size:28px}
.sym.editMode{border-bottom: solid 1px #ddd}
a.jsMode{border-bottom: solid 1px #ddd;height: 28px;display: inline-block}
.sym.site::before{content:"🏠";font-size: 26px;position: relative;top: -3px;opacity: .6;}
.sym.site:hover::before{opacity:1;}
.cache{display: inline-block;vertical-align: middle;line-height: 14px;font-size: 14px;text-align: center;}

.sitemap,
.testFiles
{
	display: inline-block;vertical-align:middle;
	font-size:0
}

:-moz-placeholder {
    color: #333030;
    font-weight: 300;
    font-size: 80%;
    -webkit-transition: all .1s ease-in-out;
    transition: all .1s ease-in-out;
}
::-moz-placeholder {
    color: #333030;
    font-weight: 300;
    font-size: 80%;
    -webkit-transition: all .1s ease-in-out;
    transition: all .1s ease-in-out;
}
:-ms-input-placeholder {
    color: #333030;
    font-weight: 300;
    font-size: 80%;
    -webkit-transition: all .1s ease-in-out;
    transition: all .1s ease-in-out;
}
:focus::-webkit-input-placeholder {
    color: #aaa;
}
:focus::-moz-placeholder {
    color: #aaa;
}
:focus:-moz-placeholder {
    color: #aaa;
}
:focus:-ms-input-placeholder {
    color: #aaa;
}

select{
	background:#fff url(/i/V.svg) no-repeat right center;padding-right: 20px;
	border:solid 0 #ccc;border-bottom-width:1px;
	font-family: inherit;font-size: 100%;
	cursor:pointer;
}

select::-ms-expand {
    display: none;
}
select {
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
}
option[selected]{background-color:#ffd;}
optgroup:empty{display:none}

textarea{resize:vertical;}

#content{
	resize: both;overflow: auto;
	display:inline-block;vertical-align:top;border:solid 1px #bbb;padding:5px;background-color:#fff
}
#content:empty{display:none !important;}

.ajxSibling{'	/* cat1.php */	.'
	position:relative;z-index:1;
	background-color:#fff;box-shadow:0 0 5px #777 inset;
	padding:20px 10px 5px 10px;margin:5px 5px 5px 25px
}

dl.cat{
	margin-top:15px;
	display: inline-block;
	border: solid 1px #bbb;border-width:0 1px 1px 0;
	margin-right: 5px;
}
.ajxSibling dl.cat{border: none;margin-right: 0;}
dl.cat>dd{margin:0 0 15px 0;word-spacing:20px}
dl.cat dt{position:relative;border-bottom:solid 1px #bbb;padding: 2px 0;}
dl.cat dt:last-child{border:none}

.cat a.debug{
	font-size: 9px;
	vertical-align: top;display: inline-block;margin-top: 4px;
	border-bottom: solid 1px #ddd;height: 18px;
}
.cat a.debug::before{
	width:10px !important;height:10px !important;margin-right:2px !important;
	font-size: 15px !important;line-height: 8px !important;
}
.cat .files{display: inline-block;width:30px;text-align:center}
.refresh:before{
	content:"\0021BB";
	font-size:25px;line-height: 14px;
	margin-right:5px;vertical-align: middle;
}
tt.sym{font-size:25px;vertical-align:middle}

.catEdit{
	display: inline-block;vertical-align: top;
	width:calc(100% - 230px);min-width:110px;
}
small.parentCat{background-color: #fff;padding: 0 5px;border: solid 1px #ccc;border-bottom: none;position: relative;bottom: -2px;}
small.parentCat+div{background-color: #fff;border: solid 1px #ccc;margin-bottom: 5px;padding-bottom: 1px;}
div.upload{
	display:inline-block;position:relative;min-width: 120px;padding:5px;
	border:outset 1px #ccc;border-radius:5px;background-color:#eee;text-align:center;
}
div.upload>input{opacity:0;position:absolute;width:100%;top:0;left:0;bottom:0;cursor:pointer}

.psw input{
	height: 40px;
	padding-left: 31px;margin-bottom: 10px;
	width: 100%;
}
	.psw{position:relative}
	.psw:hover{cursor:pointer}
	.psw::before{
	    content: "";
	    display: block;
	    position: absolute;z-index: 1;
	    top: 10px;
	    left: 5px;
	    width: 20px;
	    height: 20px;
	    background: url(/i/cat/-10/hide.svg) no-repeat center /cover;
	}
	.psw.t::before{
	    background-image: url(/i/cat/-10/view.svg);
	}
	.a>.psw::after {
		content: "?";
		position: absolute;z-index: 1;
		top: 10px;
		right: 0;
		padding: 0 5px;
		color:green;
	}
	img[alt="Captcha"]{width: 175px;cursor: pointer;}
	input[name="captcha"]{width:90px !important;margin-left:5px;text-align:center;}

ol[data-dir]>li{clear:both}'/* список файлов */.'
ol[data-dir]>li>tt{float: right;font-size: 11px;margin-left: 1em;}

';