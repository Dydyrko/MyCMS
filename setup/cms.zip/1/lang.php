<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

echo
'<div class=lang onclick="
	var e=event.target,m=firstChild,n=lastChild;
	if(e.parentNode.dataset.a || e.parentNode.dataset.v){e=e.parentNode}
	if(e.dataset.a){
		var i=n.firstChild;
		while(i){i.style.display=(i.dataset.v==e.dataset.a?\'none\':\'\');i=i.nextSibling}
		n.style.height=(n.offsetHeight>2?0:n.scrollHeight+\'px\')
	}else if(e.dataset.v){
		location.href=e.dataset.h
	}
">'
	.'<a data-a='.$lang.'><img src="/i/'.$lang.'.png"> '.strtoupper($lang).'</a>'
	.'<ul style="overflow:hidden;height:0;background-color:#fff;transition:all .5s">';

	foreach($Langs as $i=>$v){
		echo
		'<li data-v='.$v.' data-h="/'
			.($i?$v.'/':'')
			.($_GET['p']?sUrl($_GET['p'],'',$v):'')
			.'"><img src="/i/'.$v.'.png" alt="'.$v.'"> '.strtoupper($v);
	}

	echo
	'</ul>'
.'</div>';