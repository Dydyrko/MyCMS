<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(isset($_POST['add'])){	//добавить вложенные страницы в режиме редактирования
	$q='select count(*) as c from cat where parent='.$_POST['pubs'];	//список статей
	$row=DB::f(DB::q($q));
	$c=$row['c'];
	$d=date('Y-m-d H:i:s');

	$A=explode("\n",$_POST['add']);
	foreach($A as $i=>$v){
		if($v!=''){
			$v=DB::esc($v);
			$q='insert into cat set d="'.$d.'",parent='.$_POST['pubs']
			.',name'.($lang==$Langs[0]?'':'_'.$lang).'="'.DB::esc(trim($v)).'",v=0,final=0,owner='
			.(isset($_SESSION['user']['id'])?$_SESSION['user']['id']:0)	//если dev
			.',ord=IFNULL((select max(ord)+1 from cat A where A.parent='.$_POST['pubs'].'),1)';
			//echo '<li>'.$q;				
			DB::q($q);
			$id=DB::insert_id();
			if($id){
				$c++;
				$q='update cat set c='.$c.' where id='.$_POST['pubs'];DB::q($q);
				$q='insert into url set text="new",id='.$id;DB::q($q);
				echo
				'<div>'
					.$id.' <a onclick="ajx(event,\'catEdit\','.$id.',nextSibling,jsAppend(\'translit\'))">'.$v.'</a><div></div>'
				.'</div>';
			}else{echo DB::info();}
			

		}
	}
	exit;
}

if(empty($where)){$where='';}
/*
if(empty($ord)){$ord='d desc';}
if(empty($w)){$w=320;}
if(empty($z)){$z='';}
*/
if(!isset($LstParam)){$LstParam=array();}
if(empty($LstParam['ord'])){$LstParam['ord']='d desc';}
if(empty($LstParam['w'])){$LstParam['w']=320;}
if(empty($LstParam['h'])){$LstParam['h']=0;}
if(!isset($LstParam['z'])){$LstParam['z']='';}


require $root.'/1/pubsF.php';
pubs($_POST['pubs'],$where);