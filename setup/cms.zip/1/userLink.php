<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$uid=intval($_GET['userLink']);
$q='select mail'	//mail
.','.DB::qL('name')
//.','.DB::qL('meta')	//должность
.',new'		//временный пароль
.',img,v,final from cat join person on cat.id=person.id where parent=-9 and cat.id='.$uid;
$r=DB::q($q);
if(DB::num_rows($r)){
	$row=DB::f($r);
	$t='<!DOCTYPE html><title>'.$Conf['TITLE'].'</title><p>'.$Conf['TITLE'].'<h1>New password</h1>';
	if($row['new']==''){exit($t.'<p>Error: the temporary link has already been used');}
	if(!password_verify($_GET['c'],$row['new'])){exit($t.'<p>Error: password is not verified for temporary link');}

	if(empty($_COOKIE['PHPSESSID'])){
		session_set_cookie_params([
			'lifetime' => 0,
			'path' => '/',
			'domain' => $_SERVER['HTTP_HOST'],
			'secure' => false,
			'httponly' => false,
			'samesite' => 'strict'
		]);
		session_start();
	}
	$_SESSION['user']['id']=$uid;
	$_SESSION['user']['name']=$row['name'];
	//$_SESSION['user']['meta']=$row['meta'];	//должность
	$_SESSION['user']['img']=$row['img'];
	$_SESSION['user']['v']=$row['v'];	//статус
	$_SESSION['user']['mail']=$row['mail'];
	$final=$_SESSION['user']['final']=$row['final'];
	$q='update person set new="" where id='.$uid;DB::q($q);
	echo '<script>history.replaceState(null,null,"/");</script>';
	//require '1/user.php';
	$_GET['p']=$uid;
	$Page=array();
	$Page['catName']=$catName=$row['name'];
	$catImg='';
	$Page['parent']=$parent=-9;	//Регистрация

	$_SESSION['user']['newPsw']=1;
}