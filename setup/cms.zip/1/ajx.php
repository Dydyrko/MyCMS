<?php	//подключается в index.php при $_GET['ajx']

if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';exit('404');};

if(strpos($_SERVER["HTTP_REFERER"],$_SERVER["SERVER_NAME"])===false){exit('HTTP_REFERER='.$_SERVER["HTTP_REFERER"]);}	//аякс в пределах домена: только при запросе с этого же сайта

if(!empty($_POST['lang'])){$lang=$_POST['lang'];}	//способ указания языка - если URL-способ (/ru/) не применим
if(empty($lang)){exit('<a href=/>lang? (ajx)</a>');}

$first_post=reset($_POST);
$key=key($_POST);

//$key=array_key_first($_POST);	//вариант при php version >= 7.3.0

if(
	in_array(
		$key,
		array(
			'login','reg','cat','cat1','catAdd','catDel',
			'catEdit','editMode','editBar','files','testFiles',
			'dblog','log','sitemap_','sql','css'
		)
	) && file_exists($root.'/1/core/'.$key.'.php')
){
	require $root.'/1/core/'.$key.'.php';
}else if(file_exists($root.'/1/'.$key.'.php')){
	require $root.'/1/'.$key.'.php';
}else{
	var_dump($_POST);
}


