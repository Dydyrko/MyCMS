<?php	//подключается в index.php при $_GET['ajx']

if(empty($root) || empty($_SERVER["HTTP_REFERER"])){$a=0;require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';exit('404');};

if(strpos($_SERVER["HTTP_REFERER"],$_SERVER["SERVER_NAME"])===false){exit('HTTP_REFERER='.$_SERVER["HTTP_REFERER"]);}	//аякс в пределах домена: только при запросе с этого же сайта

if(!empty($_POST['lang'])){$lang=$_POST['lang'];}	//способ указания языка - если URL-способ (/ru/) не применим
if(empty($lang)){exit('<a href=/>lang? (ajx)</a>');}

$first_post=reset($_POST);		//вариант для всех версий PHP
$key=key($_POST);
	//$key=array_key_first($_POST);	//вариант при php version >= 7.3.0

/* =>	для постепенного перехода к указанию папки в $key */
if(
	in_array(
		$key,
		array(
			'login','reg','cat','cat1','catAdd','catDel',
			'catEdit','editMode','editBar','files','testFiles',
			'dblog','sql','css'
		)
	) && file_exists($root.'/1/core/'.$key.'.php')
){
	require $root.'/1/core/'.$key.'.php';
	exit;
}
/* <= */

$A=explode('_',$key);	//core_login
if(isset($A[1])){
	$p=$A[0].'/';	//папка
	$_POST[$A[1]]=$_POST[$key];
	unset($_POST[$key]);
	$key=$A[1];
}else{
	$p='';
}
$file=$root.'/1/'.$p.$key.'.php';
if(file_exists($file)){
	require $file;
}else{
	var_dump($_POST);
}

/*
if(
	in_array(
		$key,
		array(
			'login','reg','cat','cat1','catAdd','catDel',
			'catEdit','editMode','editBar','files','testFiles',
			'dblog','log','sitemap_','sql','css'
		)
	) && file_exists($root.'/1/core/'.$key.'.php')
){
	require $root.'/1/core/'.$key.'.php';
}else if(file_exists($root.'/1/'.$key.'.php')){
	require $root.'/1/'.$key.'.php';
}else{
	var_dump($_POST);
}
*/

