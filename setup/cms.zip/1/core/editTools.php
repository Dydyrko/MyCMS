<?php
if(__file__==$_SERVER['SCRIPT_FILENAME']){header($_SERVER["SERVER_PROTOCOL"].' 404 Not Found');exit('404 Not found');};
?>
<select onchange='
 if(selectedIndex>0){
  document.execCommand("formatBlock",false,options[selectedIndex].text);
  selectedIndex=0
 }
' title="Указать имя блочного элемента, содержащего текст под курсором.
• Изначально при вводе в пустое поле создаётся элемент DIV с вводимым текстом и [Enter] будет создавать элемент BR (новая строка в том же блоке).
• Если первому блоку указать тип DIV или P, то [Enter] будет создавать такой же блок, а [Shift+Enter] будет создавать элемент BR.
">
	<option>Block
	<option title="блок">DIV
	<option title="параграф">P
	<option title="Список определений">DT
		<option title="значение списка определений">DD
	<option>H1<option>H2<option>H3<option>H4<option>H5<option>H6
</select>
•
<input type=button onclick='document.execCommand("superscript")' value=suP title=SUP>
<input type=button onclick='document.execCommand("subscript")' value=SUb title=SUB>
<input type=button onclick='
	var s=document.getSelection(),t;
	//console.log(s);
	if(s.anchorNode.data!="́"){t=s+"́";document.execCommand("insertHTML",false,t)}
' value="á" title='Добавить ударение букве перед курсором'>
<input type=button onclick='
	var s=document.getSelection(),t;
	if(s.anchorNode.data!="&shy;"){t=s+"&shy;";document.execCommand("insertHTML",false,t)}
' value="shy" title='Добавить мягкий перенос (soft hyphen)'>
<input type=button onclick='document.execCommand("insertHorizontalRule")' value=HR title="insertHorizontalRule">
•
<input type=button onclick='document.execCommand("Bold")' value=B title=Bold>
<input type=button onclick='document.execCommand("Italic")' value=I title=Italic>
<input type=button onclick='document.execCommand("Underline")' value=U title=UnderLine>
<input type=button onclick='document.execCommand("strikeThrough")' value="S" title=strikeThrough>
•
<input type=button onclick='document.execCommand("JustifyLeft")' value=&larr; title='Выровнять влево'>
<input type=button onclick='document.execCommand("JustifyFull")' value="&harr;" title='JustifyFull'>
<input type=button onclick='document.execCommand("JustifyCenter")' value=C title='Выровнять по центру'>
<input type=button onclick='document.execCommand("JustifyRight")' value=&rarr; title='Выровнять вправо'>
•
<input type=button onclick='document.execCommand("InsertUnorderedList")' value=UL title='Список'>
<input type=button onclick='document.execCommand("InsertOrderedList")' value=OL title='Нумерованный список'>
•
<input type=button onclick='document.execCommand("Indent")' value=|&rarr; title='Увеличить отступ'>
<input type=button onclick='document.execCommand("Outdent")' value=&larr;| title='Уменьшить отступ'>
•

<input type=button onclick='imgTool()' value="IMG" title='Добавить/изменить картинку'>
•
<input type=button onclick='
	var s=window.getSelection(),	//document или window
	A=s.anchorNode.parentNode.attributes,
	t1=A[0],t2=A[1],v,t;
	if(s.type!="Range"){alert("Прежде надо выделить текст");return}
	if(t1){t1="href=\""+t1.value+"\""}else{t1="href=\"/\"";}
	if(t2){t2="target=\""+t2.value+"\""}else{t2="target=\"_blank\"";}
	v=t1+" "+t2;
	t=prompt(s+"\n\nУкажите атрибуты",v);
	if(t===null){
		return
	}else if(t==""){
		t=s
	}else{
		t="<a "+t+">"+s+"</a>"
	}
	//console.log("t",t);
	document.execCommand("insertHTML",false,t)
' value="A" title='Добавить ссылку выделенному тексту или удалить (при пустых атрибутах)'>

<select onchange='
 if(selectedIndex>0){
  document.execCommand("FontName",false,options[selectedIndex].text);
  selectedIndex=0
 }
'><option>Font<option>Times<option>Georgia<option>Arial<option>Tahoma
<option>Verdana<option>Calibri<option>Courier New<option>Monospace
<option>Impact</select>

<select onchange='
 if(selectedIndex>0){
  document.execCommand("FontSize",false,options[selectedIndex].text);
  selectedIndex=0
 }
'><option>Size<option>1<option>2<option>3<option>4<option>5<option>6<option>7</select>

<select onchange='
 if(selectedIndex>0){
  document.execCommand("BackColor",false,options[selectedIndex].value);
  selectedIndex=0
 }
'><option>BackColor
<option value=black style=background-color:black;color:white>black
<option value=white>white
<option value=#0000FF style=background-color:blue;color:white>синий
<option value=green style=background-color:green;color:white>green
<option value=red style=background-color:red;color:white>red
<option value=yellow style=background-color:yellow;color:black>yellow
<option value=gray style=background-color:gray;color:white>gray
</select>

<select onchange='
 if(selectedIndex>0){
  document.execCommand("ForeColor",false,options[selectedIndex].value);
  selectedIndex=0
 }
'><option>Сolor
<option value=black style=background-color:black;color:white>black
<option value=white>white
<option value=#0000FF style=background-color:blue;color:white>синий
<option value=green style=background-color:green;color:white>green
<option value=red style=background-color:red;color:white>red
<option value=yellow style=background-color:yellow;color:black>yellow
<option value=gray style=background-color:gray;color:white>gray
</select>
•
<input type=button onclick='document.execCommand("SelectAll")' value=All title='Выделить всё'>
<input type=button onclick='document.execCommand("RemoveFormat")' value=X title='Удалить форматирование'>