<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$gzip=1;	//1 или 0 (сжимать или нет)
//unset($t);
$file=$root.'/1/tmp';
if(!file_exists($file)){mkdir($file);}
$file.='/'.(empty($subhost)?'':$subhost.'_').'sitemap.txt';
if(file_exists($file)){
	$time=time();
	$t=$time-filemtime($file);
}else{$t=0;}

header('Content-Type: application/xml');
if($t>0 && $t<3600 && !isset($_GET['w'])){
	readfile($file);
	exit;
}else{
	$p='https://'.$_SERVER["SERVER_NAME"].'/';
	
	require_once $root.'/1/core/class.db.php';
	DB::getInstance();
	$cL=count($Langs);
	
	$A=array();
	$A[]='<?xml version="1.0" encoding="UTF-8"?>'."\n";
	$A[]='<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"'
	.($cL>1?' xmlns:xhtml="http://www.w3.org/1999/xhtml"':'')	//если языков больше 1, то мультиязычная карта сайта
	.'>'."\n"
		.'<url><loc>'.$p.'</loc>';
		if($cL>1){	//языков больше 1
			$B=array();	//проверка наличия текста языка главной страницы
			for($i=1;$i<$cL;$i++){$B[]='text_'.$Langs[$i];}
			$q='select '.implode(',',$B).' from url where id=-8';	//home
			$row=DB::f(DB::q($q));
			for($i=1;$i<$cL;$i++){
				if($row['text_'.$Langs[$i]]==''){continue;}	//пропустить страницу без текста
				$A[]="\n".'<xhtml:link rel="alternate" hreflang="'.$Langs[$i].'" href="'.$p.$Langs[$i].'/" />';
			}
			$A[]="\n".'<xhtml:link rel="alternate" hreflang="'.$Langs[0].'" href="'.$p.'" />';	//основной язык — без его указания
			$A[]="\n".'<xhtml:link rel="alternate" hreflang="x-default" href="'.$p.'" />';
		}
	$A[]="\n".'</url>'."\n";
	
	$q='select cat.id,url';
	if($cL>1){	//языков больше 1
		for($i=1;$i<$cL;$i++){$q.=',url_'.$Langs[$i];}
	}
	$q.=' from cat join url on cat.id=url.id where'
	.' v=1'
	.' and url<>""'
	.' and LEFT(name,1)<>""'	//имя не с пробела
	.' order by id';
	$r=DB::q($q);
	$i=0;	//COUNTERS
	$j=0;	//для томов сайтмапа
	while($row=DB::f($r)){
		$i++;
	 	$A[]='<url><loc>'.$p.$row['url'].'</loc>';
		if($cL>1){
			$b=0;	//признак наличия страницы на не основном языке
			for($i1=1;$i1<$cL;$i1++){
				if($row['url_'.$Langs[$i1]]){
					$A[]="\n".'<xhtml:link rel="alternate" hreflang="'.$Langs[$i1].'" href="'.$p.$Langs[$i1].'/'.$row['url_'.$Langs[$i1]].'" />';
					$b=1;
				}
			}
			if($b){
				$A[]="\n".'<xhtml:link rel="alternate" hreflang="'.$Langs[0].'" href="'.$p.$row['url'].'" />';
				$A[]="\n".'<xhtml:link rel="alternate" hreflang="x-default" href="'.$p.$row['url'].'" />'."\n";
			}
		}
		$A[]='</url>'."\n";
		if($i==40000/$cL){	//50000 max
			$dir=$root.'/sitemap';
			if(!file_exists($dir)){mkdir($dir);}
			$dir.='/';
			$j++;
			$A[]='</urlset>';
			if($gzip){
				$s=implode('',$A);
				$gz=gzencode($s, 9);
				file_put_contents($dir.$j.'.xml.gz',$gz);
			}else{
				file_put_contents($dir.$j.'.xml',$A);
			}
			$A=array();
			$A[]='<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";
			$i=0;
		}
	}
	$A[]='</urlset>';
	if($j){				//$j>0: есть тома
		if(count($A)>2){	//есть ветки в urlset
			$j++;
			if($gzip){
				$s=implode('',$A);
				$gz=gzencode($s, 9);
				file_put_contents($dir.$j.'.xml.gz',$gz);
			}else{
				file_put_contents($dir.$j.'.xml',$A);
			}
		}

		while(file_exists($dir.($j+1).'.xml'.($gzip?'.gz':''))){
			unlink($dir.($j+1).'.xml'.($gzip?'.gz':''));
			$j++;
		}

		$A=array();
		$A[]='<?xml version="1.0" encoding="UTF-8"?>'
			.'<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'."\n";
			for($i=0;$i<$j;$i++){
				$A[]='<sitemap><loc>'.$p.'sitemap/'.($i+1).'.xml'.($gzip?'.gz':'').'</loc></sitemap>';
			}
		$A[]='</sitemapindex>';
	}
	
	file_put_contents($file,$A);
	echo implode('',$A);
}


