<?php	//редактирование текстового поля $_POST['edit'] на странице $_POST['catEdit'] с возможностью подключения CKEDITOR
	//использовалось в эридоне для редактирования трёх разделов прямо на странице вакансии

if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

	$_POST['edit']=DB::esc($_POST['edit']);
	$q='select '.DB::qL($_POST['edit']).' from cat where id='.intval($_POST['catEdit']);
	$row=DB::f(DB::q($q));
	echo
	'<a onclick="'
		.'var e=g(\'ckEditor\');'
		.'if(!e){'
			.'var n=document.createElement(\'SCRIPT\');'
			.'n.src=\''.$ckeJS.'\';'
			.'n.id=\'ckEditor\';'
			.'n.onload='
			.'function(){CKEDITOR.replace('
				.'\''.$_POST['edit'].$_POST['catEdit'].'\','	//имя textarea составное из имени колонки и cat.id
				.'{language: \''.$lang.'\',uiColor: \'#bbbbbb\'}'
			.')};'
			
			.'document.head.appendChild(n)'
		.'}else{'
			.'CKEDITOR.replace('
				.'\''.$_POST['edit'].$_POST['catEdit'].'\','
				.'{language: \''.$lang.'\',uiColor: \'#bbbbbb\'}'
			.')'
			
	.'};style.display=\'none\'">CKEditor</a>'
	.'<textarea style="width:100%" name="'.$_POST['edit'].$_POST['catEdit'].'"'
		.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}"'
	.'>'.$row[$_POST['edit']].'</textarea>'
	.'<input type=button value="Зберегти" style="width:100%" onclick="'
		.'var e=form.elements[\''.$_POST['edit'].$_POST['catEdit'].'\'];'
		.'if(typeof(CKEDITOR)!=\'undefined\' && CKEDITOR.instances && CKEDITOR.instances.'.$_POST['edit'].$_POST['catEdit'].'){e.value=CKEDITOR.instances.'.$_POST['edit'].$_POST['catEdit'].'.getData()}'
		.'if(e.dataset.i==e.value.hashCode()){return}'
		.'e.parentNode.style.backgroundColor=\'yellow\';'
		.'ajx(event,\'catEdit\',\''.$_POST['catEdit'].'&update=&'.$_POST['edit'].'=\'+encodeURIComponent(e.value),e,\'div.dataset.i=div.value.hashCode();div.parentNode.style.backgroundColor=\\\'\\\'\',1)'
	.'">';