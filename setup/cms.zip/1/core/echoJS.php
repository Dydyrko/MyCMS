<?php	//index.php при отсутствии скрипта /js/ вывести из /1/js/ с обработкой или без
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$t=substr($_SERVER["REQUEST_URI"],1,$n-1);	//='js/имя_файла'
$file='1/'.$t.'.js';				//оригинальный файл в папке /1
if(!file_exists($file)){header('HTTP/1.1 404 Not found');exit(404);}

header('Expires: '.gmdate('D, d M Y H:i:s', date('U')+3600*24).' GMT');
header('Cache-Control: public');
header("Content-type: text/javascript; charset: UTF-8");
header('MicroSecunds: '.number_format((microtime(true)-MICRO_TIME_START)*1000000,0,',',''));

if(empty($_COOKIE['js'])){		//вывод скрипта без комментариев и лишних пробелов
	$A=file($root.'/'.$file);
	foreach($A as $i=>$v){
		$A[$i]=preg_replace('/\s\/\/.*$/','',$A[$i]);	//перед комментарием "//" должен быть пробельный символ
	}							// (табуляция или пробел) — отличить от "http://"
	$s=implode('',$A);
	$s=str_replace("\n",' ',$s);
	$s=preg_replace('/\/\*(.*?)\*\//', '', $s);		/*комментарии*/
	$s=preg_replace('/\s+/',' ', $s);			//пробелы на один
	$s=str_replace(array('{ ',' {'),'{',$s);
	$s=str_replace(array('} ',' }'),'}',$s);
	$s=str_replace(array('( ',' ('),'(',$s);
	$s=str_replace(array(') ',' )'),')',$s);
	$s=str_replace('; ',';',$s);
	$s=str_replace(', ',',',$s);
	$s=str_replace('= ','=',$s);
	$s=str_replace('[ ','[',$s);
	$s=str_replace(' ]',']',$s);
	$s=str_replace('\ ','',$s);	//'убрать экран (\n стал пробелом после замен)
	echo $s;
}else{
	readfile($file);	//вывод наглядного js
}