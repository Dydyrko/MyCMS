<?php	//Смена пароля
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if($lang=='uk'){
	$L=array(
		'Помилка повтору пароля',
		'Значення полів нового та колишнього паролів збігаються',
		'Виконано',
		'Невірний колишній пароль'
	);
}else if($lang=='ru'){
	$L=array(
		'Ошибка повтора пароля',
		'Значения полей нового и прежнего паролей совпадают',
		'Выполнено',
		'Неверный прежний пароль'
	);
}else{
	$L=array(
		'Password repeat error ',
		'The values of the fields of the new and old passwords are the same',
		'Done',
		'Wrong old password'
	);
}

if($_POST['psw']!=$_POST['psw1']){exit('<font color=red>'.$L[0].'</font>');}
if(
	empty($_SESSION['user']['newPsw'])	//не форма нового пароля
	&& $_POST['psw']==$_POST['psw0']	//проверка введённого существующего пароля
){exit('<font color=red>'.$L[1].'</font>');}
$q='select psw from person where id='.$_SESSION['user']['id'];
$row=DB::f(DB::q($q));
if(
	!empty($_SESSION['user']['newPsw'])		//новый пароль — прежний не проверяем
	|| password_verify($_POST['psw0'],$row['psw'])	//проверка ввода прежнего пароля	
){
	$_POST['psw']=password_hash($_POST['psw'],PASSWORD_BCRYPT);
	$q='update person set psw="'.$_POST['psw'].'" where id='.$_SESSION['user']['id'];DB::q($q);
	echo '<font color=green>'.$L[2].'</font>';
}else{exit($L[3]);}