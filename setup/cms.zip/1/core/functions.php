<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

function catName($id){
	$q='select '.DB::qL('name').' from cat where id='.$id;
	$row=DB::f(DB::q($q));
	return $row['name'];
}

function mailTest($mail){
	$A=explode('@',$mail);$t=-1;
	if(count($A)==2){$t=getmxrr($A[1],$M);}
	//var_dump($M);	//массив найденных в DNS записей MX,
	return $t;
}
function LangArray($cat){	//возвращается массив словаря. adt=последовательность пар строк #ключ/значение
	$q='select '.DB::qL('adt').' from cat where id='.$cat;
	$row=DB::f(DB::q($q));
	$A=explode("\n",$row['adt']);$t='';$L=array();
	foreach($A as $v){
		$v=trim($v);
		if(substr($v,0,1)=='#'){$t=substr($v,1);}else{$L[$t][]=$v;}	//$v[0] вызывает E_NOTICE ?
	}
	foreach($L as $i=>$v){
		$L[$i]=implode("\n",$v);
	}
	return $L;
}

function LangTxt($i,$A){
	return isset($A[$i])?$A[$i]:$i;
}

function Month1(){
	global $Month1,$lang;
	if($lang=='ru'){
		$Month1=array('января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря');
	}else if($lang=='en'){
		$Month1=array("January","February","March","April","May","June","July","August","September","October","November","December");
	}else{
		$Month1=array('січня','лютого','березня','квітня','травня','червня','липня','серпня','вересня','жовтня','листопада','грудня');
	}
}

function D1($d='',$t='',$b=0){	//2016-05-12 15:20:30,текст при пустой дате,(1 чтобы не выводить время, 2 чтобы вернуть только дату, 3 вывести год)
	if(empty($d) || intval($d)==0){return $t;}
	global $Month1;
	if(empty($Month1)){Month1();}
	$Y=date('Y');
	$B=explode(' ',$d);	//если  дата-время
	if($b==2){
		return $B[0];
	}else{
		$A=explode('-',$B[0]);
		if(empty($A[2])){return $t;}
		return	intval($A[2]).' '
			.$Month1[$A[1]-1]
			.($Y==$A[0]&&$b!=3?'':' '.$A[0])
			.($b==1 || empty($B[1])?'':' '.substr($B[1],0,5));	//время без секунд
	}
}
function itemCats($id,$A=0){	//для $Crumb в index.php
	if(!$id){return false;}
	if(!$A){$A=array();$A[0]=array();$A[1]=array();}
	$q='select parent,'.DB::qL('name').' from cat where id='.intval($id);
	$row=DB::f(DB::q($q));
	$A[0][]='<a href="/'.sUrl($id).'">'.$row['name'].'</a>';
	$A[1][]=$row['name'];
	//$A[2][]=$id;
	if($row['parent']!=0){
		$A=itemCats($row['parent'],$A);
	}
	return $A;
}
function Crumb(){
	global $parent,$Parent,$Crumb,$pTitle;
	$A=array();
	foreach($Parent as $i=>$v){
		$t=(empty($Parent[$i-1])?$parent:$Parent[$i-1]['id']);
		if(in_array($t,array(-9,-100))){continue;}	//Регистрация,Кабинет - пропустить (персонам в кабинете, товару при отображении категории из истории браузера)
		$A[]=$v['name'];
		$Crumb[]='<a href="/'.sUrl($t).'">'.$v['name'].'</a>';
	}
	if(!empty($A)){$pTitle.=' — '.implode(' — ',$A);}
}
function captcha($id=''){	//id=1 для нового пароля, 2 для регистрации, пусто для авторизации, 3 для обратной связи
	global $lang;
	$s='Please enter the text from the image on the right';
	if($lang=='uk'){$s='Введіть, будь ласка, текст з картинки праворуч';}
	else if($lang=='ru'){$s='Введите, пожалуйста, текст с картинки справа';}
	return
	'<div>'
		.'<input name=captcha type=text title="'.$s.'" placeholder="Captcha" required'
			.' oninput="if(value.length){setCustomValidity(\'\')}"'
			.' oninvalid="this.setCustomValidity(\''.$s.'!\')">'
		.' &larr; '
		.'<img data-i='.time().' data-s="/?img=captcha&id='.$id.'&txt=" src="/?img=captcha&id='.$id.'&txt='.time().'"'
			.' alt="Captcha" title="Captcha picture: push to refresh"'
			.' onclick="dataset.i=dataset.i*1+.1;src=dataset.s+dataset.i">'


	.'</div>';
}
function dblog(){
	global $root,$DbLog;
	$tmp=$root.'/1/tmp';
	if(!file_exists($tmp)){mkdir($tmp);}
	$DbLog[]='';
	file_put_contents($tmp.'/db.txt',implode("\n",$DbLog),FILE_APPEND);
}