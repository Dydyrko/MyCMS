<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

	if(isset($_POST['parentsPre'])){
		//var_dump($_POST);
		$q='update cat set parent='.intval($_POST['parents']).' where id='.intval($_POST['catEdit']);DB::q($q);
		$q='update cat set c=c-1 where id='.intval($_POST['parentsPre']);DB::q($q);
		$q='update cat set c=c+1 where id='.intval($_POST['parents']);DB::q($q);
		echo '<h2>Принадлежность</h2>'
			.'Странице (cat.id = '.$_POST['catEdit'].') изменена принадлежность (cat.parent = '.$_POST['parents']
			.')<br><small>То есть '.($_POST['parents']==0?' страница теперь корневая':'странице указана другая родительская страница').'</small>.';
		exit;
	}
	$Parent=array($_POST['parents']);
	function parent($parent){
		global $Parent;
		$q='select parent from cat where id <> 0 and id='.$parent;
		$row=DB::f(DB::q($q));
		$Parent[]=$row['parent'];
		return $row['parent'];
	}
	$n=$_POST['parents'];
	while($n){$n=parent($n);}
	//var_dump($Parent);

	function catParentOptions($parent,$i=1){
		global $Parent;
		$q='select id,parent,c,'.DB::qL('name').' from cat where id <> 0 and parent='.$parent.' order by ord';
		$r=DB::q($q);
		while($row=DB::f($r)){
			if($row['id']==$_POST['catEdit']){echo '<option disabled style="color:orange">'.$row['name'];continue;}
			echo '<option value='.$row['id'].($row['id']==$_POST['parents']?' selected':'').'>'
				.$row['name'].($row['c']?' ('.$row['c'].')':'')
			.'</option>';
			if($row['c']){
				if(in_array($row['id'],$Parent)){$i++;}
				echo '<optgroup style=margin-left:'.$i.'em>';
			}
				if(in_array($row['id'],$Parent)){				
					catParentOptions($row['id'],$i);
				}
			if($row['c']){echo '</optgroup>';}
		}
	}

	echo '<select onchange="ajx(event,\'catEdit\',\''.$_POST['catEdit'].'&parentsPre='.$_POST['parents'].'&parents=\'+value,\'\')">'
		.'<option value=0>Корень';
		catParentOptions(0);
	echo '</select>';