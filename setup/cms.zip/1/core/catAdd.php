<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};
require $root.'/1/core/permit.php';

$_POST['catAdd']=intval($_POST['catAdd']);
$q='select count(*) as c from cat where parent='.$_POST['catAdd'];
$row=DB::f(DB::q($q));
$c=$row['c'];
$d=date('Y-m-d H:i:s');

if(!empty($_POST['v'])){	
	$A=explode("\n",$_POST['v']);
	foreach($A as $i=>$v){
		if($v!=''){
			$q='insert into cat set d="'.$d.'",parent='.$_POST['catAdd']
			.',name'.($lang==$Langs[0]?'':'_'.$lang).'="'.DB::esc(trim($v)).'",v=0,'
			.'ord=IFNULL((select max(ord)+1 from cat A where A.parent='.$_POST['catAdd'].'),1)';
			DB::q($q);
			$id=DB::insert_id();$c++;
			echo
			'<div>'
				.$id.' <a onclick="ajx(event,\'catEdit\','.$id.',nextSibling)">'.$v.'</a><div></div>'
			.'</div>';

			if($c){$q='update cat set c='.$c.' where id='.$_POST['catAdd'];DB::q($q);}
		}
	}
	exit;
}

if(!empty($_POST['t'])){
	if($lang=='ru'){
		$L=array('Количество вложенных страниц','Cтраниц','Имена новых страниц построчно','Добавить страницы');
	}else if($lang=='uk'){
		$L=array('Кількість вкладених сторінок','Сторінок','Імена нових сторінок рядками','Додати сторінки');
	}else{
		$L=array('Number of subpages','Pages','Names of new pages line by line','Add pages');
	}
	echo '<h2>'.$_POST['t'].'</h2>'
	.'<div>'
		.'<div style=cursor:help title="'.$L[0].'">'.$L[1].': '
			.$c
		.'</div>'.$L[2].':<br>'
		.'<textarea style=width:100%>'
		.'</textarea>'
		.'<input onclick="var v=previousSibling.value;if(v){ajx(event,\'catAdd\',\''.intval($_POST['catAdd']).'&v=\'+encodeURIComponent(v),parentNode)}"'
			.' type=button style="display:block" value="'.$L[3].'">'
	.'</div>';
}