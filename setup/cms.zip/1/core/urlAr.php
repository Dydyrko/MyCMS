<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$catUrl=$catUrlEmpty=array();	//массивы для url и отсутствия url

$catUrlFile=$root.'/1/tmp';
if(!file_exists($catUrlFile)){mkdir($catUrlFile);}
$catUrlFile.='/cache';
if(!file_exists($catUrlFile)){mkdir($catUrlFile);}
$catUrlFile.='/catUrl-'.$lang.'.json';
if(
	1	//1: кэшировать Url, 0: не кэшировать (при отладке)
	&& file_exists($catUrlFile)
){
	$s=file_get_contents($catUrlFile);
	$catUrl=json_decode($s,true);
}
$catUrlStart=$catUrl;

$n=strpos($REQUEST,'?');
if($n===false){			//нет GET
	$t=substr($REQUEST,1);	//строка после первого символа (/)
}else{
	$t=substr($REQUEST,1,$n-1);	//URL раздела (до знака вопроса)
}
if($t!=''){
	if($t=='admin'){
		require $root.'/1/core/admin.php';
		exit;
	}else if($t=='zip'){	//текст в архив
		require $root.'/1/core/zip.php';exit;
	}else{
		$A=explode('/',$t);	//при $t='help/01.htm' (обращение к файлу "01.htm" из файлов "/help/1/*.htm")
		if($A[0]=='help' && isset($A[1])){
			$B=explode('.',$A[1]);
			if($B[1]=='htm'){
				header('Location: /help/?p='.$B[0],true,301);
				exit;
			}
		}
	}

	$t=urldecode($t);
	$s=mb_strtolower($t);
	if($t!=$s){	//не все строчные: направить на исправленный URL
		$t=$s;
		header('Location: /'.($lang==$Langs[0]?'':$lang.'/').$s,true,301);
		exit;
	}

	$q='select id from url where '.urLang().'="'.DB::esc($t).'"';	//функция urLang в sUrl.php
	$r=DB::q($q);
	if(DB::num_rows($r)){	//нашли id
		$row=DB::f($r);
		$catUrl[$row['id']]=$t;
		$_GET['p']=$row['id'];
		$headerStr.='<link rel="canonical" href="https:'.$host.'/'.($lang==$Langs[0]?'':$lang.'/').$t.'">';
		return;
	}else{
		err404();
		exit;
	}
}
if(!empty($_GET['p'])){			//есть id страницы
	if(empty($catUrl[$_GET['p']])){	//пока нет человекопонятного URL 
		$_GET['p']=intval($_GET['p']);
		$q='select '.urLang().' as url from url where '.urLang().'<>"" and id="'.$_GET['p'].'"';
		$r=DB::q($q);
		if(DB::num_rows($r)){	//нашли страницу, объявляем её канонической
			$row=DB::f($r);
			$catUrl[$_GET['p']]=$row['url'];
		}
	}
	if(!empty($catUrl[$_GET['p']])){	//нашли человекопонятный URL странице 
		//$headerStr.='<link rel="canonical" href="/'.($lang==$Lang[0]?'':$lang.'/').$catUrl[$_GET['p']].'">';
		header('Location: /'.($lang==$Langs[0]?'':$lang.'/').$catUrl[$_GET['p']],true,301);
	}else{
		$q='select v from cat where id='.$_GET['p'];	//ищем страницу по id: если нет или не публичная, то 404
		$r=DB::q($q);
		if(DB::num_rows($r)){
			$row=DB::f($r);
			if($row['v']<1 && empty($_SESSION["editMode"])){err404();}
			$headerStr.='<meta name="robots" content="noindex,nofollow">';
		}else{err404();}
	}
}
function err404(){
	require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';
}