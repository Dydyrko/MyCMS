<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

		$q='select a,'.DB::qL('s').' from r where b=0 and r='.$_SESSION['user']['id'];	//Все значения профиля
		$r=DB::q($q);
		$Rs=array();
		while($row=DB::f($r)){$Rs[$row['a']]=$row['s'];}

		$q='select id,'.DB::qL('name').','.DB::qL('adt').' from cat where parent=-92 and v=1 order by ord';	//поля контактов кроме телефонов
		$r=DB::q($q);
		while($row=DB::f($r)){
			echo
			'<div style="display:inline-block;vertical-align:top;margin:15px 20px 0 0">'
				.'<input value="'.(isset($Rs[$row['id']])?$Rs[$row['id']]:'').'"'
				.' onclick="if(!dataset.v){dataset.v=value.hashCode()}"'
				.' onblur="if(value.hashCode()!=dataset.v){style.backgroundColor=\'yellow\';'
				.'ajx(event,\'login\',\''.$_SESSION['user']['id'].'&a='.$row['id'].'&profile=\'+value,this,'
				.'\'div.dataset.v=div.value.hashCode();div.style.backgroundColor=null;notify(\\\'Сохранено «'.$row['name'].'»\\\',txt,0,5)\',1)}"'
				.'>'.($row['adt']?' <a title="'.$row['adt'].'" onclick="Alert(title)" style="position:absolute">?</a>':'')
				.'<div style="color:#aaa;font-size:12px">'.$row['name'].'</div>'
			.'</div>';
		}

		require $root.'/1/core/phones.php';		//телефоны
		phones($_SESSION['user']['id'],-111);

		$q='select '.DB::qL('s').' from r'				//Позиция на карте может быть своя для языка.
		.' where a=-92 and r='.$_SESSION['user']['id'];		//Если понадобится несколько маркеров, можно использовать r.b
		$r=DB::q($q);
		if(DB::num_rows($r)){
			$row=DB::f($r);
		}
		echo
		'<div id="map_canvas" data-lang="'.$lang.'" data-pos="'.(empty($row['s'])?'50.45258823661723, 30.492158802032463':$row['s']).'"'
			.' style="width:100%;height:300px;border:solid 1px #bbbbbb;margin-top:20px"></div>'
		.'<a style="display:none" onclick="var e=previousSibling;ajx(event,\'login\','
			.'\''.$_SESSION['user']['id'].'&a=-92&profile=\'+e.dataset.pos'	//pos в r.s
			.',this,\'div.style.display=\\\'none\\\';notify(\\\'Позиция на карте сохранена\\\',txt,0,5)\',1)">Сохранить позицию маркера</a>';
