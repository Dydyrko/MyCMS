<?php	//Настройки в кабинете
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

		if(!empty($_POST['profile'])){
			$_POST['profile']=intval($_POST['profile']);
		
			if(isset($_POST['uType'])){	//сохранить "Актуальные поля кабинета клиента"
				$_POST['uType']=intval($_POST['uType']);
				if($_POST['checked']!='true'){
						$q='delete from r where b='.$_POST['profile'].' and a=-91 and r='.$_POST['uType'].(empty($subhost)?'':' and c=-'.$curN);
						DB::q($q);
						//echo $q;
				}else{
					$q='insert into r set b='.$_POST['profile'].',a=-91,r='.$_POST['uType'].(empty($subhost)?'':',c=-'.$curN);
					DB::q($q);
					//echo $q;
				}
			}else{	//вставить список значений для выбранного типа клиента
				echo uType($_POST['profile']);
			}
			exit;
		}
		if($lang=='ru'){
			$L=array('Смена пароля'
				,'Прежний пароль'
				,'Кнопка слева — отобразить/скрыть, справа — сгенерировать пароль'
				,'Новый пароль'
				,'До 72 символов'
				,'Повторите пароль'
				,'Применить'
			);
		}else if($lang=='uk'){
			$L=array('Зміна пароля'
				,'Колишній пароль'
				,'Кнопка зліва - відобразити/приховати, праворуч - згенерувати пароль'
				,'Новий пароль'
				,'До 72 символів'
				,'Повторіть пароль'
				,'Застосувати'
			);
		}else{
			$L=array('Change Password'
				,'Old password'
				,'Button on the left - show/hide, on the right - generate password'
				,'New Password'
				,'Up to 72 characters'
				,'Repeat password'
				,'Apply' 
			);
		}
		echo	//Смена пароля
		'<fieldset style="display:inline-block;vertical-align:top;width: 250px;"><legend>'.$L[0].'</legend>'
			.'<form onsubmit="return ajxFormData(event,this,\'form.reset()\',lastChild)"
				onclick="
				var e=event.target,n;
				if(e.className.indexOf(\'psw\')>-1){
					if(event.layerX<50){
						n=e.firstChild;
						if(n.type!=\'text\'){
							n.type=\'text\';e.className=\'psw t\'
						}else{
							n.type=\'password\';e.className=\'psw\'
						}
					}else{
						n=e.firstChild;
						n.value=randomPassword();n.type=\'text\';e.className=\'psw t\'
					}
				}
				">'
				.'<input name=login value='.$_GET['p'].' type=hidden><input name=profile type=hidden>'
				.(empty($_SESSION['user']['newPsw'])?
					'<div class=psw><input name=psw0 type=password autocomplete=off placeholder="'.$L[1].'" title="'.$L[1].'"></div>'
					:'')
				.'<div class="a">'
					.'<div class="psw" title=" '.$L[2].'">'
						.'<input name=psw type=password placeholder="'.$L[3].'"'
							.' title="'.$L[4].'" maxlength="72">'
					.'</div>'
				.'</div>'
				.'<div class=psw><input name=psw1 type=password placeholder="'.$L[5].'"></div>'
				.'<button class="btn a" style="width:100%;display:block">'.$L[6].'</button>'
				.'<div></div>'
			.'</form>'
		.'</fieldset>';