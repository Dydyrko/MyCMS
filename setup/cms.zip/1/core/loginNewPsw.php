<?php	//выполнение формы запроса ссылки для нового пароля
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if($_SESSION['captcha3']!=$_POST['captcha']){exit(' Captcha?');}

$q='select id from person where mail="'.DB::esc($_POST['login']).'" limit 0,1';
$r=DB::q($q);
if(!DB::num_rows($r)){exit('mail?');}

$row=DB::f($r);
$code=mt_rand(100,9999);
$q='update person set new="'.password_hash($code,PASSWORD_BCRYPT).'" where id='.$row['id'];DB::q($q);

$L=LangArray(-26);	//Тексти для мов

$subject=LangTxt('memSubject',$L);	//'Ссылка на форму нового пароля';
$mes='<h1>'.$subject.'</h1><a href="https://'.$_SERVER["SERVER_NAME"].'?userLink='.$row['id'].'&c='.$code.'">'.$_SERVER["SERVER_NAME"].'</a>';
require '1/mailTo.php';
$t=mailTo($_POST['login'],$subject,$mes);
if($t){
	echo LangTxt('memPsw',$L);		//'Вам отправлен E-mail';
}else{echo 'Error mailTo';}