<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(isset($_POST['tmp'])){
	$A=array_map("unlink", glob($root.'/i/*.tmp'));
	echo '<div>Удалено файлов /i/*.tmp: '.count($A).'</div>';

	$A=array_map("unlink", glob($root.'/i/*/*.tmp'));
	echo '<div>Удалено файлов /i/*/*.tmp: '.count($A).'</div>';

	$A=array_map("unlink", glob($root.'/i/*/*/*.tmp'));
	echo '<div>Удалено файлов /i/*/*/*.tmp: '.count($A).'</div>';

	//$A=array_map("unlink", glob($root.'/i/items/*/*.tmp'));
	//echo '<div>Удалено файлов /i/items/*/*.tmp: '.count($A).'</div>';

	unset($A);
}else if(isset($_POST['wmark'])){
	$start=intval($_POST['wmark']);
	$q='select cat.id as item,cat.name as itemName,cat.img as img,files.id,files.name,files.note,files.d'	//files.d ON UPDATE CURRENT_TIMESTAMP
	.' from cat left join files on files.cat=cat.id where v>0'
	//.' cat.final=2'	//прежде было только для товаров, признаком товара было cat.final=2
	.' order by item limit '.$start.',10';
	$r=DB::q($q);
	if(DB::num_rows($r)){
		echo '<dl>Имя страницы в заголовке, справа — id страницы и в скобках порядковый номер картинки.'
			.'<br>Внизу число — последний номер, на него увеличить число в поле ввода для следующей страницы (можно стрелкой поля).'
			.'<br>Продолжать до пустой страницы';
		$t='';$i=0;
		while($row=DB::f($r)){
			$i++;
			if($t!=$row['item']){	//cat.id новый: 
				$t=$row['item'];
				echo '<dt><tt style=float:right>'.$row['item'].' ('.$i.')</tt><h2>'.$row['itemName'].'</h2>';
				if($row['img']){
					echo
					//'<img src="/i/cat/'.$row['img'].'" border=1><br>'.
					'<img src="/?img=/i/cat/'.$row['img'].'&mark=/i/wmark.jpg" border=1>'
					;
				}
			}
			if($row['name']){
				echo
				'<dd>'
				//.'<img src="/i/cat/'.$row['item'].'/'.$row['name'].'" border=1><br>'
				.'<img src="/?img=/i/cat/'.$row['item'].'/'.$row['name'].'&mark=/i/wmark.jpg" border=1>'
				;
			}else{echo '<dd>Файла галереи у страницы нет';}
		}
		echo '<dt>'.$i.'</dl>';
	}else{echo 'Complete';}
}else if(isset($_POST['wmarkTest'])){
	$root=$_SERVER["DOCUMENT_ROOT"];
	$start=intval($_POST['wmarkTest']);
	$q='select cat.id as item,cat.name as itemName,cat.img as img,files.id,files.name,files.note,files.d'	//files.d ON UPDATE CURRENT_TIMESTAMP
	.' from cat left join files on files.cat=cat.id where cat.final=2 order by item limit '.$start.',1000';
	$r=DB::q($q);
	echo '<dl>';
	$t='';$i=0;
	while($row=DB::f($r)){
		$i++;
		if($t!=$row['item']){
			$t=$row['item'];
			echo '<dt><tt style=float:right>'.$row['item'].' ('.$i.')</tt><h2>'.$row['itemName'].'</h2>';
			if($row['img']){
				$file=$root.'/i/cat/'.$row['img'];
				$file2=$file.'.mark.tmp';
				$b1=file_exists($file);
				$b2=file_exists($file2);
				if($b1 && $b2){
					if(rename($file,$file.'.bak.tmp')){
						$b=rename($file2,$file);
					}else{
						$E=error_get_last();
						echo '<dd>Ошибка переименования «'.$row['img'].'» в bak: '.$E['message'];
					}
					if($b){echo '<dd>OK переименования mark в '.$file;}
				}else{
					echo ($b1?'':'<dd>Нет файла '.$row['img']);
					echo ($b2?'':'<dd>Нет файла '.$row['img'].'.mark.tmp');
				}
			}else{echo '<dd>Картинки страницы нет';}

		}
		echo '<hr>';
		if($row['name']){
			$file=$root.'/i/cat/'.$row['item'].'/'.$row['name'];
			$file2=$file.'.mark.tmp';
			$b=file_exists($file);
			$b2=file_exists($file2);
			if($b && $b2){
				if(rename($file,$file.'.bak.tmp')){
					$b=rename($file2,$file);
				}else{
					$E=error_get_last();
					echo '<dd>Ошибка переименования «/i/cat/'.$row['item'].'/'.$row['name'].'» в bak: '.$E['message'];
				}
				if($b){echo '<dd>OK переименования mark в '.$file;}
			}else{
				echo ($b?'<dd>OK «/i/cat/'.$row['item'].'/'.$row['name'].'»':'<dd>Нет файла «/i/cat/'.$row['item'].'/'.$row['name'].'»');
				echo ($b2?'<dd>OK «/i/cat/'.$row['item'].'/'.$row['name'].'.mark.tmp'.'»':'<dd>Нет файла «/i/cat/'.$row['item'].'/'.$row['name'].'.mark.tmp'.'»');
			}
		}else{echo '<dd>Файла галереи у страницы нет';}
	}
	echo '<dt>'.$i.'</dl>';
}else if(isset($_POST['wmarkSave'])){
	//var_dump($_POST);
	$root=$_SERVER["DOCUMENT_ROOT"];
	$file=$root.'/i/cat/'.$_POST['wmarkSave'];
	$b1=file_exists($file);
	if($b1){
		$file2=$file.'.mark.tmp';
		if(file_exists($file2)){
				if(rename($file,$file.'.bak.tmp')){
					$b=rename($file2,$file);
				}else{
					$E=error_get_last();
					echo '<dd>Ошибка переименования «'.$file.'» в bak: '.$E['message'];
				}
				if($b){echo '<dd>OK переименования mark в '.$file;}
		}
	}
}else{	//собственно страница тестирования файлов
	if(class_exists('Imagick')){
		$A=Imagick::getVersion();
		//echo '<pre>'.print_r($A,true).'</pre>';
		echo '<fieldset><legend>Imagick</legend>';
		foreach($A as $i=>$v){echo'<div>'.$i.': '.$v.'</div>';}
		$A=Imagick::queryFormats();	//
		echo'<div style="overflow-y:scroll;max-width:600px;max-height:60px;border:inset 2px #eee">'.implode(', ',$A).'</div>'
		.'</fieldset>';
	}else{
		echo'imagick class not exists!';
	}

	$limit=10;
	$q='select count(*) as c,files.cat,cat.name from files join cat on files.cat=cat.id group by files.cat'
	.' order by c desc limit 0,'.$limit;
	$r=DB::q($q);
	if(DB::num_rows($r)){
		echo '<ol>Страницы в порядке убывания количества файлов галереи, лимит '.$limit;
		while($row=DB::f($r)){
			echo '<li>'.$row['c'].' <a target=_blank href=/?p='.$row['cat'].'>'.$row['name'].'</a>';
		}
		echo '</ol>';
	}else{echo '<div>Файлов в галерее нет</div>';}


	echo '<fieldset><legend>Наличие файлов в "i/cat"</legend>';
	$m=1000000;	//показать файлы больше $m байт
	$A=$B=$C=array();

	$q='select id,name,img from cat where v>0 order by id';
	$r=DB::q($q);
	echo '<div>Титульных картинок: <b>'.DB::num_rows($r).'</b></div>';
	while($row=DB::f($r)){
		$file=$_SERVER["DOCUMENT_ROOT"].'/i/cat/'.$row['img'];
		if(!file_exists($file)){
			$C[]='<li>'.$row['id'].' <span>'.$row['name'].'</span>';
		}else{
			$n=filesize($file);
			if($n>$m){
				$A[]=array($n,'<li>'.(intval($n/100000)/10).'Mb: <span>'.$row['name'].'</span> (id='.$row['id'].')');
			}
		}
	}

	$q='select id,cat,name from files where cat<>0';
	$r=DB::q($q);
	echo '<div>Галерея файлов: <b>'.DB::num_rows($r).'</b></div>';

	while($row=DB::f($r)){
		if(!file_exists($root.'/i/cat/'.$row['cat'].'/'.$row['name'])){
			$C[]='<li><span>'.$row['name'].'</span>'
				.'<a onclick="e=nextSibling;ajxTo(this,e,function(){ajx(event,\'files\',\''.$row['cat'].'&t=\'+previousSibling.innerHTML,e,[ajxBtns],1)})"> cat='.$row['cat'].'</a><div class=ajxSibling style="display:none"></div>';
		}else{
			$n=filesize($root.'/i/cat/'.$row['cat'].'/'.$row['name']);
			if($n>$m){
				$A[]=array($n,'<li>'.(intval($n/100000)/10).'Mb: <span>'.$row['name'].'</span><a onclick="e=nextSibling;ajxTo(this,e,function(){ajx(event,\'files\',\''.$row['cat'].'&t=\'+previousSibling.innerHTML,e,[ajxBtns],1)})"> cat='.$row['cat'].'</a><div class=ajxSibling style="display:none"></div>');
			}
		}
	}
	if(empty($C)){echo '<div style="color:lightgreen">Отсутствующих файлов нет</div>';}else{
		echo '<ol style="background-color:yellow">Отсутствующие файлы:'.implode('',$C).'</ol>';
	}
	if(empty($A)){echo '<div style="color:lightgreen">Размер файлов не превышает '.($m/1000000).'Mb</div>';}else{
		$v=array();
		foreach($A as $key => $row){$v[$key]=$row[0];}
		array_multisort(				//сортировка двух массивов
				$v,SORT_DESC,SORT_NUMERIC,	//первый массив и правила сортировки
				$A				//второй массив: очерёдность изменяется согласно первому массиву
		);
		foreach($A as $v){
			$B[]=$v[1];
		}
		echo '<ol>Файлы больше '.($m/1000000).'Mb ('.count($B).'):'.implode('',$B).'</ol>';
	}
	echo '</fieldset>';


	echo'<hr><a onclick="ajx(event,\'testFiles\',\'&tmp=\',nextSibling)">Удалить временные файлы</a><div></div>';

	echo '<hr><div><img onclick="if(dataset.i){ajx(event,\'testFiles\',\'&wmarkSave=\'+dataset.i)}"><input title="Имя файла после «/i/cat/»"><a onclick="
		var e=parentNode.firstChild,n=e.nextSibling;
		if(n.value){e.dataset.i=n.value;e.src=\'/?img=/i/cat/\'+n.value+\'&mark=/i/wmark.jpg\'}
	"> Добавить картинке "водяной знак" /i/wmark.jpg</a></div>';

	echo'<fieldset style=margin-top:10px><legend>Массовое добавление "водяного знака" картинкам публичных страниц</legend>'
	.'<a title="Возможность остановить автозапуск следующего процесса" onclick="
		var e=nextSibling;if(e.dataset.i && e.dataset.i!=0){textContent=e.dataset.i;e.dataset.i=0}else{e.dataset.i=textContent;textContent=\'Остановлено\'}
	">Стартовый №</a>'
	.'<input type=number min=0 step=10 value=0 style="width:6em;text-align:center" title="Номер начальной картинки (в порядке id таблицы files) для запроса по десять шт.">'
	.'<a title="Запрос аяксом десяти картинок, начиная с номера в поле ввода слева.
 Если не «Остановлено» нажатием на ссылку перед полем, то после выполнения номер в поле увеличивается на 10 и запрос повторяется до завершения" onclick="
		ajx(event,\'testFiles\',\'&wmark=\'+previousSibling.value,nextSibling
		,\'if(txt!=\\\'Complete\\\'){var e=div.previousSibling.previousSibling;e.value=10+1*e.value;if(!e.dataset.i || e.dataset.i==0){'
			.'window.setTimeout(function(){e.nextSibling.onclick()},4000)'
		.'}}\'
		)
	">Создать картинки с "водяным знаком" /i/wmark.jpg (*.mark.tmp)</a><div></div>';

	echo'<hr>Стартовый №<input type=number min=0 step=1000 value=0 style="width:6em;text-align:center" title="По тысяче">'
	.'<a onclick="ajx(event,\'testFiles\',\'&wmarkTest=\'+previousSibling.value,nextSibling)">Заменить картинки на «mark» с преименованием в «*.bak.tmp»</a><div></div>'
	.'</fieldset>';

	$q='select id,img from cat where v>0'
		//.' final=2'
		.' and img!=""';
	$r=DB::q($q);
	echo '<ol>Картинок страниц: '.DB::num_rows($r);
	while($row=DB::f($r)){
		$file=$root.'/i/cat/'.$row['img'];
		if(file_exists($file)){
			$t=filesize($file);
			if(!$t){	//если нулевой размер файла и есть резервная копия с ненулевым размером файла, то заменить на копию
				echo '<li>Нулевой '.$row['img'];
				$f=$file.'.bak.tmp';
				if(file_exists($f) && filesize($f)){
					if(unlink($file)){
						if(copy($f,$file)){echo ' OK';}else{$E=error_get_last();echo '<br>'.$E['message'];}
					}else{$E=error_get_last();echo '<br>'.$E['message'];}
					//echo ' '.filesize($f);
				}
			}
		}else{
			echo '<li style=color:red>'.$row['id'].' Нет файла '.$row['img'];
		}
	}
	echo '</ol>';

}