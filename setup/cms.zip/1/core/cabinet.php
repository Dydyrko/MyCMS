<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

//$_SESSION['user']['newPsw']=0;	//для симуляции включения режима "новый пароль"

if(isset($_SESSION['user']['admin'])){
	if(!empty($_SESSION['user']['id']) && $_SESSION['user']['id']!=$_GET['p']){	//админ становится авторизованным как персона кабинета
		echo '<div style="position:absolute;bottom:0;left:0;background-color:yellow">'.$_SESSION['user']['name'].' &rarr; '.$catName.'</div>';
	}
	$_SESSION['user']['id']=$_GET['p'];
	$_SESSION['user']['name']=$catName;
	$_SESSION['user']['img']=$catImg;
	$_SESSION['user']['final']=$final;
}

$q='select id,'.DB::qL('name').',img,c from cat where parent=-90';	//Профиль персоны
$r=DB::q($q);
$A=array();
$t=(empty($_SESSION['user']['newPsw'])?-91:-93);
while($row1=DB::f($r)){
	$A[]='<a data-id='.$row1['id'].' style="border-bottom:solid 2px #'
		.($row1['id']==$t?'999':'fff')
	.'">'.$row1['name'].'</a>';
}

echo
'<div class=cabinet onclick="
	var e=lastChild.lastChild,
	m=this.getElementsByTagName(\'A\'),
	n=event.target,i=0;
	if(n.nodeName==\'A\' && n.dataset.id){'
	.'for(i;i<m.length;i++){m[i].style.borderBottomColor=(m[i]==n?\'#999\':\'#fff\')}'
	.'if(n.previousSibling){'	//нажатие на не первый элемент
		.'e.previousSibling.style.display=\'none\';'
		.'e.style.display=\'block\';'
		.'ajx(event,\'login\',\''.$_GET['p'].'&p=\'+n.dataset.id+\'&profile=\',e,'
		.'(n.dataset.id==-92?\'if(jsAppend(\\\'gMap1\\\',0,0,0,\\\''.$host.'\\\')===true){gMap1Initialize()}\':0)'	//положение на карте
		.')'
	.'}else{'
		.'e.style.display=\'none\';'
		.'e.previousSibling.style.display=\'block\';'
	.'}'
.'}">'
	.implode(' | ',$A)
	.'<div style="margin:20px 0;position:relative">'
		.'<div'.(empty($_SESSION['user']['newPsw'])?'':' style="display:none"').'>';	//Общая информация
			require $root.'/1/core/profile.php';
			/*
			if($final==-120){
				echo '<ul style="clear:both">Админу
					<li><a href=/help target=_blank>Справка</a>
					<li><a href=/orders target=_blank>Заказы</a>
					<li><a href=/admin target=_blank>Управление сайтом</a>
				</ul>';
			}
			*/
		echo
		'</div>'
		.'<div>';

		if(!empty($_SESSION['user']['newPsw'])){	//Настройки
			require $root.'/1/core/profileSet.php';
		}

		echo
		'</div>'
	.'</div>'
.'</div>';

