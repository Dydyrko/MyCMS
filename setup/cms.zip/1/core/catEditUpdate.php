<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$_POST['catEdit']=intval($_POST['catEdit']);
//var_dump($_POST);
	if(isset($_FILES['file_cat']) && $_FILES['file_cat']['name'] || isset($_POST['chk_Del_cat'])){
		require $root.'/1/catImgSave.php';
		$img=catImgSave($_POST['catEdit']);
	}
	$A=$B=$Person=array();

	if(isset($_POST['price']) && $_POST['price']!=0 || isset($_POST['price0']) && $_POST['price0']!=0){$Item=array();}

	foreach($_POST as $i=>$v){
		if(in_array($i,array('name','adt'))){$A[]=$i.($lang==$Langs[0]?'':'_'.$lang).'="'.DB::esc($v).'"';}
		if(in_array($i,array('note'))){$A[]=$i.'="'.DB::esc($v).'"';}
		if(in_array($i,array('d','d1'))){$A[]=$i.'='.($v==''?'NULL':'"'.DB::esc($v).'"');}
		if(in_array($i,array('v','vimg','ord','final','owner'))){$A[]=$i.'="'.intval($v).'"';}

		if(in_array($i,array('text'))){$B[]=$i.($lang==$Langs[0]?'':'_'.$lang).'="'.DB::esc($v).'"';}
		if($i=='url'){
			$v=DB::esc($v);
			$B[]=$i.($lang==$Langs[0]?'':'_'.$lang).'='.($v==''?'NULL':'"'.$v.'"');	//url может быть NULL, индекс: уникальность
		}
		//перед отправкой формы тексты meta1 … meta4 сливаются строками в один meta
		if(in_array($i,array('meta'))){$B[]=$i.($lang==$Langs[0]?'':'_'.$lang).'="'.DB::esc(str_replace("\r",'',$v)).'"';}

		if(in_array($i,array('mail','available','frozen','bonus'))){$Person[]=$i.'="'.DB::esc($v).'"';}
		if(isset($Item)){
			if(in_array($i,array('code'))){$Item[]=$i.'="'.DB::esc($v).'"';}
			if(in_array($i,array('price','price1','price0'))){$Item[]=$i.'="'.DB::esc($v*100).'"';}
			if(in_array($i,array(
				//'rate',
				'currency'))){$Item[]=$i.'="'.intval($v).'"';}
		}


	}

	if(isset($img)){$A[]='img="'.($img=='Deleted'?'':$img).'"';}

	if(!empty($A)){
		$q='update cat set '.implode(',',$A).' where id='.$_POST['catEdit'];
		DB::q($q);
	}

	if($_POST['update']==1){	//пустые поля для таблицы url
		$q='delete from url where id='.$_POST['catEdit'];DB::q($q);
	}else if(!empty($B)){
		$q='select id from url where id='.$_POST['catEdit'];
		$r=DB::q($q);
		if(DB::num_rows($r)){
			$q='update url set '.implode(',',$B).' where id='.$_POST['catEdit'];
		}else{
			$q='insert into url set '.implode(',',$B).',id='.$_POST['catEdit'];
		}
		DB::q($q);
	}

	$q='SHOW TABLES like "item"';$r=DB::q($q);
	if(DB::num_rows($r)){	//есть таблица "item" для товаров
		if(empty($Item)){
			$q='select id from item where id='.$_POST['catEdit'];
			$r=DB::q($q);
			if(DB::num_rows($r)){$q='delete from item where id='.$_POST['catEdit'];DB::q($q);}	
		}else{
			$q='select id from item where id='.$_POST['catEdit'];
			$r=DB::q($q);
			if(DB::num_rows($r)){
				$q='update item set '.implode(',',$Item).' where id='.$_POST['catEdit'];
			}else{
				$q='insert into item set '.implode(',',$Item).',id='.$_POST['catEdit'];
			}
			DB::q($q);
		}
	}

	if(!empty($Person)){
		$q='select id from person where id='.$_POST['catEdit'];
		$r=DB::q($q);
		if(DB::num_rows($r)){
			$q='update person set '.implode(',',$Person).' where id='.$_POST['catEdit'];
		}else{
			$q='insert into person set '.implode(',',$Person).',id='.$_POST['catEdit'];
		}
		DB::q($q);
	}


	//if(!empty($q)){echo $q;}

	if(isset($_FILES['file_cat'])){	//эта форма: может выполняться ajx не только для неё
		echo '<div><a onclick="var n=parentNode,e=n.parentNode.parentNode.elements,i;
			for(i in e){e[i].disabled=false}
			n.parentNode.removeChild(n)">Выполнено &times;</a></div>';	//$q;
		if(!isset($_POST['show'])){exit;}
	}else{exit;}