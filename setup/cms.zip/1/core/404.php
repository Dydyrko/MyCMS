<?php
if($a){
	header($_SERVER["SERVER_PROTOCOL"].' 401 Unauthorized');
}else{
	header($_SERVER["SERVER_PROTOCOL"].' 404 Not Found');
}
if(file_exists($_SERVER['DOCUMENT_ROOT'].'/i/cat/-30/logo.svg')){$logo='/i/cat/-30/logo.svg';}
else if(file_exists($_SERVER['DOCUMENT_ROOT'].'/i/cat/-30/logo.png')){$logo='/i/cat/-30/logo.png';}
else{$logo='';}
echo
'<!doctype html>'
.'<body onload="history.replaceState(\'\',null,\'/\')">'
.'<a href="/">'
	.(empty($logo)?
		$_SERVER['SERVER_NAME']
		:'<img src="'.$logo.'" style="max-width:100%" alt="Logo" title="'.$_SERVER['SERVER_NAME'].'">'
	)
.'</a>';
if($a){
	echo
	'<h1>Error 401 Unauthorized</h1>'
	.'<p>Page "'.$_SERVER['REQUEST_URI'].'" is not public on domain «<a href="/" style="font-size:42px">'.$_SERVER['SERVER_NAME'].'</a>»';
}else{
	echo
	'<h1>Error 404 Not Found</h1>'
	.'<p>Page "'.$_SERVER['REQUEST_URI'].'" not found on domain «<a href="/" style="font-size:42px">'.$_SERVER['SERVER_NAME'].'</a>»';
}
echo
'<p style="margin-top:40px"><a href="/" onclick="if(window.history.length>2){window.history.back();return false}" title="Go back">Go back</a></p>'
//.$_SERVER['HTTP_REFERER']
;

exit;