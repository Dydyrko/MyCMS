<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

	$q='select '.DB::qL('name').','.DB::qL('adt').' from cat where id=-9';	//Регистрация
	$row=DB::f(DB::q($q));
	$row['adt']=str_replace('{captcha}',captcha(2),$row['adt']);	//id=2 (id=1 для нового пароля)

	echo
	'<style>
		.reg button{font-size:18px;}
		.reg .err{margin:10px 30px;color:red;font-size:200%}
		.reg>.ok{
			margin-top:50px;color:green;font-size:150%;text-align:center;line-height:150%;
			background-color:#fff;border:solid 1px #bbb;padding:20px;
		}
	</style>'
	.'<h2>'.$row['name'].'</h2>'
	.'<form class=reg onsubmit="ajxFormData(event,this,[\'if(txt[0]!=\\\' \\\'){div=0}\'],lastChild);return false">'
		.'<input name=reg type=hidden>'
		.$row['adt']
		.'<div></div>'
	.'</form>';