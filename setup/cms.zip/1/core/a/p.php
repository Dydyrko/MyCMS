<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$t=substr($_SERVER['REQUEST_URI'],1,3);	//первые 3 символа запроса после "домен/"
if(in_array($t,array('ru/','uk/','en/'))){
	$lang=substr($t,0,2);
}else{$lang='uk';}
echo
'<!doctype html><html lang='.$lang.'><head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1" />
<link rel=stylesheet type=text/css href=/css/ajx.css>
<link rel=stylesheet type=text/css href=/css/calendar.css>
<link rel=stylesheet type=text/css href=/css/admin.css>
<script src=/js/ajx.js></script>
<script src=/js/f.js></script>
<script src=/js/translit.js></script>
<script src=/js/calendar.js></script>
<script src=/js/screenfull.js></script>
<script src=/js/lang_'.$lang.'.js></script>
<title>'.$_GET['t'].' [child pages]</title>';
?>
<script src="/js/admin.js"></script>
</head><body style="padding:3px">
<script>
'use strict';
if(!opener || opener.closed){
	document.body.innerHTML="This browser window needs to be closed"
}else{
	var id=<?php echo intval($_GET['ap']); ?>;

	var m=document.createElement('a');
	m.className='refresh';
	m.style='float:right;margin:8px;';
	m.addEventListener('click',function(){ajx(0,'cat',id+'&order='+document.getElementById('p').lastChild.dataset['ord'],g('p'),catOrdEvt)});
	document.body.appendChild(m);

	var m=document.createElement('a');
	m.innerHTML='+';
	m.style='clear:right;float:right;margin:15px;font-size:24px';
	m.addEventListener('click',function(){ajx(0,'catAdd',id+'&t=<?php echo $_GET['t'];?>',g('content'))});
	document.body.appendChild(m);

	m=document.createElement('DIV');
	m.id='p';
	m.style.display='inline-block';
	m.style.verticalAlign='top';
	m.style.paddingTop='20px';
	document.body.appendChild(m);
	ajx(0,'cat',id,m,catOrdEvt);

	m=document.createElement('DIV');
	m.style.margin='15px';
	m.style.display='inline-block';
	m.style.verticalAlign='top';
	m.id='content';
	document.body.appendChild(m);
}
</script>

</body></html>