<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};
$t=substr($_SERVER['REQUEST_URI'],1,3);	//первые 3 символа запроса после "домен/"
if(in_array($t,array('ru/','uk/','en/'))){
	$lang=substr($t,0,2);
}else{$lang='uk';}
echo '<!doctype html><html lang='.$lang.'><head>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta charset=UTF-8>
<title>HTML Editor</title>
<style>
	*{box-sizing: border-box;outline:none}
	html,body{height: calc(100% - 10px);margin: 1px 2px;}
</style>
<body>
<textarea id="editHTML" style="width:100%;height:calc(100% - 30px)"></textarea>
<div>
	<button onclick="document.getElementById(\'editHTML\').value=\'\'" title="Очистить поле ввода">Blank</button>
	<button onclick="textareaHTML()" title="Вставить в редактор текст со страницы">In</button>
	<button onclick="textareaHTML(1)" title="Вставить на страницу текст редактора">Out</button>
	<button onclick="textareaHTML(2)" title="Вставить на страницу текст редактора и сохранить">Save</button>
</div>';
?>

<script>
'use strict';
if(!opener || opener.closed){document.body.innerHTML="This browser window needs to be closed"}
	function textareaHTML(a){
		var id=location.search,A,t;
		if(!id){return false}
		A=id.split('=');
		if(A.length){id=A[1]}
		id=id.split('&');
		id=id[0];
		if(!id){return false}
		if(A.length>2){t=A[2]}
		var	n=document.getElementById("editHTML"),
			m=opener.document.querySelector(".editBar[data-id='"+id+"'] .Save");
		if(!m){alert('m ?');return}
		var	e=m.parentNode.parentNode.parentNode.nextSibling;
		//console.log(e);
		if(a){
			e.innerHTML=n.value
		}else{
			n.value=e.innerHTML
		}
		if(a==2){
			m.onclick();
			m.parentNode.style.display="inline"
		}
		document.title=(t?decodeURIComponent(t):'')+' * '+opener.document.title+' [HTML Editor]'
	}
	textareaHTML();
</script>
