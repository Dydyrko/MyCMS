<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

session_start();
require $_SERVER['DOCUMENT_ROOT'].'/1/core/permit.php';

$file=$_SERVER['DOCUMENT_ROOT'].'/1/core/a/inBody.txt';
if(file_exists($file)){
	$s=file_get_contents($file);
	if($s===false){exit('Err get_contents '.$file);}
}else{$s='';}

echo
'<!doctype html>'
.'<title>inBody.txt</title>'
.'<link type="image/png" rel="shortcut icon" href="/favicon.png" />'
.'<style>
	*{box-sizing: border-box;outline:none}
	html,body{height: calc(100% - 15px);margin: 0 5px;}
</style>'
.'<tt style=float:right></tt>'
.'<button onclick="ajx(event,`css`,`inBody&t=`+encodeURIComponent(nextSibling.value),previousSibling)">Сохранить</button>'
.'<textarea spellcheck="false" style="width:100%;white-space: pre;height:calc(100% - 30px)">'
.$s.'</textarea>'

.'<script src="/js/ajx.js"></script>';