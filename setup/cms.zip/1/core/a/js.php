<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};
$lang=substr($_SERVER["REQUEST_URI"],1,2);
echo '<!doctype html><html lang='.$lang.'><head>';
?>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta charset=UTF-8>
<link type="image/png" rel="shortcut icon" href="/favicon.png" />
<link rel=stylesheet type=text/css href=/css/ajx.css>
<style>
	*{box-sizing: border-box;outline:none}
	html,body{height: calc(100% - 15px);margin: 0px;}
	.highLighting tr:hover{background-color:#fafafa}
	.files{position:absolute;background-color:#eee;transform:scaleY(0);transform-origin:top;transition:all .5s}
	.files.a{transform:scaleY(1)}
	.files td:nth-child(3){font-size:80%}
	a{cursor:pointer;color:#00f}
	a:hover{color:red}
	h1{margin:0 2px;font-weight:400;font-size:18px}
	#txtPos{float:right}
	button.delTmp{background-color:#afa}
	input:focus{border-color:#99f}
</style>
<body onload="ajx(0,'core_css',document.body.id+'&catName='
,document.querySelector('h1').lastChild
,'document.title=(document.body.dataset.c?\'*JS subpages* \':\'*JS: \'+txt+\'* \')+opener.document.title'
);">
<h1><b>JS</b>: <tt></tt></h1>
<form onsubmit="return false" style="height:100%;" data-ft=js>
<table style="width:100%;height:100%"><tr><td>
	<button id=filesBtn onclick="files(event,this);return false" style="margin-bottom:5px"
		 title="Show/hide list of files.<?php echo "\n";?>List will be updated with the pressed key [Shift]">
		Files
	</button><input name=name style="margin-bottom:5px" placeholder="File name"
	 title="File name (*.js), you can create a new file"><button style="margin-bottom:5px" onclick="saveFile()">Save</button>
<?php
if(0 && file_exists($_SERVER["DOCUMENT_ROOT"].'/js/ace')){
?>
	<button onclick="
		'use strict';
		form.style.opacity=0;	//скрыть действия до выполнения ace1()
		var n=document.createElement('DIV');
		n.style='position:absolute;top:25px;right:0;bottom:0;left:0';
		n.id='aceEditor';
		if(event.shiftKey){
			n.dataset.t='text';		//режим редактора (возможны баги)
		}else{n.dataset.t='javascript';}
		n.innerHTML=form.elements['text'].value;	//текст в редактор
		form.appendChild(n);
		n=jsAppend('ace1');
		if(n===true){ace0()}		//если скрипт был загружен, то выполнить функцию
		return false
	" title="Editor «Ace», with pushed [Shift] — text-mode">Ace</button>
<?php
}

echo
' <nobr>Links:
 <a onclick="ajx(0,\'core_css\',\'js\')">JS</a>
 or <a onclick="ajx(0,\'core_css\',\'css\')">CSS</a>
</nobr> 

	<tt id=txtPos title="Line number:position /length"></tt>
	<div class=files></div>
<tr style=height:100%><td>
	<textarea name=text id=r spellcheck="false" style="width:100%;white-space: pre;height:100%" onkeyup="txtPos(event,this)" onclick="txtPos(event,this)"></textarea>
	<input name=ft value="js" type=hidden>
</table>
</form>

<script src=/js/cssFiles.js></script>
<script src=/js/ajx.js></script>
<script src=/js/f.js></script>
<script>
"use strict";
	function go(form){
		var e=form.elements,i=0,b;
		for(i;i<e.length;i++){
			if(!e[i].name || e[i].name=="css"){continue}
			if(e[i].name && e[i].name=="name"){e[i].disabled=true;continue}			//имя файла
			if(e[i].name && e[i].name=="text"){e[i].disabled=true;continue}			//редактор
			if(e[i].value==""){e[i].disabled=true}else{e[i].disabled=false;b=1}
		}
		if(b){ajxFormData(0,form,0,document.querySelector(".files").lastChild)}
		for(i=0;i<e.length;i++){e[i].disabled=false}
		return false
	}
</script>';
