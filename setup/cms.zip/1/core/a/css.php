<!doctype html>
<head>
<meta charset=UTF-8>
<link type="image/png" rel="shortcut icon" href="/favicon.png" />
<link rel=stylesheet type=text/css href=/css/ajx.css>
<style>
	*{box-sizing: border-box;outline:none}
	html,body{height: calc(100% - 15px);margin: 0 5px;}
	.highLighting tr:hover{background-color:#fafafa}
	.files{position:absolute;background-color:#eee;transform:scaleY(0);transform-origin:top;transition:all .5s}
	.files.a{transform:scaleY(1);box-shadow: 1px 1px 5px #000;}
	.files td:nth-child(3){font-size:80%}
	a{cursor:pointer;color:#00f}
	a:hover{color:red}
	h1,h2{margin:0;font-size:18px}
	h1{height:22px}
	#txtPos{float:right}
	table.colors{width:100%}
	table.colors th{color:#999}
	table.colors input{width:100%}
	table.colors td:nth-child(1){width:1em}
	table.colors td:nth-child(2){width:4em}
	a.color{display:inline-block;vertical-align:top;border:solid 1px #ccc;margin-bottom:5px;padding:2px}
	a.color:hover{border-color:#aaf}
	a.color>b{white-space:nowrap;margin-right:1em;padding-left:3px;border-left-style:solid;border-left-width:15px}
	a.color>b:last-child{margin-right:0}
	button.delTmp{background-color:#afa}
	input:focus{border-color:#99f}
</style>
<body onload="ajx(0,'css',document.body.id+'&catName=',document.querySelector('h1').lastChild);">
<h1><b>Стили</b>: <tt></tt></h1>
<form onsubmit="return false" style="height:100%;" data-ft=css>
<table style="width:100%;height:100%"><tr><td>
	<button id=filesBtn onclick="files(event,this);return false" style="margin-bottom:5px"'
		.' title="Показать/скрыть список файлов. С клавишей [Shift] список обновляется">
		Файлы CSS
	</button><input name=name style="margin-bottom:5px" placeholder="File name" title="Имя файла, можно создать новый файл"><button onclick="saveFile()" style="margin-bottom:5px">Save</button>
<?php
$root=$_SERVER["DOCUMENT_ROOT"];
if(file_exists($root.'/js/ace')){
?>
	<button onclick="
		'use strict';
		form.style.opacity=0;	//скрыть действия до выполнения ace1()
		var n=document.createElement('DIV');
		n.style='position:absolute;top:25px;right:0;bottom:0;left:0';
		n.id='aceEditor';
		n.dataset.t='css';		//режим редактора
		var A=form.elements['text'].value.split('\n');
		n.dataset.a=A[0];A[0]='';	//первую строку храним в data-a и очищаем (чтобы нумерация строк совпадала с CSS в браузере)
		n.dataset.b=A.pop();		//последнюю строку храним в data-b с удалением элемента массива (чтобы дописывать без учёта замены последней строки)
		n.innerHTML=A.join('\n');	//текст в редактор
		form.appendChild(n);
		n=jsAppend('ace1');
		if(n===true){ace0()}		//если скрипт был загружен, то выполнить функцию
		return false
	">Ace</button>
<?php
}

	$C=file($root.'/1/css.ini');
	if(!$C){$C=array('#ccc','#ccc','#ccc');}
	$N=file($root.'/1/css.txt');
	if(!$N){$N=array('','','');}
	$A=
	['<style>
		a.screenfull{position:absolute;top:5px;left:5px;z-index:1;color:#fff}
		a.screenfull:hover{color:yellow}
		.ajxAlert > DIV + center{min-width:80%}
	</style>'];
	$A[]='<a class=\'screenfull\' onclick=\'screenfull.toggle(parentNode)\' style=\'font-size:24px;line-height:20px;\' title=\'Полный экран\'>⤢</a>';
	$A[]='<h2>Цвета в массиве $C</h2>';
	$A[]=
	'<form onsubmit=\'return ajxFormData(event,this)\'><input name=css value=variables type=hidden>'
		.'<table class=colors width=100%>'
			.'<tr><th>№<th>Код<th>Назначение';
			foreach($C as $i=>$v){
				$v=trim($v);
				if($v==''){continue;}
				$A[]='<tr><td>'.$i.'<td><input name=c[] value=\''.$v.'\'><td><input name=t[] value=\''.$N[$i].'\'>';
			}
			$A[]='<tr><td><td><input name=c[] value=\'\'><td><input name=t[] value=\'\'>';
		$A[]='</table><button>Сохранить</button><div></div>'
	.'</form>'
	.'<a class=close>&times;</a>';

	echo '<a class="color" onclick="showDiv(`'.str_replace('"','`',implode('',$A)).'`)">';
	foreach($C as $i=>$v){
		$v=trim($v);
		if($v==''){continue;}
		echo
		'<b style="border-color:'.($i==0?'#fff':$v).'"'
			.' title="'.$i.': '.$v."\n".str_replace('"','`',$N[$i]).'"'
		.'>'.($i==0?$v:$i).'</b> ';
	}
	echo '</a>';

	echo ' Связи <a onclick="ajx(0,\'css\',\'css\')">CSS</a> и <a onclick="ajx(0,\'css\',\'js\')">JS</a>


	<tt id=txtPos title="строка:позиция /длина строки"></tt>
	<div class=files></div>
	<tr style=height:100%><td>
		<textarea name=text id=r spellcheck="false" style="width:100%;white-space: pre;height:100%" onkeyup="txtPos(event,this)" onclick="onkeyup()"></textarea>
	</table>
	<input name=ft value="css" type=hidden>
</form>

<script src=/js/cssFiles.js></script>
<script src=/js/ajx.js></script>
<script src=/js/f.js></script>
<script src=/js/screenfull.js></script>
<script>
"use strict";
	function go(form){
		var e=form.elements,i=0,b=-1;
		for(i;i<e.length;i++){
			if(e[i].name && e[i].name=="name"){e[i].disabled=true;continue}			//имя файла
			if(e[i].name && e[i].name=="text"){e[i].disabled=true;continue}			//редактор

			if(!e[i].name || e[i].name=="c" || e[i].name=="css" || e[i].name=="ft"){continue}		//пропустить пустые, признак вложенных страниц, имя обработчика аякс, признак CSS

			if(e[i].value==""){
				e[i].disabled=true
			}else{
				//console.log(i,b,e[i].value,e[i].name);
				if(e[i].value>0 && b==e[i].value){
					b=-1;e[i].focus();
					alert("Номер должен быть уникальным");
					break
				}
				b=e[i].value;
				e[i].disabled=false;
			}
		}
		if(b>=0){ajxFormData(0,form,0,document.querySelector(".files").lastChild)}
		for(i=0;i<e.length;i++){e[i].disabled=false}
		return false
	}
	document.title=(document.body.dataset.c?"*Child pages CSS* ":"*CSS* ")'
	.(empty($_GET['t'])?'':'+"'.addslashes($_GET['t']).' * "')
	.'+opener.document.title;
</script>';
