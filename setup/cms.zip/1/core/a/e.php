<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$t=substr($_SERVER['REQUEST_URI'],1,3);	//первые 3 символа запроса после "домен/"
if(in_array($t,array('ru/','uk/','en/'))){
	$lang=substr($t,0,2);
}else{$lang='en';}
echo
'<!doctype html><html lang='.$lang.'><head>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<link rel=stylesheet type=text/css href=/css/ajx.css>
	<link rel=stylesheet type=text/css href=/css/calendar.css>
	<link rel=stylesheet type=text/css href=/css/admin.css>
	<script src=/js/ajx.js></script>
	<script src=/js/f.js></script>
	<script src=/js/translit.js></script>
	<script src=/js/calendar.js></script>
	<script src=/js/screenfull.js></script>
	<script src=/js/lang_'.$lang.'.js></script>';
?>
</head><body style="padding:3px">
<script>
'use strict';

if(!opener || opener.closed){
	document.body.innerHTML="Требуется закрыть это окно браузера"
}else{

<?php
	echo'
		var m=document.createElement("DIV");
		document.body.appendChild(m);
		ajx(0,"core_catEdit",'.intval($_GET['ae']).',m);
	document.title="* "+opener.document.title+" [Editor]"

	';
?>
}

</script>
<script src=/js/admin.js></script>
</body></html>