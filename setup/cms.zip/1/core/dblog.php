<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if($_POST['dblog']=='db'){	//обращения или ошибки SQL
	require $root.'/1/core/db.php';
	exit;
}
				//журнал изменений БД
if(isset($_POST['TRUNCATE'])){
	$q='TRUNCATE TABLE dblog';DB::q($q);
	exit('Выполнено');
}else if(!empty($_POST['dblog'])){

	if(isset($_POST['by'])){
		//var_dump($_POST);
		$q='select d,t,a,id,SUBSTRING_INDEX(note,"<hr>",1) as n from dblog where 1 order by d desc limit '.$_POST['dblog'].','.$_POST['by'];
		$r=DB::q($q);
		$n=DB::num_rows($r);
		if($n){
			while($row=DB::f($r)){
				echo '<td>'.$row['d'].'<td>'.$row['t'].'<td>'.$row['a'].'<td><a onclick="ajx(event,\'catEdit\',innerHTML)">'.$row['id'].'</a><td>'
				.(substr($row['n'],0,3)=='OLD'?'<a onclick="ajx(event,\'dblog\',\''.$row['id'].'&d=\'+encodeURIComponent(\''.$row['d'].'\'))">'.$row['n'].'</a>':$row['n'])
				."\n";
			}
			echo $n;
		}
	}else{

		$q='select note from dblog where id='.intval($_POST['dblog']).' and d="'.DB::esc($_POST['d']).'"';
		$row=DB::f(DB::q($q));
		echo $row['note'];
	}
	exit;
}

$by=30;
$q='select d,t,a,id,SUBSTRING_INDEX(note,"<hr>",1) as n from dblog where 1 order by d desc limit 0,'.$by;
$r=DB::q($q);
$n=DB::num_rows($r);
echo
'<a onclick="if(confirm(innerText+\'?\')){ajx(event,\'dblog\',\'&TRUNCATE=\',nextSibling)}">Очистить таблицу</a>'
.'<div>'
	.'<table border style="border-collapse: collapse;">'
	.'<th>Дата<th>Табл.<th>Действие<th>id<th>Примечание';
	while($row=DB::f($r)){
		echo '<tr><td>'.$row['d'].'<td>'.$row['t'].'<td>'.$row['a'].'<td><a onclick="ajx(event,\'catEdit\',innerHTML)">'.$row['id'].'</a><td>'
		.(substr($row['n'],0,3)=='OLD'?'<a onclick="ajx(event,\'dblog\',\''.$row['id'].'&d=\'+encodeURIComponent(\''.$row['d'].'\'))">'.$row['n'].'</a>':$row['n']);
	}
	echo '</table>'
	.($n==$by?
		'<a data-n=30 onclick="ajx(event,\'dblog\',dataset.n+\'&by='.$by.'\',nextSibling,[trNext],1)"'	//admin.js дозагрузка строк таблицы
		.' style="display:block;text-align:center;border:outset 2px;margin-top:5px">&darr;</a><div></div>'
	:''.$n)
.'</div>';