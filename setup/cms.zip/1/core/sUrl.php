<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

function sUrl($id,$q='',$b=''){	//ссылка на страницу $id с возможностью добавить строку запроса $q. $b для переключателя языка (='ru' или 'uk' или 'en')
	global $catUrl,/*$catUrlStart,*/$catUrlEmpty,$Langs,$lang,$root;
	$id=intval($id);
	if($b || empty($catUrl[$id]) && empty($catUrlEmpty[$id])){	//если ссылка на другой язык (переключение языка) или нет значения в массивах
		$u=urLang($b);	//имя колонки для языка
		$r=DB::q('select '.$u.' as url from url where '.$u.'<>"" and id='.$id);
		if(DB::num_rows($r)){
			$row=DB::f($r);
			$url=$row['url'];
			if(!$b){	//если не другой язык, то сохраняем в массиве
				$catUrl[$id]=$row['url'];
			}
		}else if(!$b){$catUrlEmpty[$id]=1;}
	}else if(isset($catUrl[$id])){$url=$catUrl[$id];}
	return	($lang==$Langs[0] || $b?'':$lang.'/')	//для основного языка язык не указывать
		.(empty($url)?
			'?p='.$id.(empty($q)?'':'&'.$q)
			:$url.(empty($q)?'':'?'.$q)
		);
}

function urLang($b=''){	//имя колонки таблицы для url согласно текущему языку или указанному в $b
	global $lang,$Langs;
	if($b){return 'url'.($b==$Langs[0]?'':'_'.$b);}
	return 'url'.($lang==$Langs[0]?'':'_'.$lang);
}