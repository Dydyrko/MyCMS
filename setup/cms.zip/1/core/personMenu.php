<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

echo
'<ul style="border:solid 1px #ddd;padding:5px;margin: 5px 0 0 0;">'
	//.'<li><button onclick="location=\'/popolnit-balans\'">Пополнить баланс</button> '.$_SESSION['user']['balance'].' USD'
	.'<li><a href="/?p='.$_SESSION['user']['id'].'"><img src="/i/cat/-30/user.png" style=margin-right:8px> Кабинет'
		//.$_SESSION['user']['name']
	.'</a>'

	;
	if($_SESSION['user']['final']==-120){
		echo
		'<li title="Для отображения изменения потребуется обновить страницу">'
			.'<input class=v type=checkbox'.(isset($_SESSION['editMode'])?' checked':'').'>'
			.'<a  onclick="var e=previousSibling;e.checked=!e.checked;ajx(event,\'editMode\',e.checked)">Режим редактирования</a>'
	
		/*	//"мои" - товары, статьи: если выбранно, то отображается список ссылок на разделы объектов
		.'<dt><input type=checkbox'.(isset($_SESSION['user']['my'])?' checked':'').'><a onclick="'
			.'var n=previousSibling;n.checked=!n.checked,e=nextSibling;'
			.'return ajx(event,\'login\',\'&my=\'+n.checked,e)'		
			.'">Мои</a>'
		.'<div></div><img src="'.$host.'/i/b.gif" onload="var e=parentNode.firstChild;if(e.checked){e.checked=false;e.nextSibling.onclick()}" style=position:absolute>'
		*/
	
		.'<li><a href="/admin" target=_blank>Админка</a>'
		/*
		.'<dt><a href="/orders" target=_blank>Заказы</a>'
		.'<dt><a href="/suppliers" target=_blank>Поставщики</a>'
		.'<dt><a href="/'.sUrl(-1).'">Все товары</a>'
		.'<dt><a href="/csv">CSV импорт/экспорт</a>'
		*/
		.'<li><a href="/help/">HELP</a>'

		;
	}
	echo
	'<li><a onclick="ajx(event,\'login\',\'unset\',0,\'location=location\')"><img src="/i/cat/-30/exit.png"> Завершить сеанс</a>'
.'</dl>'
.'<a style="position:absolute;top:0;right:0;padding:5px" onclick="parentNode.parentNode.parentNode.previousSibling.onclick()">&times;</a>';