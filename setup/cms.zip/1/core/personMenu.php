<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

echo
'<ul style="border:solid 1px #ddd;padding:5px;margin:0;">'
	.'<li><a href="/?p='.$_SESSION['user']['id'].'"><svg><use href="/i/cat/-30/user.svg#a"></use></svg> Cabinet</a>';

	if($_SESSION['user']['final']==-120){
		echo
		'<li>'
			.'<label style="cursor:pointer">'
			.'<input type=checkbox'.(isset($_SESSION['editMode'])?' checked':'')
			.'  onclick="ajx(event,\'core_editMode\',checked,0,\'location.reload()\')">'	//true
			.' Edit mode</label>'
		.'<li>&uarr; <a href="/admin" target=_blank>Admin Panel</a>'
		.'<li>&uarr; <a href="/help/" target=_blank>HELP</a>';
	}

	echo
	'<li><a onclick="ajx(event,\'core_login\',\'unset\',0,\'location=(document.querySelector(\\\'.cabinet\\\')?\\\'/\\\':location)\')"><img src="/i/cat/-30/exit.png"> Exit</a>'
.'</dl>'
.'<a style="position:absolute;top:15px;right:5px;font-size:25px;line-height:0" onclick="parentNode.parentNode.parentNode.previousSibling.onclick()">&times;</a>';