<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

echo
'<ul style="border:solid 1px #ddd;padding:5px;margin: 5px 0 0 0;">'
	.'<li><a href="/?p='.$_SESSION['user']['id'].'"><img src="/i/cat/-30/user.png" style=margin-right:8px> Cabinet</a>';

	if($_SESSION['user']['final']==-120){
		echo
		'<li title="Refresh the page to see the change">'
			.'<input class=v type=checkbox'.(isset($_SESSION['editMode'])?' checked':'').'>'
			.'<a  onclick="var e=previousSibling;e.checked=!e.checked;ajx(event,\'core_editMode\',e.checked)">Edit mode</a>'	
		.'<li>&uarr; <a href="/admin" target=_blank>Admin Panel</a>'
		.'<li>&uarr; <a href="/help/" target=_blank>HELP</a>';
	}

	echo
	'<li><a onclick="ajx(event,\'core_login\',\'unset\',0,\'location=location\')"><img src="/i/cat/-30/exit.png"> Exit</a>'
.'</dl>'
.'<a style="position:absolute;top:15px;right:5px;font-size:25px;line-height:0" onclick="parentNode.parentNode.parentNode.previousSibling.onclick()">&times;</a>';