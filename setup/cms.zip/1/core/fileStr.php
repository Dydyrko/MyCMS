<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

function fileStr($row){	//id,cat,name,text,ord,v
	global $host,$lang;
	$row['name']=rawurlencode($row['name']);
	$t=substr($row['name'],strrpos($row['name'],'.'));
	if($lang=='ru'){
		$L=array('Нулевой статус (Новый)','Фотогалерея','Видео','Подтверждён','Слайд','Удалить файл');
	}else if($lang=='uk'){
		$L=array('Нульовий статус (Новий)','Фото','Відео','Підтверджено','Слайд','Видалити файл');
	}else{
		$L=array('Zero status (New)','Photo','Video','Confirmed','Slide','Delete File');
	}
	return
	'<div style="display:inline-block;vertical-align:top;width:80px;margin:6px 3px;background-color:#fff;border:solid 1px #999;padding:1px">'
		.(in_array($t,array('.css','.js','.svg'))?
			'<a onclick="'
			.'var n=document.createElement(\'DIV\');n.style=\'position:absolute;top:0px;left:0px;width:100%;height:100%;z-index:1\';parentNode.appendChild(n);'
			.'ajx(event,\'core_files\',\''.$row['cat'].'&edit='.$row['name'].'\',parentNode.lastChild'
			//.',\'if(jsAppend(\\\'ace\\\',0)===true){ace1()}\''
			.')">'.$row['name'].'</a>'
			//.'<div style="position:absolute;top:0px;left:0px;width:100%"></div>'
		:'')
		.'<a href="'.$host.'/i/cat/'.$row['cat'].'/'.$row['name'].'" target=_blank>'
			.'<img src="'.$host.(strtolower($t)=='.svg'?'/i/cat/'.$row['cat'].'/'.$row['name']:'/?img=/i/cat/'.$row['cat'].'/'.$row['name'].'&w=80&h=80&z&m').'">'
		.'</a>'
		.'<input name=name['.$row['id'].'] value="'.$row['text'].'"'
			.' title="'.$row['text'].'" style="width:100%"'
			.' oninput="style.backgroundColor=(value!=title?\'yellow\':\'\')"'
			.' onblur="ajx(event,\'core_files\',\''.$row['cat'].'&id='.$row['id'].'&text=\'+value,this,'
				.'\'if(txt==1){'
					.'var e=div.parentNode;e.parentNode.removeChild(e)'
				.'}else if(txt==2){'
					.'div.style.backgroundColor=null'
				.'}else{'
					.'alert(txt)'
				.'}\',
			1)">'
		.'<a onclick="var e=previousSibling;e.value=\'\';e.onblur()" style=float:right title="'.$L[5].'">&times;</a>'	//Удалить файл
		.'№<input size=2 value="'.$row['ord'].'" title="'.$row['ord'].'" style="text-align:center"'
		.' oninput="style.backgroundColor=(value!=title?\'yellow\':\'\')"'
		.' onblur="ajx(event,\'core_files\',\''.$row['cat'].'&id='.$row['id'].'&ord=\'+value,this,
			\'div.style.backgroundColor=null\',
		1)"'
		.'>'
		.'<select'
			.' onchange="style.backgroundColor=\'yellow\';'
				.'ajx(event,\'core_files\',\''.$row['cat'].'&id='.$row['id'].'&v=\'+value,this'
				.',\'div.style.backgroundColor=null\',1)"'
			.' style=width:100%>'
			.'<option value=0>'.$L[0]	//Нулевой статус (Новый, Для Служебного Пользования)'
			.'<option value=1'.($row['v']==1?' selected':'').'>'.$L[1]	//Фото'
			.'<option value=2'.($row['v']==2?' selected':'').'>'.$L[2]	//Видео'
			//.'<option value=-2'.($row['v']==-2?' selected':'').'>'.$L[3]	//Подтверждён (Для Служебного Пользования)'
			.'<option value=-1'.($row['v']==-1?' selected':'').'>'.$L[4]	//Слайд'

		.'</select>'
		.'<small style="cursor:pointer;line-height:100%;display: block;" onclick="var A=textContent.split(\' \'),d=A.join(\'T\');Alert(\'<h2>'.$row['text'].'</h2><input type=datetime-local data-d=\'+d+\' value=\'+d+\'><a onclick=\\\'var d=previousSibling.value;if(d!=previousSibling.dataset.d){ajx(event,`files`,`'.$row['id'].'&d=`+d)}\\\'> OK</a>\')">'.$row['d'].'</small>'
	.'</div>';
}