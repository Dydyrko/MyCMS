<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if($_POST['login']=='unset'){
	//unset($_SESSION);
	session_unset();
	unset($_COOKIE['PHPSESSID']);
	setcookie('PHPSESSID', '', time() - 3600, '/');
}else if($_POST['login']=='registration'){	//форма регистрации
	require '1/core/regForm.php';
	exit;
}else if(isset($_POST['personMenu'])){
	require '1/core/personMenu.php';
	exit;
}else if(isset($_POST['profile'])){	//Профиль персоны
	require '1/core/profile.php';
}else if(isset($_POST['test'])){	//проверка логина (mail), если успешно - то кнопка входа и поле id
	$L=array(
		'uk'=>array('Увійти','Логін','не знайдений'),
		'ru'=>array('Войти','Логин','не найден'),
		'en'=>array('Come in','Login','not found')
	);
	if(!isset($L[$lang])){$L[$lang]=$L['en'];}
	if($_POST['login']=='dev@'){
		echo '<input name=id value="'.$_POST['login'].'" type=hidden><button>'.$L[$lang][0].'</button>';
		exit;
	}
	$q='select id from person where mail="'.DB::esc($_POST['login']).'"';
	$r=DB::q($q);
	if(DB::num_rows($r)){
		$row=DB::f($r);
		echo '<div style="margin-bottom:15px"></div><input name=id value="'.$row['id'].'" type=hidden><button>'.$L[$lang][0].'</button>';
	}else{echo ''.$L[$lang][1].' «'.$_POST['login'].'» '.$L[$lang][2].'';}
}else if(isset($_POST['psw']) && !empty($_POST['id'])){		//проверка пароля по id персоны из input (чтобы дважды не искать по логину)
	require '1/core/loginPsw.php';
}else if($_POST['login']=='newPsw'){	//форма "Забыли пароль?" отправки e-mail для нового пароля
	$q='select '.DB::qL('adt').' from cat where id=-11';
	$row=DB::f(DB::q($q));
	echo $row['adt'];
}else if(isset($_POST['newPsw'])){	//выполнение формы отправки mail для нового пароля
	require '1/core/loginNewPsw.php';
}else if(empty($_POST['login'])){	//показать форму входа
	require '1/core/loginForm.php';
}

