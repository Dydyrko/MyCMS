<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

foreach($_POST['tel'] as $i=>$v){
	$q='select s from r where r='.$_SESSION['user']['id']	//для всех языков один набор телефонов — на основном языке
	.' and b=0 and c='.intval($i)	//порядковый номер телефона (возможно, начать не с нуля - чтобы предыдущие номера оставить для другой инфо)
	.' and a=-111';
	$r=DB::q($q);
	if(DB::num_rows($r)){
		if($v==''){
			//if($i>9){	//номер телефону
				$q='select count(*) as c from r where a=-111 and r='.$_SESSION['user']['id'];
				$row=DB::f(DB::q($q));
				//if($row['c']==1){exit('Один номер телефону має залишитись');}
			//}
			$q='delete from r where a=-111 and b=0 and c='.intval($i).' and r='.$_SESSION['user']['id'];
			DB::q($q);
			if($row['c']>1){exit('-1');}else{exit();}
			//exit('-1');
		}else{
			$q='update r set s="'.DB::esc($v).'" where a=-111 and b=0 and c='.intval($i).' and r='.$_SESSION['user']['id'];
		}
	}else{
		$q='insert into r set a=-111,b=0,c='.intval($i).',r='.$_SESSION['user']['id'].',s="'.DB::esc($v).'"';
	}
	DB::q($q);
}