<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(isset($_POST['del'])){
	if(unlink($root.'/1/tmp/db.txt')){echo 'Файл db.txt удалён';}
}else if(isset($_POST['delErr'])){
	if(unlink($root.'/1/tmp/err_db.txt')){echo 'Файл err_db.txt удалён';}
}else if(isset($_POST['err'])){
	$file=$root.'/1/tmp/err_db.txt';
	if(file_exists($file)){
		$A=file($file);
		echo count($A).' строк. <a onclick="ajx(event,\'dblog\',\'db&delErr=\',parentNode)">Удалить файл err_db.txt</a>';
		foreach($A as $i=>$v){
			$B=explode("\t",$v);
			if($B[0]){
				echo '<div style=background-color:yellow><small>'.$B[0].'</small> '.$B[1].'</div>';
				$j=0;
			}else{
				if($j==0){
					echo '<textarea>'.$B[1].'</textarea>';
				}else{
					echo $B[1].($j>2?', ':'<br>');
				}
				$j++;
			}
		}
		//echo implode('<br>',$A);
	}else{echo 'Файла err_db.txt нет';}
}else{
	$file=$root.'/1/tmp/db.txt';
	if(file_exists($file)){
		echo 'Ссылки на серии запросов с указанием длительности в мс:<br>';
		$A=file($file);
		$s='<div>'.count($A).' строк <a onclick="ajx(event,\'dblog\',\'db&del=\',parentNode.parentNode)">Удалить файл db.txt</a></div>';
		$n=0;
		foreach($A as $i=>$v){
			$B=explode("\t",$v);
			if(count($B)==1){
				$s.=($i==0?'':'</table><b>'.number_format($t,3).' мс</b>').'<a name="a'.$n.'" style=display:block;background-color:yellow>'.$B[0].'</a><table border=0>';
				if($i!=0){echo '<a title="'.$n.'" href="#a'.($n-1).'" style="display:inline-block;width:9%;padding:5px">'.number_format($t,0).'</a>'.($n%10?' ':'<br>');}
				$t=0;$n++;
			}else{
				$s.='<tr>';
				foreach($B as $j=>$a){
					$s.=($j==2?'<td width=50%><textarea style="width:100%">'.$a.'</textarea>':'<td'.($j==0?' style="color:#999;vertical-align:top"':'').'>'.$a);
				}
				$t+=$B[1];
			}
		}
		$s.='</table><b>'.number_format($t,3).' мс</b>';
		echo '<a href="#a'.($n-1).'" style=padding:5px>'.number_format($t,0).'</a> ';
		echo $s;
	}else{echo 'Файла db.txt нет';}
}