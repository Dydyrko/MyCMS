<?php	//проверка пароля персоны (id был получен при 'mail test')
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

	if(empty($_COOKIE['PHPSESSID'])){
		session_set_cookie_params([
			'lifetime' => 0,
			'path' => '/',
			'domain' => $_SERVER['HTTP_HOST'],
			'secure' => false,
			'httponly' => false,
			'samesite' => 'strict'
		]);
		session_start();
	}

	if($_POST['id']=='dev@' && $_POST['psw']=='@ @'){
		$_SESSION['user']['admin']='dev';
		echo 'dev';
		exit;
	}
	$_POST['id']=intval($_POST['id']);
	$q='select captcha,psw,new from person where id='.$_POST['id'];
	$r=DB::q($q);
	if(DB::num_rows($r)){
		$row=DB::f($r);
		$captcha=$row['captcha'];
	}else{exit('?');}

	if(!empty($captcha)
		 && (empty($_POST['captcha']) || empty($_SESSION['captcha']) || $_SESSION['captcha']!=$_POST['captcha'])
	){
		echo ' '.captcha();	//login.php
		exit('Captcha ?');
	}

	if(
		//$row['psw']==$_POST['psw'].(empty($_POST['code'])?'':"\t".$_POST['code'])
		password_verify($_POST['psw'],$row['psw'])
	){
		if($captcha){$q='update person set captcha=0 where id='.$_POST['id'];DB::q($q);}
		if($row['new']){$q='update person set new="" where id='.$_POST['id'];DB::q($q);}	//сброс временного пароля

		$q='select '.DB::qL('name').',img,final,v from cat where id='.$_POST['id'];
		$row=DB::f(DB::q($q));
		$_SESSION['user']['id']=$_POST['id'];
		$_SESSION['user']['name']=$row['name'];
		$_SESSION['user']['img']=$row['img'];
		$_SESSION['user']['final']=$row['final'];
		$_SESSION['user']['v']=$row['v'];
		/*
		$q='select balance from person where id='.$_POST['id'];
		$row=DB::f(DB::q($q));
		$_SESSION['user']['balance']=$row['balance'];
		*/
		if(in_array($_POST['id'],array(-201))){$_SESSION['user']['admin']='dev';echo 'dev';}	//вместо dev@
	
		//echo personMenu();	//1/functions.php если не перегружать страницу, то показать меню персоны
	}else{
		$q='update person set captcha=1 where id='.$_POST['id'];DB::q($q);
		$L=LangArray(-26);	//Тексти для мов
		echo	// 'Пароль не верный!';
		captcha()	//без id: 2=регистрация, 3=новый пароль
		.LangTxt('auErr',$L).
		'<br><a onclick="qNewPsw()">'.LangTxt('memGet',$L).'</a> ?';
	}