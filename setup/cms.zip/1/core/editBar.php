<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(isset($_POST['editBar'])){
	if(isset($_POST['adt'])){
		$q='update cat set adt'.($lang==$Langs[0]?'':'_'.$lang).'="'.DB::esc($_POST['adt']).'" where id='.intval($_POST['editBar']);
	}else if(isset($_POST['text'])){
		$q='update url set text'.($lang==$Langs[0]?'':'_'.$lang).'="'.DB::esc($_POST['text']).'" where id='.intval($_POST['editBar']);
	}else{
		exit('?');
	}
	DB::q($q);
	echo '<div style=padding:5px>'.DB::info().' <a onclick="parentNode.parentNode.removeChild(parentNode)" style="cursor:pointer;padding:15px">&times;</a></div>';
	exit;
}

echo
'<div class="editBar noselect" data-y="0" style="'.(empty($editBarPos)?'position:fixed;top:200px;left:0px':$editBarPos).';"
 ondragstart="return false"
 onmousedown="editBarMD(this)"
 ontouchstart="editBarMD(this,1)"
 onmouseup="dataset.m=dataset.y=0;"
 ontouchend="onmouseup();document.body.style.overflow=\'auto\'"
 onmousemove="console.log(event.type);if(dataset.y>0){dataset.m=\'1\';style.top=(event.clientY-dataset.y)+\'px\';}"
 ontouchmove="if(dataset.y>0){dataset.m=\'1\';style.top=(event.changedTouches[0].clientY-dataset.y)+\'px\';}"
>'
	.'<a title="Show/hide «'.(empty($editBarTitle)?'description':$editBarTitle).'» edit box"'
		.' onclick="var e=nextSibling;e.style.display=(e.style.display!=`none`?`none`:`initial`)"'
		.'>&#10148;</a>'
	.'<div class="editBar" data-id='.(isset($editBarId)?$editBarId:$_GET['p'])
		.(isset($editBarAdt)?' data-adt=1':'')
		.' style="display:inline-block;word-spacing:10px;padding-left:10px;display:none">';
		if(isset($editBarId) && $editBarId==-8){	//Home
				echo
				'<a onclick="
					var e=window.open(\''.$host.'/'.$lang.'/?ap=0'
					.'&t=root\''
					.',\'edit\',\'resizable,scrollbars,status\');
					e.focus();
				" title="Site structure in a separate browser window — editable">'
				.'/</a> ';
		}

		echo
		'<a onclick="'
			.'var e=window.open(\''.$host.'/'.$lang.'/?ae=\'+parentNode.dataset.id'
				.',\'edit\',\'resizable,scrollbars,status\');'
			.'e.focus();
		" title="Edit page data in a separate browser window"><tt class=sym>&#9874;</tt></a>
		
		<a onclick="'
			.'var e=window.open(\''.$host.'/'.$lang.'/?ap=\'+parentNode.dataset.id+\''
			.'&t='.(empty($editBarTitle)?'\'+document.title':$editBarTitle.'\'')	
			.',\'edit\',\'resizable,scrollbars,status\');
			e.focus();
		" title="List of subpages in a separate browser window — with the ability to edit, add, delete">'
		.'<tt class=sym>&#9776;</tt></a>';

		echo ' <a target="_blank" onclick="href=\'/'.$lang.'/zip?id=\'+parentNode.dataset.id"
		 title="Save text to archive file">ZIP</a>';
		
		echo ' <a onclick="ajx(event,\'files\',parentNode.dataset.id+\'&t='
			.(isset($editBarId)?catName($editBarId):htmlspecialchars($catName))
			.'\',0,\'jsAppend(\\\'screenfull\\\')\')"'
			.' title="Page file gallery"><tt class=sym>&#10048;</tt></a>';

		if(empty($noedit)){
			if($lang=='ru'){
				$L=array(
					'Проверка картинок.'."\n".' Если код картинки в тексте или на другом сервере,'
					.' то сохранить картинку в галерею файлов страницы.'
					.' Если путь к файлу абсолютный — то изменить на относительный: отобразится количество изменений.'
					."\n".' Так как картинок может быть несколько — повторите до сообщения «OK»'
					,'Редактор HTML в отдельном окне браузера'
				);
			}else if($lang=='uk'){
				$L=array(
					'Перевірка картинок.'."\n".' Якщо код зображення в тексті або на іншому сервері,'
					.' то зберегти картинку в галерею файлів сторінки.'
					.' Якщо шлях до файлу абсолютний — то змінити на відносний: відобразиться кількість змін.'
					."\n".' Так як картинок може бути кілька — повторіть до повідомлення «OK»'
					,'Редактор HTML в окремому вікні браузера'
				);
			}else{
				$L=array(
					'Checking pictures.'."\n".' If the image code is in the text (code «base64») or is on another server,'
					.' then saving the image to the page file gallery.'
					.' If the path to the file is absolute, then change it to relative: the number of changes will be displayed.'
					."\n".' Since there may be several pictures — repeat until the message «OK»'
					,'HTML editor in separate browser window'
				);
			}
			echo
			' <a onclick="imgSrc(this)" title="'.$L[0].'"'
				.' style="display:inline-block;vertical-align:middle;font-size:80%;line-height:11px">img<br>src</a>';

			echo
			' <a onclick="
				var t=parentNode.dataset.id,e=window.open(\''.$host.'/?htm&p=\'+t,\'edit\'+t,\'resizable,scrollbars,status\');
				e.focus();" title="'.$L[1].'">HTML</a>';
		}

		echo
		' <a onclick="
			var id=parentNode.dataset.id,'
			.'e=window.open(\''.$host.'/'.$lang.'/?css&p=\'+id'
				//.'+\'&t='.(empty($editBarTitle)?'\'+document.title':$editBarTitle.'\'')
				.',\'css\'+id'
				.',\'resizable,scrollbars,status\');
			e.focus();" title="CSS editor in a separate browser window">CSS</a>';

		echo
		' <a onclick="
			var id=parentNode.dataset.id,'
			.'e=window.open(\''.$host.'/'.$lang.'/?js&p=\'+id'
				//.'+\'&t='.(empty($editBarTitle)?'\'+document.title':$editBarTitle.'\'')
				.',\'js\'+id'
				.',\'resizable,scrollbars,status\');
			e.focus();" title="JS editor in a separate browser window">JS</a>';

		if(empty($noedit)){
			echo
			'<div style=height:10px></div>
			<label style="cursor:pointer" title="Edit '
				.(isset($editBarAdt)?'adt':'description')
				.(isset($editBarId)?' «'.catName($editBarId).'»':' page').'">
				<input class=v type=checkbox onclick="
				var e=parentNode.parentNode.parentNode.nextSibling;
				e.contentEditable=checked;
				if(checked){
					document.execCommand(\'defaultParagraphSeparator\', false, \'p\');
					e.focus();
				}
				parentNode.parentNode.lastChild.style.display=(checked?`inline`:`none`)
				"><tt class=sym style="font-size: 30px;line-height: 0;vertical-align: sub;">&#9997;</tt>
			</label>'

			.'<span style="display:none;padding-bottom:20px;line-height: 30px;">';	
				require $root.'/1/core/editTools.php';
				if($lang=='ru'){
					$L=array(
						'Сохранить HTML[F2]'."\n"
						.' *Содержимое элементов класса «noedit» — для заполнения скриптами — очищается,'
						.' значение «data-t» подставляется в фигурных кавычках'
						,'Сохранить'
					);
				}else if($lang=='uk'){
					$L=array(
						'Зберегти HTML[F2]'."\n"
						.' *Вміст елементів класу «noedit» — для заповнення скриптами — очищається,'
						.' значення «data-t» підставляється у фігурних лапках'
						,'Зберегти'
					);
				}else{
					$L=array(
						'Save HTML[F2]'."\n"
						.' *The contents of the elements of the "noedit" class — to be filled with scripts — are cleared,'
						.' the value "data-t" is substituted in curly quotes'
						,'Save'
					);
				}
				echo
				' <button class="Save" onclick="editBarSave(this)" style="margin:5px;width: auto;padding: 5px;"'
					.' title="'.$L[0].'">'.$L[1].'</button>'
				.'<span style="word-spacing:initial;color:#000;white-space:nowrap;background-color:#afa;margin:5px;display:inline-block;"></span>'
			.'</span>';
		}
	echo
	'</div>'
.'</div>';