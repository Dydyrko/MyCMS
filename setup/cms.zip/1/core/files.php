<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$_POST['files']=intval($_POST['files']);

if(isset($_POST['text']) && isset($_POST['id'])){
	$id=intval($_POST['id']);
	if($_POST['text']==''){	//удалить файл без текста
		$q='select name,cat from files where id='.$id;
		$row=DB::f(DB::q($q));
		$dir=$root.'/i/cat/'.$_POST['files'];
		$s=$dir.'/'.$row['name'];
		if(!unlink($s)){$E=error_get_last();echo '<li>'.$E['message'];};
		foreach(glob($s.'*.tmp') as $f){unlink($f);}
		$files=scandir($dir);	//в пустой папке 2 файла: . и ..
		if(count($files)==2){rmdir($dir);}
		$q='delete from files where id='.$id;DB::q($q);
		$q='ALTER TABLE files AUTO_INCREMENT = 1';DB::q($q);

		//$q='delete from fileAccess where file='.$id;DB::q($q);

		echo '1';	//файл удалён
	}else{			//изменение текста
		$q='update files set text'.($lang==$Langs[0]?'':'_'.$lang).'="'.DB::esc($_POST['text']).'" where id='.$id;
		DB::q($q);
		echo '2';	//изменён текст к файлу
	}
	exit;
}else if(isset($_POST['ord']) && isset($_POST['id'])){	//изменение очерёдности файлов
	$q='update files set ord="'.intval($_POST['ord']).'" where id='.intval($_POST['id']);
	DB::q($q);
	echo '3';	//$q;	//требуется любой ответ сервера кроме 1 и 2, может быть отображён alert(txt)
	exit;
}else if(isset($_POST['v']) && isset($_POST['id'])){	//изменение v
	$q='update files set v="'.intval($_POST['v']).'" where id='.intval($_POST['id']);
	DB::q($q);
	exit;
}else if(isset($_POST['edit'])){
	$file=$root.'/i/cat/'.($_POST['files']?$_POST['files'].'/':'').$_POST['edit'];
	if(isset($_POST['save'])){
		//var_dump($_POST);
		echo file_put_contents($file,$_POST['save']);
		exit;
	}
	$s=file_get_contents($file);
	echo
	'<form onsubmit="return false" style="height:100%;position:relative">'
		.'<div style="height:25px;background-color:#ddd">'
			.($_POST['files']?	//галерея
				'<input type=button onclick="var e=form.parentNode;e.parentNode.removeChild(e)" value="Close &times;" style="float:right">'
			:'');			//ajxAlert
			echo
			'<tt style="font-size:12px;padding:5px">/i/cat/'.($_POST['files']?$_POST['files'].'/':'').$_POST['edit'].'</tt>'
			.'<input type=button style="" value="Save" onclick="'
			.'ajx(event,\'core_files\',\''.$_POST['files'].'&edit='.$_POST['edit'].'&save=\'+encodeURIComponent(form.elements[\'text\'].value),nextSibling)">'
			.'<tt style="cursor:help" title="Bуtes saved" onclick="innerHTML=\'\'"></tt>'
		.'</div>'
		.'<textarea name=text style="display:block;width:100%;height:calc(100% - 30px);margin-top:-1px">'.$s.'</textarea>'
	.'</form>'
	;
	exit;
}else if(!empty($_POST['new'])){
	//var_dump($_POST);
	$file=$root.'/i/cat';
	if(!file_exists($file)){mkdir($file);}
	$file.='/'.$_POST['files'];
	if(!file_exists($file)){mkdir($file);}

	$q='select max(ord) as m from files where cat='.$_POST['files'];
	$row=DB::f(DB::q($q));
	if($row['m']){$m=$row['m'];}else{$m=0;}


	if($_POST['new']=='URL'){
		if(empty($_POST['name'])){exit('URL=?');}
		$s=file_get_contents(
			$_POST['name'],
			false,			//use_include_path
			stream_context_create(array('ssl' => array('verify_peer' => false, 'verify_peer_name' => false)))	//для самоподписанных SSL
		);
		if($s===false){exit('URL error: '.$_POST['name']);}

		$name=substr($_POST['name'],strrpos($_POST['name'],'/')+1);
		$q=strpos($name,'?');
		if($q){$name=substr($name,0,$q);}

		$name=rawurldecode($name);
		$name=mb_strtolower($name);
		require '1/core/translit.php';
		$name=translit($name);

		if(file_exists($file.'/'.$name)){
			//$name=uniqid().$name;
			$ext=substr($name,strripos($name,'.'));
			$i=0;
			do{		//перебор чисел для задания имени файла с проверкой наличия
				$i++;
				$name=$i.$ext;
				$f=$file.'/'.$name;
			}while(file_exists($f));
			$file=$f;
		}else{
			$file.='/'.$name;
		}

		$bytes=file_put_contents($file,$s);
		if($bytes===false){exit('URL file error');}
		//echo $bytes;
	}else if(!empty($_POST['dataimg']) || $_POST['new']=='base64'){
		if(!empty($_POST['dataimg'])){	//инструмент img/src
			$data=$_POST['dataimg'];
		}else{$data=$_POST['name'];}
		$A=explode(';', $data);		//['data:image/png','base64,…']
		if(empty($A[1])){exit('dataimg error');}
		$type=$A[0];
		$data=$A[1];
		$A=explode(',', $data);
		if(empty($A[1])){exit('dataimg error');}
		$data=$A[1];
		$data=base64_decode($data);
		if($type!='data:'){
			$ext=substr($type,strrpos($type,'/')+1);	//image/png	после слэша
			$n=strpos($ext,'+');
			if($n>0){$ext=substr($ext,0,$n);}	//svg+xml	до плюса
			if($ext!=''){$ext='.'.$ext;}
		}else{$ext='.b';}
		$i=0;
		do{		//перебор чисел для задания имени файла с проверкой наличия
			$i++;
			$name=$i.$ext;
			$f=$file.'/'.$name;
		}while(file_exists($f));
		$file=$f;
		$bytes=file_put_contents($file,$data);
		if($bytes===false){exit('dataimg saving error');}
	}else{
		$ext='.'.strtolower($_POST['new']);
		if(empty($_POST['name']) || file_exists($file.'/'.$_POST['name'].$ext)){
			//$name=uniqid().$ext;
			$i=0;
			do{		//перебор чисел для задания имени файла с проверкой наличия
				$i++;
				$name=$i.$ext;
				$f=$file.'/'.$name;
			}while(file_exists($f));
			$file=$f;
		}else{
			$name=$_POST['name'].$ext;
			$file.='/'.$name;
		}
	}

	if(touch($file)){	//при успешной установке файлу текущей даты (при отсутствии файл создаётся)
		$q='insert into files set d=NOW()'
		.',name="'.$name.'"'
		.',text="'.$name.'"'
		.',cat='.$_POST['files']
		.',ord='.($m+1)
		.',v=0';
		DB::q($q);
		if(isset($_POST['dataimg'])){	//инструмент img/src
			echo '/i/cat/'.$_POST['files'].'/'.$name;
		}else{
			require $root.'/1/core/fileStr.php';
			$row=array('id'=>DB::insert_id(),'cat'=>$_POST['files'],'name'=>$name,'text'=>$name,'ord'=>($m+1),'v'=>0,'d'=>'');
			echo fileStr($row);
		}
	}else{echo 'Err '.$file;}
	exit;
}else if(isset($_POST['d'])){
	$_POST['d']=DB::esc($_POST['d']);
	$q='update files set d="'.str_replace('T',' ',$_POST['d']).'" where id='.intval($_POST['files']);
	DB::q($q);
	echo'<h2>date</h2>'.DB::info();
	//var_dump($_POST);
	exit;
}

require $root.'/1/core/fileStr.php';
require $root.'/1/core/translit.php';

if(!isset($m)){
	$q='select max(ord) as m from files where cat='.$_POST['files'];
	$row=DB::f(DB::q($q));
	if($row['m']){$m=$row['m'];}else{$m=0;}
}
if(!empty($_FILES['file'])){
	//var_dump($_FILES['file']);
	//echo '<p>m='.$m.'</p>';
	$d=date('Y-m-d H:i:s');
	$pth='/i/cat';
	$obj=$_POST['files'];
	$Path=$root.$pth;
	if(!file_exists($Path)){mkdir($Path);}
	$Path.='/'.$obj;
	if(!file_exists($Path)){mkdir($Path);}
	$Path.='/';
	$A=$_FILES['file'];
	$S=array();
	foreach($A['name'] as $i=>$nm){
		if($A["error"][$i]!=0){echo 'err=',$A["error"][$i],'<br>';continue;}
		//$nm=basename($nm);	//для безопасности: если имя файла со слэшами
		$n=translit(mb_strtolower($nm,'UTF-8'));
		if($n=='.htaccess'){
			$n=$n.'.txt';
		}else{
			$n=str_replace('%','',$n);
			$n=str_replace('.php','.php.txt',$n);
			$n=str_replace('.pl','.pl.txt',$n);
		}
		if(file_exists($Path.$n)){$n=$n.'_'.uniqid();}
		if(move_uploaded_file($A["tmp_name"][$i],$Path.$n)){
			//echo '<li>Файл ',$n,' | ',$A["size"][$i],'&nbsp;байт<br><img src=/?img=',$pth.'/'.$obj.'/'.$n,'&w=60>';
			$q='insert into files set d="'.$d.'"'
			.',name="'.$n.'"
			,text="'.DB::esc($nm).'"
			,cat='.$obj
			.',ord='.($m+$i+1)
			;
			DB::q($q);

			$row=array('id'=>DB::insert_id(),'cat'=>$obj,'name'=>$n,'text'=>$nm,'ord'=>($m+$i+1),'v'=>1,'d'=>'');
			$S[]=fileStr($row);
		}else{echo "Error file uplpoad ",$n;}
	}
	echo implode('',$S);
	exit;
}

if($lang=='ru'){
	$L=array('Обновить','Файлы'
	,'URL, код base64 или имя нового файла (без расширения).'."\n".'Затем указать в списке — скопировать файл (URL) или создать (base64 или желаемый тип пустого файла)');
}else{
	$L=array('Refresh','Files'
	,'URL (file or base64 code) or name of the new file (without extension).'."\n".'Then specify in the list - to copy file (URL) or to create file — (base64 or type)');
}
echo
'<h2>'
	.'<a style="float:right;border: solid 1px #999;line-height:0;padding:10px 2px 14px;"'
		.' onclick="screenfull.toggle(parentNode.parentNode)" title="Screenfull">⤢</a>'
	.'<a onclick="ajx(event,\'core_files\',\''.$_POST['files'].'&t='.htmlspecialchars($_POST['t']).'\',parentNode.parentNode)" title="'.$L[0].'">'.$L[1].'</a> <small>'
	.($_POST['t']?'«'.$_POST['t'].'»':'')
	.' id='.$_POST['files'].'</small>'
	//.' <a onclick="var e=parentNode.nextSibling;ajxTo(this,e,function(){ajx(event,\'catEdit\','.$_POST['files'].',e,[ajxBtns],1)})"'
	//	.' title="Данные страницы id='.$_POST['files'].'">&#9874;</a>'
.'</h2>'
.'<div class=ajxSibling style="display:none"></div>'
//.'<a onclick="ajx(event,\'core_testFiles\',0,parentNode)" style=float:right>test</a>'
.'<form>'
	.'<input name=core_files value='.$_POST['files'].' type=hidden>'
	.'<input name=file[] type=file multiple style="max-width:224px;padding:2px;border:solid 1px #ddd"'
		.' onchange="ajxFormData(event,form,\'\',form.lastChild);ondragleave()"'
		.' ondragover="if(event.dataTransfer.items[0].kind==\'file\'){style.backgroundColor=\'yellow\'}"'
		.' ondragleave="style.backgroundColor=null"'
	.'>'
	.' <nobr><select name=new onchange="var n=form.elements[\'name\'];'
		.'if(!n.value && options.selectedIndex<3){options.selectedIndex=0;n.focus();return false}'
		.'if(options.selectedIndex){'
		.'ajxFormData(event,form,\'\',form.nextSibling);'
		.'options.selectedIndex=0;form.elements[\'name\'].value=\'\''
		.'}">'
		.'<option value=0>New file<option>URL<option>base64<option>SVG<option>CSS<option>JS'
	.'</select>'
	.'<input name=name title="'.$L[2].'"></nobr>'
	.'<div></div>'
.'</form><div></div>';

$q='select id,cat,name,'.DB::qL('text').',ord,v,d from files where cat='.$_POST['files'].' order by ord,text';
$r=DB::q($q);
while($row=DB::f($r)){
	echo fileStr($row);
}

