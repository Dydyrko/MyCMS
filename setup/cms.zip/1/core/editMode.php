<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

	if(isset($_POST['debug'])){
		if($_POST['editMode']=='false'){
			unset($_SESSION['debug']);
		}else{
			$_SESSION['debug']=1;
		}
	}else{
		if($_POST['editMode']=='false'){
			unset($_SESSION['editMode']);
			//echo 'Режим редагування вимкнено';
		}else{
			$_SESSION['editMode']=1;
			//echo 'Режим редагування включено';
		}
	}