<?php //index.php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(empty($_GET['p'])){	//HOME
	$_GET['p']=0;
	$q='select '.DB::qL('name').','.DB::qL('text').','.DB::qL('meta').' from cat left join url on cat.id=url.id where cat.id=-8';
	$Page=DB::f(DB::q($q));
	$Page['owner']=0;

	//временно: от отдельных переменных постепенно перейду на массив $Page
	//$meta=$Page['meta'];
	$pTitle=$catName=$Page['name'];
	$text=$Page['text'];
	$owner=0;

}else{
	$_GET['p']=intval($_GET['p']);
	$q='select parent,final,c,'.DB::qL('name').','.DB::qL('meta').',img,v,vimg,owner,d,d1,ord'
	.' from cat left join url on cat.id=url.id where cat.id='.$_GET['p'].' limit 0,1';
	$Page=DB::f(DB::q($q));
	$owner=$Page['owner'];
	$t=mb_substr($Page['name'],0,1,'utf-8');
	if($Page['name']=='' || $t==' '){$headerStr.='<meta name="robots" content="none"/>';}	//при отсутствии имени страницы, или если имя с пробела

	//от отдельных переменных постепенно перейду на массив $Page
	//$meta=$Page['meta'];
	$pTitle=$catName=$Page['name'];
	$catImg=$Page['img'];
	$catImgV=$Page['vimg'];	
	$catDate=$Page['d'];
	$catDate1=$Page['d1'];
	$final=$Page['final'];
	$vis=$Page['v'];	
	$parent=$Page['parent'];
	$cAll=$Page['c'];	//количество всех вложенных страниц

	$Parents=array($_GET['p']);	//массив id страницы и всех родителей страницы от ближайшего до корневого
	if($Page['parent']!=0){
		$Parent=array();
		function parent($parent){
			global $Parent;
			$q='select parent,'.DB::qL('name').',img from cat where id='.$parent.' limit 0,1';
			$row=DB::f(DB::q($q));
			$Parent[]=array('id'=>$row['parent'],'name'=>$row['name'],'img'=>$row['img']);
			return $row['parent'];
		}
		$n=$Page['parent'];
		while($n){$n=parent($n);}	//заполняем массив $Parent[id,name,img]

		$Parents[]=$Page['parent'];
		foreach($Parent as $i=>$v){if($v['id']){$Parents[]=$v['id'];}}
		$topParent=$Parents[count($Parents)-1];	//корневой раздел страницы


		$Crumb=array(	//"хлебные крошки"
			//$catName	//показывать ли имя страницы в Crumb
		);

		if(
			empty($_GET['cat'])		//категория товара для определённости при принадлежности товара к нескольким категориям (разделам каталога)
			&& $_GET['p']
			&& isset($final) && $final==2	//товар
		){
			$q='select a from r where r=-1 and b='.$_GET['p'].' order by s desc,a limit 0,1';
			$row1=DB::f(DB::q($q));
			$_GET['cat']=$row1['a'];	//категория товара
		}

		if(empty($_GET['cat'])){
			Crumb();			//функция в 1/core/functions.php
		}else{
			$A=itemCats($_GET['cat']);	//функция в 1/core/functions.php
			$Crumb=$A[0];
			$pTitle.=' — '.implode(' — ',$A[1]);
		}

		$Crumb=array_reverse($Crumb);

	}
	if(!empty($Page['c'])){
		$q='select count(*) as c from cat where v>0 and parent='.$_GET['p'];
		$row1=DB::f(DB::q($q));
		$cVis=	//от отдельных переменных постепенно перейду на массив $Page
		$Page['cVis']=$row1['c'];	//видимые вложенные страницы
	}
}