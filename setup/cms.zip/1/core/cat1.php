<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};
require $root.'/1/core/permit.php';

if(isset($_POST['cat1'])){
	$q='select id,'.DB::qL('name').',c,v,ord from cat where parent=0 order by ord,name';
	$r=DB::q($q);
	while($row=DB::f($r)){
		cat1($row);
	}
}

function cat1($row){
	$q='select count(*) as c from files where cat='.$row['id'];
	$files=DB::f(DB::q($q));
	$files=$files['c'];
	echo
	'<dt data-id='.$row['id'].'>'
		.($row['c']==0?'':'<a class="cat" title="subpages">'.$row['c'].'&darr;</a>')	//внутренние страницы
		.'<input class=v type=checkbox'.($row['v']>0?' checked':'').' value='.$row['v'].'><a class="v" title="v='.$row['v'].'"></a>'
		.'<input class="ord" value="'.$row['ord'].'" data-v="'.$row['ord'].'" style="width:4em;text-align:center" type=number title="ord">'
		.'<a class="catEdit" title="id='.$row['id'].'"'.($row['name']!=''?'>'.$row['name']:' title="Name is empty">id='.$row['id']).'</a>'
		.'<a class="files" title="files">'.($files?$files:'<tt class=sym>&#10048;</tt>').'</a>'
		.'<a class="catAdd" title="Add subpages"><tt class=sym>+</tt></a>'
		.'<a class="catDel" title="Delete"><tt class=sym>&times;</tt></a>'
		.'<div class=ajxSibling style="display:none;position:relative;margin:5px 5px 5px 25px"></div>';
}