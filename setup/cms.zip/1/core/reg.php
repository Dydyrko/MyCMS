<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$L=LangArray(-26);	//Тексти для мов

if(isset($_POST['agreement'])){
	$q='select '.DB::qL('adt').' from cat where id=-100';	//Кабинет
	$row=DB::f(DB::q($q));
	echo $row['adt'];
	exit;
}

if(!empty($_POST['mail'])){	//процесс регистрации
	if($_SESSION['captcha2']!=$_POST['captcha']){exit(' Капча?');}

	$txt='';$err='';
	$_POST['mail']=trim($_POST['mail']);	

	$A=explode('@',$_POST['mail']);$t=-1;
	if(count($A)==2){$t=getmxrr($A[1],$M);}else{echo' <div class="err">Mail?</div>';return;}
	if($t!==true){
		$err='<p>'
		.(
			$t===false?LangTxt('mxNotFound',$L).' «'.$A[1].'»':'«'.$_POST['mail'].'» — '.LangTxt('mailErr',$L)
		).'</p>';
	}else{
		$_POST['mail']=DB::esc($_POST['mail']);

		$q='select '.DB::qL('name').' from cat join person on cat.id=person.id where parent=-9 and mail="'.$_POST['mail'].'" limit 0,1';
		$r=DB::q($q);
		if(DB::num_rows($r)){		//Повторная проверка наличия email на случай одновременной регистрации
			$row=DB::f($r);
			$err.='<div>«'.$row['name'].'» '.LangTxt('mailExist',$L).' «'.$_POST['mail'].'»</div>';
		}else{
			$code=mt_rand(100,9999);
			$q='insert into cat set v=0,parent=-9,name="'.DB::esc($_POST['name']).'",d=NOW()'
			//.(empty($_POST['final'])?'':',final='.intval($_POST['final']))	//если при регистрации указывается тип пользователя
			;
			DB::q($q);
			$uid=DB::insert_id();
			if(!$uid){exit('uid?');}
			$q='insert into person set id='.$uid.',mail="'.$_POST['mail'].'",'
				.'new="'.password_hash($code,PASSWORD_BCRYPT).'"';
			DB::q($q);
			$q='update cat set c=c+1 where id=-9';DB::q($q);

			$q='select note,'.DB::qL('adt').','.DB::qL('name').' from cat where id=-27';	//Сообщение о регистрации на сайте
			$row=DB::f(DB::q($q));
			$mes=str_replace(
				array('{userName}','{code}','{root}','{uid}','{TITLE}'),
				array($_POST['name'],$code,'https://'.$_SERVER["SERVER_NAME"],$uid,$Conf['TITLE']),
				$row['adt']
			);

			$subject=$row['name'].' '.$_SERVER["SERVER_NAME"];	//Регистрация на сайте
			require '1/mailTo.php';
			mailTo($_POST['mail'],$subject,$mes);
			$txt.=LangTxt('regOK',$L);				//На Ваш email отправлено сообщение для завершения регистрации
			if(!empty($row['note'])){
				mailTo($row['note'],$subject.': '.$_POST['name'],$_POST['mail'].'<br>id='.$uid.'<br>ip='.$_SERVER['REMOTE_ADDR']);
			}
		}
	}
	if(!empty($err)){
		echo		//начинается с пробела — для отображения в последнем блоке формы
		' <div class="err">'.$err.'</div>';
	}else{
		echo		//текст формы
		'<div class="ok">'.$txt.'</div>';
		return;
	}

}