<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};
require $root.'/1/core/permit.php';

$_POST['catDel']=intval($_POST['catDel']);

if(isset($_POST['childs'])){	//удалить только вложенные страницы
	//var_dump($_POST);exit;
	$start=microtime(true);
	$Log=$Cats=array();	//вложенные разделы вглубь иерархии
	catIn($_POST['catDel'],'',$_POST['catDel']);
	$s=implode(',',$Cats);
	if($s){
		$q='delete from r where r in ('.$s.') or a in ('.$s.') or b in ('.$s.')';DB::q($q);
		$n=DB::affected_rows();	if($n){echo  '<p>Удалено из r: '.$n;}

		//$q='delete from item where id in ('.$s.')';DB::q($q);
		//$n=DB::affected_rows();	if($n){echo  '<p>Удалено из item: '.$n;}

		$q='delete from url where id in ('.$s.')';DB::q($q);
		$n=DB::affected_rows();	if($n){echo  '<p>Удалено из url: '.$n;}

		$q='delete from person where id in ('.$s.')';DB::q($q);
		$n=DB::affected_rows();	if($n){echo  '<p>Удалено из person: '.$n;}

		$q='delete from cat where id in ('.$s.')';DB::q($q);
	}
	
	echo '<p>Удалено страниц: '.DB::affected_rows()
	.'<br>'.number_format((microtime(true)-$start)*1000,0,',','').' ms';
	$q='ALTER TABLE cat AUTO_INCREMENT = 1';DB::q($q);
	$q='update cat set c=0 where id='.$_POST['catDel'];DB::q($q);
}else{
	$q='select parent,img,name from cat where id='.$_POST['catDel'];
	$row=DB::f(DB::q($q));
	$parent=$row['parent'];
	
	$Log=$Cats=array();	//вложенные разделы вглубь иерархии
	catIn($_POST['catDel'],$row['img']);
	$s=implode(',',$Cats);
	$c=0;
	if($s){
		$q='delete from r where r in ('.$s.') or a in ('.$s.') or b in ('.$s.')';DB::q($q);
			$c+=DB::affected_rows();
		//$q='delete from item where id in ('.$s.')';DB::q($q);
		//	$c+=DB::affected_rows();
		$q='delete from url where id in ('.$s.')';DB::q($q);
			$c+=DB::affected_rows();
		$q='delete from person where id in ('.$s.')';DB::q($q);
			$c+=DB::affected_rows();
		$q='delete from cat where id in ('.$s.')';DB::q($q);
	}
	echo '<h2>Удалена страница «'.stripslashes($row['name']).'» (id='.$_POST['catDel'].')</h2><p>Удалено страниц: '
	.DB::affected_rows().($c?' и '.$c.' в других таблицах, связанных с удалёнными страницами':'');
	$q='ALTER TABLE cat AUTO_INCREMENT = 1';DB::q($q);
	
	$q='select count(*) as c from cat where parent='.$parent;
	$row=DB::f(DB::q($q));
	$c=$row['c'];
	$q='update cat set c='.$c.' where id='.$parent;DB::q($q);
}

if(!empty($Log)){echo '<ol>Удалены файлы:<li>'.implode('<li>',$Log).'</ol>';}

function catIn($id,$img='',$x=0){	//$x=раздел, который не удалять (для удаления только внутр. страниц $x=$_POST['catDel'])
	global $Cats;
	if($id!=$x){
		$Cats[]=$id;		//список на удаление
		catFilesDel($id,$img);	//удалить файл раздела и галерею файлов
	}
	$q='select id,img from cat where parent='.$id.' limit 0,1000';
	$r=DB::q($q);
	while($row=DB::f($r)){
		catFilesDel($row['id'],$row['img']);
		catIn($row['id']);
		//if($catInCount<51){catIn($row['id']);}
	}
}

function catFilesDel($id,$img){
	global $Log;
	$dir=$_SERVER['DOCUMENT_ROOT'].'/i/cat';
	if($img){
		$s=$dir.'/'.$img;
		if(file_exists($s)){
			unlink($s);
			foreach(glob($s.'*.tmp') as $f){unlink($f);}
			$Log[]=$img;
		}
	}
	$q='select id,name from files where cat='.$id;
	$r=DB::q($q);
	if(DB::num_rows($r)){
		while($row=DB::f($r)){
			$s=$dir.'/'.$id.'/'.$row['name'];
			if(file_exists($s)){
				unlink($s);
				foreach(glob($s.'*.tmp') as $f){if(file_exists($f)){unlink($f);}}
			}
			if(file_exists($dir.'/'.$id)){
				$files=scandir($dir.'/'.$id);	//в пустой папке 2 файла: . и ..
				if(count($files)==2){rmdir($dir.'/'.$id);}
			}
			$q='delete from files where id='.$row['id'];DB::q($q);
			//$q='delete from fileAccess where file='.$row['id'];DB::q($q);	//Таблица для участника проекта: файл, персона, заметка
			//$q='delete from fileTop where id='.$row['id'];DB::q($q);	//таблица для указания файлу (id) для внутренней страницы проекта — id проекта (top)
	
			$Log[]=$id.'/'.$row['name'];
		}
		$q='ALTER TABLE files AUTO_INCREMENT = 1';DB::q($q);
	}
}