<?php
function echoJS($A){
	foreach($A as $i=>$v){
		$A[$i]=preg_replace('/\s\/\/.*$/','',$A[$i]);	// ! перед комментарием "//" должен быть пробельный символ
	}							// (табуляция или пробел) — чтобы отличить от "http://"
	$s=implode('',$A);
	$s=str_replace("\n",' ',$s);
	$s=preg_replace('/\/\*(.*?)\*\//', '', $s);		/*комментарии*/
	$s=preg_replace('/\s+/',' ', $s);			//пробелы на один
	$s=str_replace(array('{ ',' {'),'{',$s);
	$s=str_replace(array('} ',' }'),'}',$s);
	$s=str_replace(array('( ',' ('),'(',$s);
	$s=str_replace(array(') ',' )'),')',$s);
	$s=str_replace('; ',';',$s);
	$s=str_replace(', ',',',$s);
	$s=str_replace('= ','=',$s);
	$s=str_replace('[ ','[',$s);
	$s=str_replace(' ]',']',$s);
	$s=str_replace('\ ','',$s);	//убрать экран переноса строки (\n стал пробелом после замен)
	return $s;
}