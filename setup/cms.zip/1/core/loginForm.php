<?php	//аяксом отобразить форму входа (текст adt cat.id=-10)
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

	$onsubmit='onsubmit="loginSubmit(event,this);return false"';	//header.js
	$login='name="login" type="text" required oninput="'
		.'var n=form.lastChild;n.innerHTML=\'\';'	//инфо блок формы: сообщение или кнопка входа
		.'n.removeAttribute(\'data-i\');'
		.'n=nextSibling;n.style.display=(value.indexOf(\'@\')>0?\'block\':\'none\');'	//блок ввода пароля
		.'parentNode.className=\'\'"';
	$psw=' type="password" name=psw autocomplete=off required ondblclick="type=(type!=\'text\'?type=\'text\':type=\'password\')"'
		.' onclick="parentNode.parentNode.className=\'a\';oninput()"'
		.' oninput="'
			.'var t=this.form.elements[\'login\'].value,n=form.lastChild;'
			.'if(t.length && (!n.dataset.i || n.dataset.i!=t)){'	//первое нажатие или после изменения логина: поиск логина, если нет — блок пароля скрывается
				.'ajx(event,\'login\',t+\'&test=\',n,
				\'if(txt[0]==\\\'<\\\'){div.dataset.i=\\\'\'+t+\'\\\';}'
				.'else{div.dataset.i=\\\'\\\';div.parentNode.querySelector(\\\'.psw\\\').style.display=\\\'none\\\'}\'
				)'
			.'}'
		.'"';
	$registration='onclick="ajx(0,\'login\',\'registration\',0,\'document.querySelector(\\\'.reg\\\').elements[\\\'captcha\\\'].focus()\')"';
	$q='select '.DB::qL('adt').' from cat where id=-10';	//текст формы входа на всех языках
	$row=DB::f(DB::q($q));
	echo str_replace(array('{onsubmit}','{login}','{psw}','{registration}'),array($onsubmit,$login,$psw,$registration),$row['adt']);
