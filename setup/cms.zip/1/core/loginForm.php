<?php	//аяксом отобразить форму входа (текст adt cat.id=-10)
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

	$onsubmit='onsubmit="loginSubmit(event,this);return false"';	//header.js
	$login='name="core_login" type="text" required oninput="loginOnInput(this)"';
	$psw=' type="password" name=psw autocomplete=off required ondblclick="type=(type!=\'text\'?type=\'text\':type=\'password\')"'
		.' onclick="parentNode.parentNode.className=\'a\';oninput()"'
		.' oninput="pswOnInput(this)"';
	$registration='onclick="ajx(0,\'core_login\',\'registration\',0,\'document.querySelector(\\\'.reg\\\').elements[\\\'captcha\\\'].focus()\')"';
	$q='select '.DB::qL('adt').' from cat where id=-10';	//текст формы входа на всех языках
	$row=DB::f(DB::q($q));
	echo str_replace(array('{onsubmit}','{login}','{psw}','{registration}'),array($onsubmit,$login,$psw,$registration),$row['adt']);
