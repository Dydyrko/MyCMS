<?php
if(__file__==$_SERVER['SCRIPT_FILENAME']){header($_SERVER["SERVER_PROTOCOL"].' 404 Not Found');exit('404 Not found');};

require '1/core/translit.php';

$q='select adt,text,name from cat left join url on cat.id=url.id where cat.id='.intval($_GET['id']);
$row=DB::f(DB::q($q));

$t=$_GET['id'].'_'.translit(mb_strtolower($row['name'],'UTF-8'));

if($row['adt'] || $row['text']){
	$filename=$_SERVER['DOCUMENT_ROOT'].'/1/tmp';
	if(!is_dir($filename)){mkdir($filename,0777);}
	$filename.='/'.uniqid().'.zip';
	$zip=new ZipArchive();
	$zip->open($filename, ZipArchive::CREATE);

	$zip->addFromString($t.'.name.txt', $row['name']);
	if($row['adt']){$zip->addFromString($t.'.adt.txt', $row['adt']);}	
	if($row['text']){$zip->addFromString($t.'.txt', $row['text']);}

	//$zip->setArchiveComment(iconv('UTF-8','Windows-1251',$row['name']));
	
	$zip->close();
	header('Content-Type: application/zip');
	header('Content-Disposition: attachment; filename="'.$t.'.zip"');
	header('Content-Length: '.filesize($filename));
	readfile($filename);
	unlink($filename);
}else{echo '<h1>Текста нет</h1>';}

