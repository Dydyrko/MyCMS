<?php
if(__file__==$_SERVER['SCRIPT_FILENAME']){header($_SERVER["SERVER_PROTOCOL"].' 404 Not Found');exit('404 Not found');};

require $root.'/1/core/permit.php';

if(isset($_POST['favicon']) ){	//загрузка фавикона в блоке редактирования внизу страниц
	//var_dump($_FILES);
	if($_FILES['file']['error']==0){
		$t=$_FILES['file']['tmp_name'];
		$s=$_FILES['file']['name'];
		$s=substr($s,strrpos($s,'.'));
		$file=$root.'/favicon'.$s;
		if(file_exists($file)){unlink($file);}
		if(move_uploaded_file($t,$file)){
			echo '<div>Выполнено, размер файла: '.$_FILES['file']['size']
			.' <button type=button onclick="location.reload(true)">обновить</button></div>';
		}

	}
	exit;
}else if(isset($_POST['v'])){
	$A=array(
		1=>'✓ Обычная (v = 1)',
		2=>'☆ Особая (v = 2)',
		0=>'    Скрытая (v = 0)'
	);
	
	if($_POST['v']==='false'){	//снята птичка
		$q='update cat set v=0 where id='.intval($_POST['cat']);DB::q($q);
	}else if($_POST['v']==='true'){	//выбрана птичка
		echo '<style>
			.setV>li:hover{background-color:yellow;cursor:pointer}
		</style>'
		.'<h2>Указание статуса<br>странице id = '.$_POST['cat'].'</h2>'
		.'<ul class=setV style="list-style:none;min-width: 300px;text-align:left" onclick="'
			.'var e=event.target;'
			.'if(e.dataset.v===\'0\'){'
				.'ajxPointer.parentNode.style.backgroundColor=\'\';'
				.'var p=ajxPointer.previousSibling;'
				.'p.value=0;p.checked=false;'
				.'nextSibling.click();'	//кнопка "закрыть"
				.'return'
			.'}'
			.'if(!e.dataset.v){return}'
			.'ajx(event,\'cat\',\''.$_POST['cat'].'&v=\'+e.dataset.v,this,'
				.'\'ajxPointer.title=txt;'
					.'ajxPointer.parentNode.style.backgroundColor=\\\'\\\';'
					.'ajxPointer.previousSibling.value=\'+e.dataset.v+\';'
					.'div.nextSibling.click()\''
			.')
		">';
			foreach($A as $i=>$v){
				echo
				'<li style="margin-bottom:10px" data-v="'.$i.'">'.$v;
			}
 		echo '</ul>';

	}else{	//после доп.выбора
		if($_POST['v']=='false'){$_POST['v']=0;}
		$q='update cat set v='.$_POST['v'].' where id='.intval($_POST['cat']);DB::q($q);
		echo $A[$_POST['v']];
	}
	exit;
}
if(isset($_POST['ord'])){
	$q='update cat set ord='.intval($_POST['ord']).' where id='.intval($_POST['cat']);DB::q($q);
	exit;
}

$by=30;
$ord=(empty($_POST['order']) || $_POST['order']=='ord'?'ord,name,id':DB::esc($_POST['order']));
$q='select id,'.DB::qL('name').',c,v,ord from cat where parent='.intval($_POST['cat'])
	.(empty($_POST['like'])?'':
		($_POST['like']=='%'?' and name=""':' and name like "'.DB::esc($_POST['like']).'"')
	)
	.' order by '.$ord.' limit '.(empty($_POST['next'])?0:intval($_POST['next'])).','.$by;
$r=DB::q($q);
$n=DB::num_rows($r);
require $root.'/1/core/cat1.php';

if(empty($_POST['next']) && empty($_POST['like'])){
	$q='select LEFT(name,1) as f, count(*) as c from cat where parent='.intval($_POST['cat']).' group by f order by f';
	$r1=DB::q($q);
	$A=array();
	while($row1=DB::f($r1)){$A[]='<option title="'.$row1['c'].'">'.$row1['f'].'</sup>';}
	if($lang=='ru'){
		$L=array(
			'Исходная сортировка',
			'По алфавиту',
			'Последние записи — вверху',
			'Последние по дате — вверху',
			'Фильтр по первому символу'
		);
	}else if($lang=='uk'){
		$L=array(
			'Початкове сортування',
			'За алфавітом',
			'Останні записи — вгорі',
			'Останні за датою — вгорі',
			'Фільтр за першим символом'
		);
	}else{
		$L=array(
			'Initial sort',
			'Alphabetically',
			'Recent entries are at the top',
			'Last by date — top',
			'Filter by first character'
		);
	}
	echo
	'<div style="position:absolute;top:5px;left:5px">'
		.'<a onclick="var e=parentNode.nextSibling;e.dataset.ord=\'ord\';e=parentNode.parentNode;console.log(e);e.querySelector(\'.refresh\').click()"'
		.' title="'.$L[0].' (ord, name, id)">Sort</a>'
		.' by <a onclick="var e=parentNode.nextSibling;e.dataset.ord=\'name\';e=parentNode.parentNode;console.log(e);e.querySelector(\'.refresh\').click()"'
		.' title="'.$L[1].'">name</a>'
		.' • <a onclick="var e=parentNode.nextSibling;e.dataset.ord=\'id%20desc\';e.parentNode.querySelector(\'.refresh\').click()"'
		.' title="'.$L[2].'">id</a>'
		.' • <a onclick="var e=parentNode.nextSibling;e.dataset.ord=\'d%20desc\';e.parentNode.querySelector(\'.refresh\').click()"'
		.' title="'.$L[3].'">d</a>'
		.' • <select title="'.$L[4].'" onchange="var e=parentNode.nextSibling;e.dataset.like=selectedIndex>0?value+\'%\':\'\';ajx(event,\'cat\','.intval($_POST['cat']).'+\'&order=\'+e.dataset.ord+\'&like=\'+e.dataset.like,e)"><option value="">A-Z'.implode('',$A).'</select>'
	.'</div>'
	.'<dl class=cat data-ord="'.(empty($_POST['order'])?'ord':$_POST['order']).'" data-like="" data-n="'.$by.'">';
}

while($row=DB::f($r)){cat1($row);}

if(empty($_POST['next']) && empty($_POST['like'])){
	echo '</dl>';
	if($n==$by){
		echo
		'<a onclick="var e=previousSibling;ajx(event,\'cat\','.intval($_POST['cat']).'+\'&order=\'+e.dataset.ord+\'&like=\'+e.dataset.like+\'&next=\'+e.dataset.n,nextSibling,[divNext,catOrdEvt],1)"'
		.' style="display:block;margin-top:5px;text-align:center;border:outset 2px">Next</a><div data-next=1></div>';
	}
}

if(isset($_POST['next'])){
	echo "\n".$n."\t".$by;
}