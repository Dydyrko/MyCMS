<?php	//телефоны персоны
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

function phones($id,$a){
	global $host;
	$q='select '.DB::qL('name').','.DB::qL('adt').' from cat where id='.$a;
	$row=DB::f(DB::q($q));
	$name=$row['name'];$adt=$row['adt'];

	$q='select c,'.DB::qL('s').' from r where a='.$a.' and r='.$id.' order by c desc';	//a=Профиль персоны/Контакты/Телефоны
	$r=DB::q($q);
	$Tel=array();
	if(DB::num_rows($r)){
		while($row=DB::f($r)){
			$Tel[]=
			'<dt><input data-i="'.$row['c'].'" value="'.$row['s'].'" data-v="'.$row['s'].'"'
			.' oninput="style.backgroundColor=(value==dataset.v?\'\':\'yellow\')"'
			.' onblur="userEdit(event,this,\'tel[\'+dataset.i+\']\','.$id.')"'
			.'>'	//<img src="/i/edit_icon.png">'
			.' <img src="'.$host.'/i/delete.png" onclick="var p=parentNode,e=p.firstChild;e.value=\'\';e.onblur()" style="cursor:pointer">'	// style="cursor:pointer;position:absolute;right:-60px;bottom:10px;">'
			;
		}
	}else{
		$Tel[]=
		'<dt><input data-i="-1" value="" data-v="" placeholder="'.$adt.'"'
		.' oninput="style.backgroundColor=(value==dataset.v?\'\':\'yellow\')"'
		.' onblur="userEdit(event,this,\'tel[\'+dataset.i+\']\','.$id.')"'
		.'>'
		//.'<img src="/i/edit_icon.png">'
		;
	}
	echo
	'<style>.tel{display:inline-block}.tel dt{position: relative;}</style>'
	.'<div class="tel">'
		.'<dl style="margin-bottom:0"><span style="margin-bottom: 30px">'.$name.':</span>'
			.implode('',$Tel)
		.'</dl><a onclick="
			var e=previousSibling,n=e.lastChild,m=n.cloneNode(true),x=parseInt(n.firstChild.dataset.i);
			n=m.firstChild;
			n.dataset.i=x-1;n.value=n.dataset.v=\'\';
			e.appendChild(m);
			n.focus();
		" style="display:block"><img src="'.$host.'/i/add.png"> Добавить</a>'
        .'</div>';

}