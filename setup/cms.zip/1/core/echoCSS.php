<?php	//index.php: при отсутствии файла /css/ вывести из /1/css/ PHP с подстановкой значений цвета
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$C=file($root.'/1/css.ini');
if($C===false){exit('css.txt ?');};
foreach($C as $i=>$v){$C[$i]=trim($v);}
$t=substr($_SERVER["REQUEST_URI"],1,$n-1);	//$t='css/имя_файла'
if(!file_exists('1/'.$t.'.css.php')){exit('/1/'.$t.'.css.php ?');}

ob_start();
	require '1/'.$t.'.css.php';
	$s=ob_get_contents();
ob_end_clean();
header("Content-type: text/css; charset: UTF-8");
header('Expires: '.gmdate('D, d M Y H:i:s', time()+3600*24).' GMT');
header('Cache-Control: public');
header('MicroSecunds: '.number_format((microtime(true)-MICRO_TIME_START)*1000000,0,',',''));
echo $s;
