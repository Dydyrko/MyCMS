<?php
if(__file__==$_SERVER['SCRIPT_FILENAME']){header($_SERVER["SERVER_PROTOCOL"].' 404 Not Found');exit('404 Not found');};

if(empty($_COOKIE['PHPSESSID'])){
		session_set_cookie_params([
			'lifetime' => 0,
			'path' => '/',
			'domain' => $_SERVER['HTTP_HOST'],
			'secure' => false,
			'httponly' => false,
			'samesite' => 'strict'
		]);
	session_start();
}

if(empty($_SESSION['user']) || (empty($_SESSION['user']['admin']) && $_SESSION['user']['final']!=-120)){	//Форма авторизации админа
	echo
	'<!doctype html><html data-lang="'.$Langs[0].'" lang="'.$lang.'"><head>'
	.'<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">'
	.'<title>Admin — '.$Conf['TITLE'].'</title>'
	.'<meta name="viewport" content="width=device-width, initial-scale=1" />'
	.'<link rel="stylesheet" type="text/css" href='.$host.'/css/ajx.css>'
	.'<link rel="stylesheet" type="text/css" href='.$host.'/css/1.css>'
	.'<style>
		input{height:30px;width: 100%;margin-bottom:10px;text-align:center;border:solid 1px #ddd;}
		button{width: 100%;}
		a{cursor:pointer;}
	</style>'
	.'<script src='.$host.'/js/ajx.js></script>'
	.'<script src=/js/f.js></script>'
	.'<script src='.$host.'/js/header.js></script>'
	.'<body onload="document.querySelector(\'.login>a\').onclick()"><span class=login>';
		$L=array('en'=>'Login or register','uk'=>'Вхід або реєстрація','ru'=>'Вход или регистрация');
		echo
		'<a href="/'.$lang.'/'.sUrl(-9).'" title="'.$L[$lang].'"'
			.' onclick="ajx(event,\'core_login\',\'&regUrl=\'+href,0,
					\'div.getElementsByTagName(\\\'input\\\')[0].focus()\');return false">'
			//.'<img src="'.$host.'/i/cat/-30/user.png" style=padding:12px>'
			.'<svg style="max-width:100%"><use href="/i/cat/-30/user.svg#a"></use></svg>'
		.'</a></span>'
	.'<PROGRESS value=0></PROGRESS>';
	exit;
}

echo
'<!doctype html><html data-lang='.$Langs[0].' lang='.$lang.'><head>'
	.'<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">'
	.'<title>'.$_SESSION['user']['name'].' (adminPanel — '.$Conf['TITLE'].')</title>'
	.'<meta name="viewport" content="width=device-width, initial-scale=1" />'
	.'<link rel="stylesheet" type="text/css" href='.$host.'/css/ajx.css>'
	//.'<link rel="stylesheet" type="text/css" href='.$host.'/css/input.css>'
	.'<link rel="stylesheet" type="text/css" href='.$host.'/css/calendar.css>'
	.'<link rel="stylesheet" type="text/css" href='.$host.'/css/admin.css>'
	.'<link type="image/png" rel="shortcut icon" href="'.$host.'/favicon.png">';
	if(file_exists($root.'/js/lang_'.$lang.'.js')){
		echo '<script src='.$host.'/js/lang_'.$lang.'.js></script>';
	}else{
		echo '<script src='.$host.'/js/lang_en.js></script>';
	}
	echo
	'<script src='.$host.'/js/ajx.js></script>'
	.'<script src=/js/f.js></script>'
	.'<script src='.$host.'/js/translit.js></script>'
	.'<script src='.$host.'/js/calendar.js></script>'

	.'<script src='.$host.'/js/cabinet.js></script>'

	//.'<script src='.$host.'/js/screenfull.min.js></script>'
	.'<script src='.$host.'/js/screenfull.js></script>'

.'</head><body style="padding:0 5px 5px 5px">'

.'<PROGRESS value=0></PROGRESS>'

.'<dl class=cat style="resize: both;overflow: auto;padding-bottom:10px;display: inline-block;">'
	.'<dd class=cat>';
	$L=array('en'=>'Exit','uk'=>'Завершити сеанс','ru'=>'Завершить сеанс');
	if(empty($L[$lang])){$L[$lang]=$L['en'];}
	echo
	'<a class="exit sym" style="font-size:18px" title="'.$L[$lang].'">&larr;]</a>';	//&#10008;

	$L=array('en'=>'Refresh','uk'=>'Обновити сторінку','ru'=>'Обновить страницу');
	if(empty($L[$lang])){$L[$lang]=$L['en'];}
	echo
	' <a href="/'.($lang==$Langs[0]?'':$lang.'/').'admin" class=sym title="'.$L[$lang].'">&#8635;</a>';	//&#9850;

	$L=array('en'=>'Site editing mode','uk'=>'Режим редагування на сайті','ru'=>'Режим редактирования на сайте');
	if(empty($L[$lang])){$L[$lang]=$L['en'];}
	echo
	' <input class=v type=checkbox'.(isset($_SESSION['editMode'])?' checked':'')
		.'><a class="editMode sym" style="border-bottom: solid 1px #ddd;" title="'.$L[$lang].'">&#9874;</a>';	//&#9997; Writing Hand toptal.com/designers/htmlarrows/symbols

	$L=array(
		'en'=>'Cookie flag to turn off minimization of scripts, effective after clearing browser cache',
		'uk'=>'Позначка в куках вимкнення мінімізації скриптів, діє після очищення кешу браузера',
		'ru'=>'Отметка в куках выключения минимизации скриптов, действует после очистки кэша браузера'
	);
	if(empty($L[$lang])){$L[$lang]=$L['en'];}
	echo
	' <input class=v type=checkbox'.(empty($_COOKIE['js'])?'':' checked')
		.' onclick="document.cookie=\'js=\'+(checked?1:0)+\';path=/;samesite=strict\';">'
		.'<a style="border-bottom: solid 1px #ddd;height: 28px;display: inline-block" onclick=chk(this)'
			.' title="'.$L[$lang].'">js</a>';

	$L=array('en'=>'Open website page in a new window','uk'=>'Відкрити сторінку сайту у новому вікні','ru'=>'Открыть страницу сайта в новом окне');
	if(empty($L[$lang])){$L[$lang]=$L['en'];}
	echo
	' <a href=/'.($lang==$Langs[0]?'':$lang.'/').' target=_blank class=sym title="'.$L[$lang].'">&#8657;</a> ';	//9786

	$L=array(
		'en'=>'Language selection',
		'uk'=>'Вибір мови',
		'ru'=>'Выбор языка'
	);
	if(empty($L[$lang])){$L[$lang]=$L['en'];}
	echo
	' <select title="'.$L[$lang].'"'
		//.' style=float:right'
		.' onchange="'
			.'location.href=\'/\'+(value==\''.$Langs[0].'\'?\'\':value+\'/\')+\'admin\''	//язык по-умолчанию (uk) в URL не указывается
		.'">';
		foreach($Langs as $v){echo '<option value="'.$v.'"'.($lang==$v?' selected':'').'>'.$v;}
	echo
	'</select>';
	//.'<a onclick="notificationOn()">notificationOn</a>'

	$L=array(
		'en'=>'Check for existence and size of files',
		'uk'=>'Перевірити наявність та розмір файлів',
		'ru'=>'Проверить наличие и размер файлов'
	);
	if(empty($L[$lang])){$L[$lang]=$L['en'];}
	echo
	'<dd class=cat>'
		.' <a class="testFiles sym" style="font-weight:700" title="'.$L[$lang].'">'
			//.'&#128247;'	//📷
			.'<svg viewBox="0 0 487 487" width="24" xmlns="http://www.w3.org/2000/svg">'
				.'<use href="/i/cat/-10/camera.svg#a"></use>'
			.'</svg>'
		.'</a>';

		$L=array('en'=>'Website navigation log','uk'=>'Журнал переходів на сайт','ru'=>'Журнал переходов на сайт');
		if(empty($L[$lang])){$L[$lang]=$L['en'];}
		echo
		' <a class="log" title="'.$L[$lang].'">Log</a>'
		.' <a class="mailLog sym" title="mailLog" style="font-size: 28px">&#9993;</a>'
		.' <a class="sitemap sym" title="Sitemap">'
			//.'&#127760;'	//🌐
			.'<svg viewBox="0 0 18 18" width="22" height="22" xmlns="http://www.w3.org/2000/svg">'
				.'<use href="/i/cat/-10/globus.svg#a"></use>'
			.'</svg>'
		.'</a>'
		;
		if(file_exists($root.'/1/orders.php')){echo ' <a href=/orders target=_blank>Orders</a>';}

		echo ' <a onclick="var e=g(\'content\');ajx(event,\'core_sql\',\'cache\',e)"
		 style="display: inline-block;vertical-align: middle;line-height: 14px;font-size: 14px;text-align: center;"
		title="Clear server cache [id: Url]">Clear<br>cache</a>';

		/*echo'<select id=CKEdit style="float:right;font-size:11px">'
			.'<option value=4>CKEditor 4<option value=5>CKEditor 5'
		.'</select>';*/

		echo ' <a href=/help target=_blank style=padding-right:5px title=Help>?</a>';

	if(isset($_SESSION['user']['admin']) && $_SESSION['user']['admin']=='dev'){
		echo
		'<dd class=cat>'
			.'<div style="color:#999;font-size:12px;">'
				.'<tt title="SERVER_SOFTWARE" style="cursor:help">'.$_SERVER['SERVER_SOFTWARE'].'</tt> '
				.'<tt title="timezone (index.php)" style="cursor:help">'.date_default_timezone_get().'</tt>'
			.'</div>'
			.'<input class=v type=checkbox'.(isset($_SESSION['debug'])?' checked':'')
				.'><a class=debug title="Debug SQL mode">debug</a>'
			//.' <a class="dblog" title="Журнал изменений БД">DbLog</a>'	//если указывать триггеры таблицам
	
			.' <a onclick="var e=g(\'content\');ajx(event,\'core_sql\',\'\',e)">Sql</a>'
			.' <a onclick="var e=g(\'content\');ajx(event,\'core_sql\',\'session\',e)" title="Session PHP">S</a>'
			.' <a onclick="var e=g(\'content\');ajx(event,\'core_sql\',\'phpinfo\',e)" title="phpinfo">Php</a>'
			.' <a onclick="'
				.'jsAppend(\'aceF\');'
				.'var e=g(\'content\');ajx(event,\'core_sql\',\'files\',e)'
				.'" title="Files" class="sym" style="font-size: 24px;">💾</a>'	//🛄 💾 💽 📀 💿
	
			.(file_exists($root.'/1/tmp/db.txt')?' <a class="db" title="Database query log">Db</a>':'')
			.(file_exists($root.'/1/tmp/err_db.txt')?' <a style="color:red" class="errdb" title="Database errors log">Err</a>':'');

		$t=ini_get('error_log');
		if(file_exists($t)){
			$s=filesize($t);
			if($s>15){
				echo ' <a title="PHP error_log" onclick="ajx(event,\'core_css\',\'errLog&t='.$t.'\')">'.filesize($t).'</a>';
			}
		}
	}

	if(!empty($_SESSION['user']['id']) && isset($_SESSION['user']['name'])){	//не dev@
		echo ' <a onclick="ajx(0,\'core_login\',\''.$_SESSION['user']['id'].'&p=-93&profile\',g(\'content\'))"'
		.' style=padding-right:5px title="'.DB::esc($_SESSION['user']['name']).'">PsW</a>';
	}

	echo
	'<dd class=cat>'
		.'<input title="Search" size=3 placeholder="🔎 id" style="text-align:center"'
			.' onblur="var e=g(\'content\'),t=value;if(t){ajx(event,\'core_catEdit\',t,e)}"'
			.' onkeyup="if(event.keyCode==13){onblur()}">'
		.' <a class="add sym" title="Add root page">+</a>'
		.'<a class="refresh" style="float:right" title="Refresh"></a>'
	.'</dd>'
	.'<div class="cat" style="padding-top:10px">'
	;	
		require $root.'/1/core/cat1.php';
		$q='select id,'.DB::qL('name').',c,v,ord from cat where parent=0 order by ord,name';
		$r=DB::q($q);
		while($row=DB::f($r)){
			cat1($row);
		}
	echo
	'</div>'
.'</dl>'
.'<div id=content></div>'
.'<script src="'.$host.'/js/admin.js"></script>'
.'</html>';