<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(empty($_SESSION['user']['admin']) || $_SESSION['user']['admin'] !='dev'){exit;}

if(!empty($_POST['sql'])){
	//var_dump($_POST['sql']);
	if($_POST['sql']=='phpinfo'){
		phpinfo();
		exit;
	}else if($_POST['sql']=='session'){
		echo '<pre>';
		var_dump($_SESSION);
		//var_dump(session_get_cookie_params());
		echo '</pre>';
		exit;
	}else if($_POST['sql']=='cache'){
		$dir=$root.'/1/tmp/cache';
		if(file_exists($dir)) {
			$A=array();
			$s=strlen($root);
			foreach (glob($dir.'/*') as $file) {
				$A[]='<li>'.substr($file,$s);
				unlink($file);
			}
			if(empty($A)){
				echo 'Cache empty';
			}else{
				echo 'Deleted cache files:<ol>'.implode('',$A).'</ol>';
			}
		}else{echo 'Not exists '.$dir;}
		exit;
	}else if($_POST['sql']=='files'){
		if(isset($_POST['file'])){
			//var_dump($_POST);
			echo file_get_contents($root.$_POST['file']);
			exit;
		}else if(isset($_POST['saveFile'])){
			//var_dump($_POST);
			$fileName=$root.$_POST['saveFile'];
			if(file_exists($fileName)){
				$s=rename($root.$_POST['saveFile'],$root.$_POST['saveFile'].'.bak');
				if(!$s){$E=error_get_last();exit($E['message']);}
			}
			$s=file_put_contents($root.$_POST['saveFile'],$_POST['t']);
			if($s){echo 'Файл '.$_POST['saveFile'].' сохранён ('.$s.' байт)';}
			exit;
		}else if(isset($_POST['delFile'])){
			//var_dump($_POST);
			if(unlink($root.$_POST['delFile'])){echo '<b>Удалён файл '.$_POST['delFile'].'</b>';}
			else{$E=error_get_last();echo $E['message'];}
			exit;
		}
		if(isset($_POST['dir'])){
			$dir=$_POST['dir'];
			//$A=explode('/',$dir);
			//if(array_pop($A)=='..'){array_pop($A);$dir=implode('/',$A);}
		}else{
			$dir='';
		echo '<ol data-dir="'.$dir.'/'.'" style="margin:0;float:left;height:100%;overflow-y:auto"'
			.' onclick="var e=event.target;if(e.tagName==\'A\'){
				if(e.dataset.t==\'dir\'){
					var dir=dataset.dir,A=dir.split(\'/\');
					if(e.textContent==\'..\'){A.pop();A.pop();console.log(A);dir=A.join(\'/\')+\'/\';console.log(dir);}else{dir+=e.textContent+\'/\'}
					ajx(event,\'core_sql\',\'files&dir=\'+dir,this,\'div.dataset.dir=\\\'\'+dir+\'\\\'\')
				}else if(e.dataset.t==\'del\'){
					var n=e.parentNode.parentNode,fName=n.firstChild.textContent;
					if(confirm(e.title+\' «\'+fName+\'»?\')){
						ajx(event,\'core_sql\',\'files&delFile=\'+n.parentNode.dataset.dir+fName,n)
					}
				}else{
					ace1(nextSibling,e.textContent);ajx(event,\'core_sql\',\'files&file=\'+dataset.dir+e.textContent,nextSibling.lastChild,ace2,1)
				}
			}">';
		}
		$A=scandir($root.$dir);

			echo $dir;
		foreach($A as $i=>$v){
			if($v=='.'){continue;}
			if((!$dir || $dir=='/') && $v=='..'){continue;}
			$f=$root.$dir.'/'.$v;
			if(is_dir($f)){
				echo '<li style="background-color:#eee"><a data-t="dir">'.$v.'</a>';
			}else if(is_file($f)){
				echo '<li><a>'.$v.'</a><tt><b>'.(filesize($f)/1000).'</b> '
				.date ("Y.m.d H:i:s",filemtime($f)).' <a data-t=del title="Удалить файл" style=font-size:18px>&times;</a></tt>';
			}else{
				echo '<li style="background-color:yellow">'.$v;
			}
		}
		if(!isset($_POST['dir'])){
			echo '</ol><div><b></b></div>';
		}
		exit;
	}else if(isset($_POST['del'])){
		if(unlink($_POST['sql'])){
			echo 'Файл «'.$_POST['sql'].'» удалён';
		}else{
			echo '«'.$_POST['sql'].'» ?';
		}
		exit;
	}else if(isset($_POST['f'])){
		$t=file_get_contents($_POST['sql']);
		if($t){
			$t=str_replace("\n\t",'<dd>',$t);
			$t=str_replace("\n",'<dt>',$t);
			echo '<dl><dt>'.$t.'</dl>'
			.'<a onclick="var e=g(\'content\');ajx(event,\'core_sql\',\''.$_POST['sql'].'&del=\',e)" style="color:red">Удалить файл</a>';
		}else{
			echo '«'.$_POST['sql'].'» ?';
		}
		exit;
	}else if($_POST['sql']=='jsCook'){	//не минимизировать файлы JS
		if($_POST['v']=='true'){
			setcookie('js','1');
		}else{
			setcookie('js','0');
		}
		exit;
	}

	if($_POST['m']=='true'){
		$A=explode(';'."\n",$_POST['sql']);
	}else{
		$A=array($_POST['sql']);
	}
	$R=array('<h2>SQL</h2>');
	foreach($A as $i=>$v){
		if($v==''){continue;}
		$R[]='<h3 title="Первые 80 символов">'.mb_substr($v,0,80).'</h3>';
		$r=DB::q($v);
		if($r){
			$R[]='<ol style="text-align:left">';
			if($r===true){
				$R[]='<li>affected_rows='.DB::affected_rows($r);
				$R[]='<li>insert_id='.DB::insert_id($r);
				$R[]='<li>info='.DB::info();
			}else{	// SELECT, SHOW, DESCRIBE или EXPLAIN
	
				while($row=DB::f($r)){
					$R[]='<li>'.($_POST['p']=='true'?'<pre>':'').print_r($row,true).($_POST['p']=='true'?'</pre>':'');
				}
			}
			$R[]='</ol>';
		}
	}
	echo implode('',$R);
	exit;
}
echo
'<div>'
	.'<textarea style=width:100%></textarea>'
	.'<input type=button onclick="
		var t=previousSibling.value,p=nextSibling.firstChild.checked,m=nextSibling.nextSibling.firstChild.checked;
		if(t){ajx(event,\'core_sql\',encodeURIComponent(t)+\'&p=\'+p+\'&m=\'+m)}
	" value="SQL" style=width:100%>'
	.'<label><input type=checkbox> PRE</label>'
	.'<label title="Список запросов, завершающихся ; в конце строки" style="float:right">'
		.'<input type=checkbox style="display:inline"> Multi</label>'
	.'<dl style=margin-top:15px>'
	.'<dt>Служебные страницы'
		.'<dd><a onclick="sqlTxt(this)">SELECT version()</a>'
			.' • <a onclick="sqlTxt(this)">SELECT @@GLOBAL.sql_mode</a>'
			.' • <a onclick="sqlTxt(this)">SELECT @@session.sql_mode</a>'
		.'<dd><a onclick="sqlTxt(this)">SET sql_mode="ERROR_FOR_DIVISION_BY_ZERO"</a>'
		.'<dd><a onclick="sqlTxt(this)">SHOW TABLES</a>'
			.' • <a onclick="sqlTxt(this)">CHECK TABLE cat</a>'
		.'<dd><a onclick="sqlTxt(this)">DESCRIBE cat</a>'
			.' • <a onclick="sqlTxt(this)">SHOW CREATE TABLE cat</a>'
			.' • <a onclick="sqlTxt(this)">ALTER TABLE cat AUTO_INCREMENT = 1</a>'
		.'<dd><a onclick="sqlTxt(this)">SELECT database()</a>'
			.' • <a onclick="sqlTxt(this)">SHOW VARIABLES</a>'
		.'<dd><a onclick="sqlTxt(this)">SHOW FUNCTION STATUS where Db=database()</a>'
		.'<dd><a onclick="sqlTxt(this)">SHOW CREATE FUNCTION transliterate_func</a>'

		.'<dd><a onclick="sqlTxt(this)">select id,name from cat where id<0</a>'
		.'<dd><a onclick="sqlTxt(this)">update url set text=REPLACE(text, \'Искомый_текст\', \'Текст_вместо_искомого\')</a>'
	.'<dt>Количество страниц для поисковиков'
		.'<dd><a onclick="sqlTxt(this)">select count(*) as c from cat join url on cat.id=url.id where cat.v=1 and url<>""</a>'
	/*
	.'<dt>Количество товаров для поисковиков'
		.'<dd><a onclick="sqlTxt(this)">select count(*) as c from cat join url on cat.id=url.id where cat.v=1 and cat.final=2 and url<>""</a>'
	.'<dt>Категории (списки товаров)'
		.'<dd><a onclick="sqlTxt(this)">select id,name from cat where final=1 order by name</a>'
	.'<dt>Категории, содержащие характеристику "Производитель"'
		.'<dd><a onclick="sqlTxt(this)">select name,r,b from r join cat on r.r=cat.id where a=11 and final=1</a>'
	.'<dt>Категории, НЕ содержащие характеристику "Производитель"'
		.'<dd><a onclick="sqlTxt(this)">select name,r,b from cat left join r on r.r=cat.id  and a=11 where final=1 and r is null</a>'
	.'<dt>Курсы валют поставщиков'
		.'<dd><a onclick="sqlTxt(this)">select cat.name,r.b,r.c from r join cat on r.r=cat.id where r.a=12 order by name</a>'
	*/
	.'<hr>'
	.'<dt>Удаление связей с отсутствующими страницами'
		.'<dd><a onclick="sqlTxt(this)">delete r FROM `r` left join cat on r.a=cat.id WHERE a>0 and cat.id is null</a>'
		.'<dd><a onclick="sqlTxt(this)">delete r FROM `r` left join cat on r.b=cat.id WHERE b>0 and cat.id is null</a>'
	/*
	.'<dt>Переход на вариант указания "ВСЕ значения" характеристике товара в категории'
		.'<dd><a onclick="sqlTxt(this)">select r.a,r.b from r join cat on r.r=cat.id where cat.final=1 and r.b!=r.a</a>'
		.'<dd><a onclick="sqlTxt(this)">update r join cat on r.r=cat.id set b=a where cat.final=1</a>'
		.'<dd><a onclick="sqlTxt(this)">delete A from cat A join cat P on A.parent=P.id where A.v=2 and A.name="Все" and P.parent=-11</a>'
	*/
	.'</dl>'
.'</div>';

