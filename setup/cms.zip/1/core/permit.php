<?php	//разрешить только авторизованному админу
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(
	!(isset($_SESSION['user']['admin']))	//dev
	&&
 	!(isset($_SESSION['user']['final']) && $_SESSION['user']['final']==-120)	//тип пользователя Администратор
){exit('No permission');}