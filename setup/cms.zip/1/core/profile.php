<?php	//Профиль персоны
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

//echo $owner;
if(empty($_GET['p'])){$_GET['p']=$_POST['login'];}
if(!(	//только авторизованному с id=id страницы. Админ в режиме редактирования может открыть - при этом он становится авторизованным с id=id страницы.
	isset($_SESSION['user']['id']) && $_SESSION['user']['id']==$_GET['p']
)){exit('Требуется авторизация');}

function uType($uType=-115){	//Актуальные поля кабинета клиента в зависимости от типа клиента (по умолчанию Гость=-115).
	global $subhost,$curN;	//Функция используется здесь (if $_POST['p']==-93) и в 1/profileSet.php
	$q='select b from r where a=-91 and r='.$uType.(empty($subhost)?'':' and c=-'.$curN);	//a=Общая информация кабинета, r=Тип пользователя:Гость по умолчанию, c=номер поддомена (по таблице курсов валют для них) со знаком минус
	$r=DB::q($q);
	$A=array();
	while($row=DB::f($r)){$A[]=$row['b'];}	//Значения для первого типа в select

	$q='select id,'.DB::qL('name').' from cat where parent=-91 and v=1 order by ord,name';
	$r=DB::q($q);
	$B=array();
	while($row=DB::f($r)){
		$B[]='<dt><input value='.$row['id']
		.(in_array($row['id'],$A)?' checked':'')
		.' type=checkbox><a onclick="chk(this)">'.$row['name'].'</a>';
	}
	return implode('',$B);
}
if(isset($_POST['profile'])){	//вызов файла из login.php
	//var_dump($_POST);
	if(isset($_POST['p']) && $_POST['p']==-92 && empty($_POST['profile'])){	//Контакты
		require $root.'/1/core/profileCont.php';
	}else if(!empty($_POST['psw'])
		// && isset($_POST['psw0'])
		){	//Смена пароля
		require $root.'/1/core/profileSetPsw.php';
	//}else if(isset($_POST['p']) && $_POST['p']==167 && !empty($_POST['profile'])){	//Способ доставки. Настройка для доменов (стран)
	//	require $root.'/1/profileSetDelivery.php';
	}else if(isset($_POST['p']) && $_POST['p']==-93){	//Настройки
		require $root.'/1/core/profileSet.php';
		/*
		if(in_array($_SESSION['user']['final'],array(-116,-117))){	//поставщик товаров
			require $root.'/1/ajx/profileCurrency.php';
		}
		if(!empty($_SESSION['user']['admin']) || isset($_SESSION['user']['final']) && $_SESSION['user']['final']==-120){
			require $root.'/1/profileSetAdmin.php';	//Настройка наборов опций (со статусом 1) общей информации (id=-91) профиля
		}
		*/						//по опциям "тип пользователя" (id=-112) — указывается тип клиенту в поле cat.final
	//}else if(isset($_POST['curRate'])){	//запись курсов валют товаров. r=userId,a=(12=грн,13=руб,14=BYN) валюта (под)домена, b=(-1=usd,-2=eur, -3=rub), c=курс со знаком минус
	//	require $root.'/1/ajx/profileCurrencySave.php';
	//}else if(isset($_POST['p']) && $_POST['p']==-94){	//Рейтинг
	//	echo 'Рейтинг';

	}else if(isset($_POST['catName'])){	//имя клиента и adt
		$q='update cat set '.DB::esc($_POST['catName']).($lang==$Langs[0]?'':'_'.$lang).'="'.DB::esc($_POST['profile']).'" where id='.$_SESSION['user']['id'];
		DB::q($q);
	}else if(!empty($_POST['profile']) && !empty($_POST['a'])){	//save r.s_'.$lang	//геопозиция в s_ru
		$_POST['profile']=DB::esc($_POST['profile']);	//s
		$_POST['a']=intval($_POST['a']);	//a
		$q='select '.DB::qL('s').' from r where a='.$_POST['a'].' and r='.$_SESSION['user']['id']	//Слоган клиента
		.' and b=0 limit 0,1';
		$r=DB::q($q);
		if(DB::num_rows($r)){
			$row=DB::f($r);
			if($row['s']!=$_POST['profile']){
				$q='update r set s'.($lang==$Langs[0]?'':'_'.$lang).'="'.$_POST['profile'].'" where a='.$_POST['a'].' and b=0 and r='.$_SESSION['user']['id'];
				DB::q($q);
			}
		}else{
			$q='insert into r set s'.($lang==$Langs[0]?'':'_'.$lang).'="'.$_POST['profile'].'",a='.$_POST['a'].',b=0,r='.$_SESSION['user']['id'];
			DB::q($q);
		}
		echo $q;
	}else if(isset($_FILES['file_cat'])){	//Save Общая информация
		$L=array('uk'=>array('Загружений файл ','Файл видалений'),'ru'=>array('Загружен файл ','Файл удалён'),'en'=>array('File upploaded: ','File deleted'));
		$A=array();
		if(is_uploaded_file($_FILES['file_cat']["tmp_name"]) || isset($_POST['chk_Del_cat']) ){
			require $root.'/1/catImgSave.php';
			$img=catImgSave($_SESSION['user']['id']);
			if($img){
				if($img=='Deleted'){$img='';}
				$q='update cat set img="'.$img.'" where id='.$_SESSION['user']['id'];
				DB::q($q);
				echo ($img?$L[$lang][0].$img:$L[$lang][1]);
			}
		}
	}else if(isset($_POST['fill'])){	//заполнить элемент выбора
		require $root.'/1/postFill.php';
	}else if(isset($_POST['tel'])){
		require $root.'/1/core/profileTelSave.php';
	}else if(isset($_POST['vs']) || isset($_POST['v']) || isset($_POST['s'])){	//vs=поля ввода в списке (33,34); v="Множественный выбор из списка" (32); s=поле ввода (40), число из диапазона, мин-макс (43), поле ввода + (с добавлением полей 41)
		$id=$_SESSION['user']['id'];
		require $root.'/1/core/paramsSave.php';	//POST 'vs','v','s'
	}

	exit;
}



$q='select b from r where a=-91'	//Общая информация: набор полей
.' and r='.$final;			//по типу клиента cat.final=(-115 … -120)
$r=DB::q($q);
$Actual=array();
while($row=DB::f($r)){$Actual[]=$row['b'];}


$Checked=array();	//$Checked=массив связей страницы: товара с категориями  (категория = конечный раздел каталога = список товаров)
$q='select r.a,r.b,'.DB::qL('r.s').','.DB::qL('name').' from r join cat on r.b=cat.id where r.r='.$_SESSION['user']['id'].' order by cat.ord,name';
$r=DB::q($q);
while($row=DB::f($r)){		//или категории (списка товаров) с характеристиками для указания возможных
	$Checked[$row['a']][$row['b']]=$row['name'];	//значения справочника (a) для страницы (r) по id (b)
	if($row['s'] && $row['b']==0){$Rs[$row['a']]=$row['s'];}
}

$Rs=array();	//текстовые значения согласно языку (s_ru)
$q='select r.a,'.DB::qL('r.s').' from r where r.r='.$_SESSION['user']['id'].' and b=0';
$r=DB::q($q);
while($row=DB::f($r)){
	if($row['s']){$Rs[$row['a']]=$row['s'];}
}
//var_dump($Rs);

$q='select '.DB::qL('name').','.DB::qL('adt').' from cat where id=-113';	//ФИО
$row=DB::f(DB::q($q));
$UserName=array($row['name'],$row['adt']);	//0=заголок и 1=подсказка ФИО


$q='select '.DB::qL('name').','.DB::qL('adt').' from cat where id=-114';	//Произвольный текст
$row=DB::f(DB::q($q));
$UserAdt=array($row['name'],$row['adt']);	//0=заголок и 1=подсказка

$q='select '.DB::qL('adt').' from cat where id='.$_SESSION['user']['id'];
$row=DB::f(DB::q($q));
$UserAdt[]=$row['adt'];	//[2]=значение Произвольный текст


$q='select '.DB::qL('name')
.','.DB::qL('adt')
.' from cat where id='.$final;	//Тип пользователя
$row=DB::f(DB::q($q));
echo '<div style="float:right;margin-top:-20px;color:#bbb" title="'.htmlspecialchars($row['adt']).'">'.$row['name'].'</div>';

$L=array('uk'=>'Зберегти','ru'=>'Сохранить','en'=>'Save');
echo	//фото
'<form onsubmit="return ajxFormData(event,this,0,lastChild)" style="float:left;position:relative;width:160px;margin:0 20px 10px 0">'
	.'<img id=img src="'.$host.'/?img=/i/'.($catImg?'cat/'.$catImg:'person.jpg').'&w=120&h=160&m" width=120>'
	.'<br><input name="file_cat" type=file style="text-align:left" onchange="'
			.'var reader = new FileReader(),file=files.item(0);'
			.'reader.onload=function(e){g(\'img\').src=e.target.result;};'
			.'reader.readAsDataURL(file);g(\'imgSaveBtn\').disabled=false'
		.'">'
	.($catImg?'<label style="position:absolute;top:0;right:0"><input name=chk_Del_cat type=checkbox style="width:auto;height:auto;" onclick="g(\'imgSaveBtn\').disabled=!checked">&times;</label>':'')
	.'<input id=imgSaveBtn type=submit value="'.$L[$lang].'" disabled style="clear:both;display:block;width:100%">'
	.'<input name=login value="'.$_GET['p'].'" type=hidden><input name=profile type=hidden><input name=hdn_cat value="'.$catImg.'" type=hidden>'
	.'<div></div>'
.'</form>';

echo
'<div style="display:inline-block;vertical-align:top;margin:15px 20px 0 0">'
	.'<input value="'.$catName.'"'
	.' onclick="if(!dataset.v){dataset.v=value.hashCode()}"'
	.' onblur="if(value.hashCode()!=dataset.v){style.backgroundColor=\'yellow\';'
		.'ajx(event,\'login\',\''.$_GET['p'].'&catName=name&profile=\'+value,this,\'div.dataset.v=div.value.hashCode();div.style.backgroundColor=null;notify(\\\'Сохранено «'.$UserName[0].'»\\\',txt,0,5)\',1)}"'
	.'>'
	
	.' <a title="'.$UserName[1].'" onclick="Alert(title)" style="position:absolute">?</a>'	//подсказка
	.'<div style="color:#aaa;font-size:12px">'.$UserName[0].'</div>'
	
.'</div>'

.'<div style="display:inline-block;vertical-align:top;margin-right:20px"><a style="float:right;margin-right:-10px" title="'.$UserAdt[1].'" onclick="Alert(title)">?</a>'
	.'<div style="color:#aaa;font-size:12px">'.$UserAdt[0].'</div>'
	.'<textarea name=adt style=width:335px'
	.' onclick="if(!dataset.v){dataset.v=value.hashCode()}"'
	.' onblur="if(value.hashCode()!=dataset.v){style.backgroundColor=\'yellow\';'
		.'ajx(event,\'login\',\''.$_GET['p'].'&catName=adt&profile=\'+encodeURIComponent(value),this,\'div.dataset.v=div.value.hashCode();div.style.backgroundColor=null;notify(\\\'Сохранено «'.$UserAdt[0].'»\\\',txt,0,5)\',1)}"'

	.'>'.$UserAdt[2].'</textarea>'
.'</div>'

;

//echo '<div>';
	$q='select id,'.DB::qL('name').','.DB::qL('adt').',final from cat where '
	//.' id BETWEEN -111 and -105'
	.' parent=-91 and v=1'	//Общая информация
	.(empty($Actual)?'':' and id in ('.implode(',',$Actual).')')
	.' order by ord';

	$r=DB::q($q);
	while($row=DB::f($r)){
		if($row['final']==31){	//выбор одного из списка
			$q='select b from r where a='.$row['id'].' and r='.$_SESSION['user']['id'].' limit 0,1';
			$r1=DB::q($q);
			if(DB::num_rows($r1)){
				$row1=DB::f($r1);
				$b=$row1['b'];
			}else{$b=0;}	
			$q='select '.DB::qL('name').','.DB::qL('adt').' from cat where id='.$row['id'];
			$row1=DB::f(DB::q($q));
			echo
			'<form style="display:inline-block;vertical-align:top;padding-top:15px;margin-right:20px" onsubmit="return ajxFormData(event,this,\'if(!txt){form.firstChild.nextSibling.style.backgroundColor=null}\',lastChild)">'
				.'<input name=login value="'.$_GET['p'].'" type=hidden>'
				.'<select name=v['.$row['id'].'] onchange="style.backgroundColor=\'yellow\';form.onsubmit()">'
					.'<option value=0 style="color:#fff;background-color:#666">'.$row1['name'].':';
				$q='select id,'.DB::qL('name').' from cat where v>0 and parent='.$row['id'];
				$r2=DB::q($q);
				while($row2=DB::f($r2)){
					echo '<option value='.$row2['id'].($b==$row2['id']?' selected':'').'>'.$row2['name'];
				}
				echo
				'</select><input name=profile type=hidden>'
				.'<a style="float:right;margin-right:-10px" title="'.$row1['adt'].'" onclick="Alert(title)">?</a>'

				.'<div style="color:#aaa;font-size:12px">'.$row1['name'].'</div>'
				.'<div></div>'
			.'</form>';
		//}else if($row['id']==-103){
		}else if($row['final']==32){	//выбор многих из списка
			$q='select '.DB::qL('name').','.DB::qL('adt').' from cat where id='.$row['id'];
			$row1=DB::f(DB::q($q));
			echo
			'<div style="min-width:160px;display:inline-block;vertical-align:top;margin-right:20px">'
				.($row1['adt']?'<a style="float:right;margin:15px -10px 0 0" title="'.$row1['adt'].'" onclick="Alert(title)">?</a>':'')
				.'<form onsubmit="return itemsFilter(event,this)">'
					.'<input name=login value='.$_GET['p'].' type=hidden><input name=profile value=0 type=hidden><input name=fill type=hidden>'
					.'<div class=oSelect>'
						.mSelect(					//1/functions.php
							$row['id'],					//Регион
							(isset($Checked[$row['id']])?$Checked[$row['id']]:0),	//0,		//$Ar[id]=name если заполнять опции не аяксом
							'v',		//имя элемента формы: справочник или текст
							$Checked,					//выбранное значение, если опции заполнены и есть выбор
							$row1['name'].':',	//имя характеристики и количество записей (товаров или групп товаров с этой характеристикой)
							1					//=1: выполнить form.onsubmit()
						)
					.'</div>'
					.'<input name="v['.$row['id'].'][]" value=0 type=hidden>'
					.'<div></div>'
				.'</form>'
				.'<div></div>'
			.'</div>';
		}else if($row['id']==-102){
			echo
			'<div style="display:inline-block;vertical-align:top;margin-right:20px">'	//Специальность
				.'<form onsubmit="return itemsFilter(event,this)">'
					.'<input name=login value='.$_GET['p'].' type=hidden><input name=profile value=0 type=hidden><input name=fill type=hidden>'
					.'<div class=oSelect>'
						.mSelect(
							-102,					//Специальность
							(isset($Checked[-102])?$Checked[-102]:0),	//0,		//$Ar[id]=name если заполнять опции не аяксом
							'v',		//имя элемента формы: справочник или текст
							$Checked,					//выбранное значение, если опции заполнены и есть выбор
							'Специальность:',	//имя характеристики и количество записей (товаров или групп товаров с этой характеристикой)
							1					//=1: выполнить form.onsubmit()
						)
					.'</div>'
					.'<input name="v[-102][]" value=0 type=hidden>'
					.'<div></div>'
				.'</form>'
				.'<div></div>'
			.'</div>';
		}else{
			echo
			'<div style="display:inline-block;vertical-align:top;margin:15px 20px 0 0">'
				.'<input value="'.(isset($Rs[$row['id']])?htmlspecialchars($Rs[$row['id']]):'').'"'
				.' onclick="if(!dataset.v){dataset.v=value.hashCode()}"'
				.' onblur="if(value.hashCode()!=dataset.v){style.backgroundColor=\'yellow\';ajx(event,\'login\',\''.$_GET['p'].'&a='.$row['id'].'&profile=\'+value,this,\'div.dataset.v=div.value.hashCode();div.style.backgroundColor=null;notify(\\\'Сохранено «'.$row['name'].'»\\\',txt,0,5)\',1)}"'
				.'> <a title="'.$row['adt'].'" onclick="Alert(title)" style="position:absolute">?</a>'
				.'<div style="color:#aaa;font-size:12px">'.$row['name'].'</div>'
			.'</div>';
		}
	}
//echo '</div>';

?>
<script>
function userEdit(evt,a,name,id){	//контакты/телефоны
	if(a.value!=a.dataset.v){
		ajx(
			evt,
			'login',
			id+'&profile=&'+name+'='+encodeURIComponent(a.value),
			a,
			['if(txt){if(txt=="-1"){div.parentNode.parentNode.removeChild(div.parentNode)}else{div.value=div.dataset.v;div=0}}else{div.style.backgroundColor="";div.dataset.v=div.value}']
		)
	}
}
</script>
