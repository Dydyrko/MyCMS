<?php	//POST страницы редактирования CSS "/a/css.php" или  страницы редактирования JS "/a/js.php"
if(__file__==$_SERVER['SCRIPT_FILENAME']){header($_SERVER["SERVER_PROTOCOL"].' 404 Not Found');exit('404 Not found');};

require $root.'/1/core/permit.php';

if(isset($_POST['ft']) && in_array($_POST['ft'],array('css','js'))){
	$dir=$root.'/1/'.$_POST['ft'];
	$dir1=$root.'/'.$_POST['ft'];
}

if($_POST['css']=='css'){
	$q='select r.s,r.b,B.id,'.DB::qL('B.name','p').' from r,cat A,cat B where A.id=r.r and B.id=r.a and A.name="CSS" order by r.s,B.name';
	$r=DB::q($q);
	echo
	'<style>.tdHover td[title]:hover{background-color:yellow !important;cursor:help}</style>'.
	'<h2>CSS links to pages</h2><table class="tdHover"><tr><th>File<th>Page<th>id';
	$t='';
	while($row=DB::f($r)){
		echo '<tr>';
			if($t!=$row['s']){
				$t=$row['s'];echo '<td>'.$row['s'];
			}else{echo '<td title="'.$row['s'].'">';}
		echo '<td'
			.($row['b']==-1?' style="background-color:lightgreen" title="For subpages"':'')
		.'>'.($row['id']==-8?'<b>Home</b>':$row['p']).'<td>'.$row['id'];
	}
	echo '</table>';

}else if($_POST['css']=='js'){
	$q='select r.s,r.b,B.id,'.DB::qL('B.name','p').' from r,cat A,cat B where A.id=r.r and B.id=r.a and A.name="JS" order by r.s,B.name';
	$r=DB::q($q);
	echo
	'<style>.tdHover td[title]:hover{background-color:yellow !important;cursor:help}</style>'.
	'<h2>JS links to pages</h2><table class="tdHover"><tr><th>File<th>Page<th>id';
	$t='';
	while($row=DB::f($r)){
		echo '<tr>';
			if($t!=$row['s']){
				$t=$row['s'];echo '<td>'.$row['s'];
			}else{echo '<td title="'.$row['s'].'">';}
		echo '<td'
			.($row['b']==-1?' style="background-color:lightgreen" title="For subpages"':'')
		.'>'.($row['id']==-8?'<b>Home</b>':$row['p']).'<td>'.$row['id'];
	}
	echo '</table>';

}else if(
	in_array($_POST['css'],array(
		'robots',	//редактировать /robots.txt
		'inHead',	//редактировать /1/a/inHead.txt
		'inBody'	//редактировать /1/a/inBody.txt
		)
	) && isset($_POST['t'])
){
	$file=$_SERVER['DOCUMENT_ROOT'].'/'.($_POST['css']=='robots'?'':'1/core/a/').$_POST['css'].'.txt';
	if(trim($_POST['t'])==''){
		if(file_exists($file)){unlink($file);}
		exit('OK');
	}else{
		$s=file_put_contents($file,$_POST['t']);
		exit($s===false?'Err put_contents '.$file:'OK, file size: '.$s);
	}
}else if($_POST['css']=='dir'){
	$_POST['id']=intval($_POST['id']);
	$rr=($_POST['ft']=='css'?-55:-56);	//r.r
	$q='select c,s from r where r='.$rr.' and b='.(isset($_POST['c'])?-1:0).' and a='.$_POST['id'];
	$r=DB::q($q);
	if(DB::num_rows($r)){
		$R=array();
		while($row=DB::f($r)){
			$R[$row['s']]=$row['c'];	//убрал минус 18.03.2023
		}
	}
	$A=scandir($dir);
	sort($A,SORT_NATURAL | SORT_FLAG_CASE);	//натурально (1,2,10…) и регистронезависимо

	echo
	'<input name=css value="'.$_POST['id'].'" type=hidden>'
		.(isset($_POST['c'])?'<input name=c value="1" type=hidden>':'');

		echo
		'<table>'
		.'<tr style=cursor:help><th title="The unique serial number of the attached file. To disable, specify: zero">№'
			.'<th title="File name (without «.php»)">File'
			.'<th title="Modified">Date'
			.'<th title="Delete file">Delete'
			.'<th title="Temporary file: create or delete">Tmp'
		.'<tbody onclick="getFile(event)" class=highLighting>';
		foreach($A as $i=>$v){
			if(in_array($v,array('.','..'))){continue;}
			if($_POST['ft']=='css'){$v=substr($v,0,strrpos($v,'.'));}
			echo '<tr'.(empty($R[$v])?' style="display:none"':'').'>'
				.'<td><input name=ord['.$v.'] style="width:4em;text-align:center"'
					.(empty($R[$v])?'':' value="'.$R[$v].'"')
				.' type=number min=0>'
				.'<td><a>'.$v.'</a>'
				.'<td>'.date('Y-m-d H:i:s',filemtime($dir.'/'.$v.($_POST['ft']=='css'?'.php':'')))
				.'<td><button class=delFile onclick="return false">&times</button>'
				.'<td><button data-t=makeTmp'
					.(file_exists($dir1.'/'.$v)?
						' class=delTmp>delete'
						:' class=makeTmp>create'
					).'</button>';
		}
		echo
		'</table>';

		if($lang=='ru'){
			$L=array('все','Сохранить странице выбор CSS. Для удаления выбора — очерёдность указать «нуль»','Сохранить выбор','Сброс');
		}else if($lang=='uk'){
			$L=array('всі','Зберігати сторінці вибір CSS. Для видалення вибору – черговість вказати «нуль»','Зберегти вибір','Скинути');
		}else{
			$L=array('all','Save page selection css. To remove the selection — the order should be specified as «zero»','Save selection','Reset');
		}

		echo
		'<input type=checkbox onclick="
		var e=form.elements,n,i=0;
		for(i;i<e.length;i++){
			if(!e[i].name || e[i].name[0]!=\'o\'){continue}	//имя не начинается на o (ord)
			n=e[i].parentNode.parentNode;n.style.display=(e[i].value||checked?\'\':\'none\')	//list-item
		}
		"><a onclick=chk(this)>'.$L[0].'</a>'
		.' <input type=reset value="'.$L[3].'">'
		.' <button onclick="go(form)" title="'.$L[1].'">'.$L[2].'</button>'
		.'<div></div>'
	;
}else if($_POST['css']=='delFile'){
	$file=$dir.'/'.$_POST['t']
		.($_POST['ft']=='css'?'.php':'');
	if(file_exists($file)){
		$q='delete from r where s="'.DB::esc($_POST['t']).'"';DB::q($q);$t=DB::affected_rows();
		unlink($file);
		exit('Deleted ('.$t.')');
	}else{exit('File not exists');}
}else if($_POST['css']=='makeTmp'){
	if($_POST['ft']=='css'){
		$C=file($root.'/1/css.ini');
		if($C===false){exit('css.txt ?');};
		foreach($C as $i=>$v){$C[$i]=trim($v);}
	}
	if(!file_exists($root.'/'.$_POST['ft'])){mkdir($root.'/'.$_POST['ft']);}
	$file=$root.'/'.$_POST['ft'].'/'.$_POST['t'];
	ob_start();
		require $root.'/1/'.$_POST['ft'].'/'.$_POST['t'].($_POST['ft']=='css'?'.php':'');
		$s=ob_get_contents();
	ob_end_clean();
	if($_POST['ft']=='js'){
		$A=explode("\n",$s);
		require $root.'/1/core/echoJS-func.php';
		$s=echoJS($A);
	}
	$s=file_put_contents($file,$s);
	if($s===false){
		exit('Err '.$_POST['t']);
	}else{
		echo 'Created|Delete'."\n".'Size: '.$s;
	}
}else if($_POST['css']=='delTmp'){
	$file=$root.'/'.$_POST['ft'].'/'.$_POST['t'];
	unlink($file);
	echo 'Deleted|Create';
}else if($_POST['css']=='note'){	//записать в примечание страницы, содержащей публичные вложенныме страницы,
					//параметры отображения списка
	if(!isset($_POST['underText'])){$_POST['underText']=0;}
	$A=array("\tPage list options");
	foreach($_POST as $i=>$v){
		if($i=='css'){continue;}
		else if($i=='p'){$p=intval($v);continue;}
		$A[]=$i."\t".$v;
	}
	if(empty($p)){exit('p=?');}
	$q='update cat set note="'.implode("\n",$A).'" where id='.$p;
	DB::q($q);
	echo DB::info();
}else if($_POST['css']=='variables' && is_array($_POST['c']) && is_array($_POST['t'])){
	$n=file_put_contents($root.'/1/css.ini',implode("\n",$_POST['c']));
	if($n!==false){echo '<p>css.ini saved: '.$n.' bytes';}else{exit('<p>Err css.ini');}
	$n=file_put_contents($root.'/1/css.txt',implode("\n",$_POST['t']));
	if($n!==false){echo '<p>css.txt saved: '.$n.' bytes';}else{exit('<p>Err css.txt');}
	echo '<p><button onclick="location.href=location.href">Refresh edit page</button>';
}else if(isset($_POST['ord'])){
	$_POST['css']=intval($_POST['css']);
	$rr=($_POST['ft']=='css'?-55:-56);	//r.r
	if(empty($_POST['css']) || empty($_POST['ord'])){exit;}
	$q='delete from r where r='.$rr.' and b='.(isset($_POST['c'])?-1:0).' and a='.intval($_POST['css']);
	DB::q($q);	//удаляем все записи для страницы (собственно страницы списка или вложений)
	echo '<p>'.$q;
	foreach($_POST['ord'] as $i=>$v){
		$v=intval($v);
		if($v==0){continue;}		//нулевые не добавляются
		$q='insert into r set r='.$rr.',a='.$_POST['css']
			.',b='.(isset($_POST['c'])?-1:0)	//-1=для вложенных страниц
			.',c='.$v			//очерёдность файлов CSS	(убрал минус 18.03.2023)
			.',s="'.DB::esc($i).'"';		//имя файла (до .php)
		echo '<p>'.$q;
		DB::q($q);echo '<p>'.DB::info();
	}
}else if(isset($_POST['saveFile'])){	//сохранение редактируемого файла
	if($_POST['ft']=='css'){
		$file=$dir.'/'.$_POST['css'].'.php';
		$bak=substr($file,0,strrpos($file,'.')).'.bak.php';
	}else{
		$file=$dir.'/'.$_POST['css'];
		$bak=$file.'.bak';
	}
	if(file_exists($bak)){unlink($bak);}
	if(file_exists($file)){rename($file,$bak);}
	$s=file_put_contents($file,$_POST['saveFile']);
	echo'<h2>Saving a file</h2>'.$_POST['css'].'';
	if($s!==false){
		echo '<p>Done, file size: '.$s;
	}else{
		$E=error_get_last();
		exit('<p class=err>'.$E['message']);
	}
}else if(isset($_POST['catName'])){
	$_POST['css']=intval($_POST['css']);
	echo catName($_POST['css']);
}else if(isset($_POST['ft'])){	//прочесть файл в textarea
	$file=$dir.'/'.$_POST['css'].($_POST['ft']=='css'?'.php':'');	//css — файл php с массивом значений цвета
	if(!file_exists($file)){exit('File not exists '.$file);}
	$s=file_get_contents($file);
	if($s!==false){echo $s;}else{exit('err get_contents');}
}else if($_POST['css']=='errLog'){
	if(empty($_POST['t']) || !file_exists($_POST['t'])){exit('<h2>PHP error log</h2>');}
	if(isset($_POST['del'])){
		if(unlink($_POST['t'])){
			echo 'File «'.$_POST['t'].'» deleted';
		}else{
			$A=error_get_last();
			if(isset($A['message'])){echo $A['message'];}
		}
		exit;
	}
	$s=file_get_contents($_POST['t']);
	echo '<h2>PHP error log</h2><div><pre style="overflow-x:auto;text-align:left">'.$s
		.'</pre><button onclick="ajx(event,\'core_css\',\'errLog&del=&t='
		.rawurlencode($_POST['t']).'\',parentNode)">Delete file &times;</button></div>';
}else{
	var_dump($_POST);
}