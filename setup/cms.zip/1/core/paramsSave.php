<?php	//Профиль персоны
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$debug=0;
//var_dump($_POST['v']);//exit;

$q='select a,b,s'.($lang==$Langs[0]?'':'_'.$lang).' as s from r where r='.$id;		//$a=характеристика, b=значение списка, s=текстовое значение, r=объект (товар, персона)
$B=$A=array();
$r=DB::q($q);
while($row=DB::f($r)){
	$A[$row['a']][$row['b']][]=$row['s'];
}
//var_dump($A);

if(isset($_POST['vs'])){
	foreach($_POST['vs'] as $i=>$v){
		if(is_array($v)){	//поля ввода в списке (33,34)
			foreach($v as $j=>$s){
				if(isset($A[$i]) && isset($A[$i][$j])){
					if($s != $A[$i][$j][0]){
						if($s==''){
							$q='delete from r where r='.$id.' and a='.intval($i).' and b='.intval($j);
						}else{
							$q='update r set s="'.DB::esc($s).'" where r='.$id.' and a='.intval($i).' and b='.intval($j);
						}
						if($debug){echo '<li>'.$q;}
						DB::q($q);
					}

				}else if($s!=''){
					$q='insert into r set s_'.$lang.'="'.DB::esc($s).'",r='.$id.',a='.intval($i).',b='.intval($j);
					if($debug){echo '<li>'.$q;}
					DB::q($q);
				}
			}
		}
	}
}
if(isset($_POST['v'])){
	foreach($_POST['v'] as $i=>$v){
		if(is_array($v)){	//"Множественный выбор из списка" (32)
			foreach($v as $j=>$s){
				$b=intval($s);
				if(!$b){continue;}
				if(!isset($A[$i][$b])){
					$q='insert into r set b="'.intval($b).'",r='.$id.',a='.intval($i).',s_'.$lang.'=""';
					if($debug){echo '<li>'.$q;}
					DB::q($q);
				}else{
					$B[$b]=1;
				}
			}
			if(isset($A[$i])){
				foreach($A[$i] as $j=>$s){	//сохранённые ранее значения параметра a=$i
					if(empty($B[$j])){
						$q='delete from r where r='.$id.' and a='.intval($i).' and b='.intval($j);
						if($debug){echo '<li>'.$q;}
						DB::q($q);
					}
				}
			}
		}else{	//select (31)
				if(isset($A[$i]) && $v){
					if(!isset($A[$i][$v])){
						$q='update r set b="'.DB::esc($v).'" where r='.$id.' and a='.intval($i);
						if($debug){echo '<li>'.$q;}
						DB::q($q);
					}
				}else if($v){
					$q='insert into r set b="'.DB::esc($v).'",'	//значение
						.'r='.$id.','				//товар
						.'a='.intval($i);			//характеристика
					if($debug){echo '<li>'.$q;}
					DB::q($q);
				}else if(isset($A[$i])){
					$q='delete from r where r='.$id.' and a='.intval($i);
					if($debug){echo '<li>'.$q;}
					DB::q($q);
				}
		}
	}
}
if(isset($_POST['s'])){
		foreach($_POST['s'] as $i=>$s){
			if(is_array($s)){				//поле ввода + (с добавлением полей 41)
				if(!empty($A[$i][0])){			//были значения
					$B=array_diff($A[$i][0],$s);	//отсутствующие в запросе
					$t=implode('","',$B);
					if($t){
						$q='delete from r where r='.$id.' and a='.intval($i).' and b=0 and s_'.$lang.' in ("'.$t.'")';
						if($debug){echo '<li>'.$q;}
						DB::q($q);
					}
				}
				foreach($s as $j=>$t){
					if($t=='' && isset($A[$i]) && in_array($t,$A[$i][0])){
						$q='delete from r where r='.$id.' and a='.intval($i).' and b=0 and s_'.$lang.'=""';
						if($debug){echo '<li>'.$q;}
						DB::q($q);
					}else if($t!='' && (!isset($A[$i]) || !in_array($t,$A[$i][0]))){	//если нет ни одного значения или нет значения среди имеющихся
						$q='insert into r set b=0,s_'.$lang.'="'.DB::esc($t).'",r='.$id.',a='.intval($i);
						if($debug){echo '<li>'.$q;}
						DB::q($q);					
					}
				}
			}else{		//поле ввода (40), число из диапазона, мин-макс (43)
				if(isset($A[$i]) && isset($A[$i][0])){
					if($A[$i][0][0] != $s){
						if($s){
							$q='update r set s_'.$lang.'="'.DB::esc($s).'" where r='.$id.' and a='.intval($i);
						}else{
							$q='delete from r where r='.$id.' and a='.intval($i);
						}
						if($debug){echo '<li>'.$q;}
						DB::q($q);
					}
				}else if($s!=''){
					$q='insert into r set s_'.$lang.'="'.DB::esc($s).'",r='.$id.',a='.intval($i).',b=0';
					if($debug){echo '<li>'.$q;}
					DB::q($q);
				}
			}
		}
}