<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$file=$root.'/1/tmp/'.(empty($subhost)?'':$subhost.'_').'sitemap.txt';
if(file_exists($file)){
	$time=time();
	$fTime=filemtime($file);
	$t=$time-$fTime;
	if($t>3600){
		$t=round($t/3600,2).' hours';
	}else{$t.=' sec';}
	echo
	'<a href="/sitemap.xml" target=_blank>Sitemap</a> '
	.date('Y-m-d H:i:s',$fTime).' ('.$t.')'
	.' <a href="/sitemap.xml?w" target=_blank>refresh</a>';
}else{
	echo '<a href="/sitemap.xml?w" target=_blank>Create sitemap.xml</a>';
}