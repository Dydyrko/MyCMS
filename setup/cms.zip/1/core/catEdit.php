<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

require $root.'/1/core/permit.php';

$_POST['catEdit']=intval($_POST['catEdit']);
$langA=$lang;
//$langA='ru';	//Вариант задания определённого языка вместо $Langs[0];

if(isset($_POST['childV'])){	//изменить статус вложенных страниц
	if($langA=='ru'){
		$L=array('Изменение статуса вложенных страниц','Изменён статус на ','','вложенным страницам','Без изменений');	
	}else if($langA=='uk'){
		$L=array('Зміна статусу вкладених сторінок','Змінено статус на ','','вкладеним сторінкам','Без змін');
	}else{
		$L=array('Changing the Status of Subpages','Changed status to ','','subpages','No change');
	}
	if($_POST['childV']==1){
			if($langA=='ru'){
				$L[2]='"Публичный"';
			}else if($langA=='uk'){
				$L[2]='"Пубічний"';
			}else{
				$L[2]='"Public"';
			}
		$q='update cat set v=1 where parent='.intval($_POST['catEdit']).' and v=0';
	}else{
			if($langA=='ru'){
				$L[2]='"Скрытый"';
			}else if($langA=='uk'){
				$L[2]='"Прихований"';
			}else{
				$L[2]='"Hidden"';
			}
		$q='update cat set v=0 where parent='.intval($_POST['catEdit']).' and v=1';
	}
	DB::q($q);
	$n=DB::affected_rows();
	echo '<h2 style="font-size:16px">'.$L[0].'</h2>'
	.'<div style=min-width:300px>';
		if($n){echo $L[1].$L[2],' '.$L[3].': <b>'.$n.'</b>';}
		else{echo $L[4];}
	echo '</div>';
	exit;
}else if(isset($_POST['owners'])){	//список персон для указания владельца (поставщика) товара
	$q='select id,'.DB::qL('name').' from cat where parent=-9 and final <= -117 order by name';	//песоны в разделе "Регистрация"
	$r=DB::q($q);
	echo '<select name=owner onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}"><option value=0>Owner:';
	while($row=DB::f($r)){
		echo '<option value="'.$row['id'].'"'.($row['id']==$_POST['catEdit']?' selected':'').'>'.$row['name'];
	}
	echo '</select>';
	exit;
}else if(isset($_POST['parents'])){	//показать выбор родителя
	require $root.'/1/core/catEditParents.php';
	exit;
}else if(isset($_POST['getText'])){	//Вставка текста в textarea
	if(!in_array($_POST['getText'],array('note','adt','text'))){exit;}
	if(!in_array($_POST['t'],array('cat','url'))){exit;}
	$q='select '.DB::qL($_POST['getText']).' from '.$_POST['t'].' where id='.intval($_POST['catEdit']);
	$r=DB::q($q);
	if(DB::num_rows($r)){
		$row=DB::f($r);
		echo($row[$_POST['getText']]);
	}
	exit;
}else if(isset($_POST['setUrl'])){	//подстановка родительского URL для иерархического варианта
	$q='select parent from cat where id='.intval($_POST['catEdit']);
	$row=DB::f(DB::q($q));
	$q='select '.DB::qL('url').' from url where id='.$row['parent'];
	$row=DB::f(DB::q($q));
	echo (empty($row['url'])?'':$row['url'].'/').$_POST['setUrl'];
	exit;
}else if(isset($_POST['testUrl'])){
	$q='select cat.id,'.DB::qL('name').' from cat join url on cat.id=url.id where cat.id != '.intval($_POST['catEdit'])
	.' && url'.($lang==$Langs[0]?'':'_'.$lang).'="'.DB::esc($_POST['testUrl']).'"';
	$r=DB::q($q);
	if(DB::num_rows($r)){
		$row=DB::f($r);
		echo '<div style="min-width:200px;margin-top:20px">'.$_POST['testUrl'].'</div>'
		.'<p>id='.$row['id']
		.'<p><a href=/?p='.$row['id'].' target=_blank>'.$row['name'].'</a>';
	}
	exit;
}else if(isset($_POST['update'])){
	require $root.'/1/core/catEditUpdate.php';
}else if(!empty($_POST['edit'])){	//редактирование описания или анонса
	require $root.'/1/core/catEditEdit.php';	//использовалось в эридоне для редактирования трёх разделов прямо на странице вакансии
	exit;
}else if(isset($_POST['lang'])){	//проверка отсутствия текста языка (не основного)
	$A=array();
	$q='select (name_'.$lang.'="") as name,(adt_'.$lang.'="") as adt from cat where id='.intval($_POST['catEdit']);
	$row=DB::f(DB::q($q));
	if($row['name']==1){$A[]='name';}
	if($row['adt']==1){$A[]='adt';}

	$q='select (text_'.$lang.'="") as text from url where id='.intval($_POST['catEdit']);
	$row=DB::f(DB::q($q));
	if(isset($row['text']) && $row['text']==1){$A[]='text';}

	if(empty($A)){echo 'OK';}else{echo implode("\t",$A);}
	exit;
}else if(isset($_POST['newfile'])){
	//var_dump($_POST);
	$h='<h2>Page picture</h2>';
	$n=mb_strrpos($_POST['newfile'],'.');
	if(!$n){exit($h.'ext? '.$_POST['newfile']);}
	$m=mb_strlen($_POST['newfile']);
	$t=mb_substr($_POST['newfile'],-($m-$n));
	//echo '<br>n='.$n.'<br>t='.$t;exit;
	$s=file_get_contents(
		$_POST['newfile'],
		false,			//use_include_path
		stream_context_create(array('ssl' => array('verify_peer' => false, 'verify_peer_name' => false)))	//для самоподписанных SSL
	);
	if($s===false){exit($h.'URL error: '.$_POST['newfile']);}

	$name=$_POST['catEdit'].$t;	//имя файла
	$file=$root.'/i/cat';
	if(!file_exists($file)){mkdir($file);}
	$file.='/'.$name;
	//echo $file."\t";
	foreach(glob($file.'*.tmp') as $f){unlink($f);}

	$bytes=file_put_contents($file,$s);
	if($bytes===false){exit('URL file error');}
	$q='update cat set img="'.$name.'" where id='.$_POST['catEdit'];DB::q($q);
	echo $h.'"'.$name.'": '.$bytes.' bytes<p>If picture previously existed — clear your browser cache and refresh this form ↻</p>';
	exit;
}

$q='select cat.id,parent,v,ord,'.DB::qL('name')
//.','.DB::qL('adt').','.DB::qL('text')
.','.DB::qL('meta').','.DB::qL('url').',note,img,vimg,d,d1,final,owner,c'
.',url.t,cat.t as ct'	//дата изменения
	.' from cat left join url on cat.id=url.id where cat.id='.intval($_POST['catEdit']).(isset($_POST['parent'])?' and parent='.intval($_POST['parent']):'');
$r=DB::q($q);
if(!DB::num_rows($r)){exit('Not found');}
$row=DB::f($r);
//echo $row['meta'];
$owner=$row['owner'];

//var_dump($row);
if($row['owner']!=0){
	$q='select '.DB::qL('name').' from cat where id='.$row['owner'];
	$row1=DB::f(DB::q($q));
	$ownerName=$row1['name'];
}

if($row['parent']!=0){
	$q='select '.DB::qL('name').' from cat where id='.$row['parent'];
	$parentName=DB::f(DB::q($q));
	$parentName=$parentName['name'];
}
/*
if($row['parent']==-1){	//товар
	if(empty($subhost)){
		$q='select cat.owner,item.code,item.price,item.price0,item.price1,item.currency from cat join item on cat.id=item.id'
		.' where cat.id='.intval($_POST['catEdit']);
	}else{
		$q='select cat.owner,A.code,B.price,B.price0,B.price1,B.currency'
		.' from cat join (item A join item_'.$subhost.' B on A.id=B.id) on cat.id=A.id'
		.' where cat.id='.intval($_POST['catEdit']);
	}
	$itemRow=DB::f(DB::q($q));
	//var_dump($itemRow);
}else
*/
 if($row['parent']==-9){	//персоны
	$q='select mail'
		//.',available,frozen,bonus'
		.' from person where id='.intval($_POST['catEdit']);
	$personRow=DB::f(DB::q($q));
}

if(!isset($_POST['v'])){	//первоначальное отображение — после сохранения обновляется содержимое формы
	$LColor=array('uk'=>'#ffe','ru'=>'#fee','en'=>'#efe');
	if(!isset($LColor[$lang])){$LColor[$lang]=$LColor['en'];}
	echo
	'<form onsubmit="return catEditSubmit(this)" style="background-color:'.$LColor[$lang].';text-align:left">';
}

if(!intval($row['d'])){$row['d']='';}
if(!intval($row['d1'])){$row['d1']='';}

if($langA=='ru'){
	$L=array(
		'parent'=>'Принадлежит (parent)'
		,'status'=>'Статус'
		,'v0'=>'Скрыт'
		,'v1'=>'Публичный'
		,'v2'=>'Особый (товар заказан)'
		,'v3'=>'(товар продан)'
		,'ord'=>'Очерёдность'
		,'date'=>'Дата'
		,'event'=>'Событие'
		,'d'=>'Дата страницы (публикации, начала акции…)'
		,'d1'=>'Другая дата (события, окончания акции…)'
		,'root'=>'Корневая страница'
		,'final'=>'тип'
		,'final0'=>'Раздел'
		//,'final-1'=>'Категория товара (-1)'
		//,'final1'=>'Список товаров (1)'
		//,'final2'=>'Товар (2)'
		//,'final3'=>'Публикация (3)'
		//,'final11'=>'Производитель'
		,'final31'=>'Выбор одного из списка (31)'
		,'final32'=>'Множественный выбор из списка (32)'
		,'final33'=>'Выбор одного из списка с полем ввода (33)'
		,'final34'=>'Множественный выбор из списка с полями ввода (34)'
		,'final40'=>'Поле ввода (40)'
		,'final41'=>'Поле ввода + (41)'
		,'final42'=>'Число из диапазона (42)'
		,'final43'=>'Числа мин. — макс. (43)'
		,'imgDel'=>'Отметить для удаления'
		,'adt'=>'Анонс'
		,'text'=>'Описание'
		,'url'=>array('создать','простой','иерархический')
		,'symbols'=>'Количество символов'
		,'meta1'=>'Описание'
		,'meta2'=>'Ключевые слова'
		,'meta4'=>'Код внутрь header (для каждого языка)'
		,'updated subpages number'=>'Обновлено количество вложенных страниц'
		,'visitorsLog'=>'Журнал переходов на эту страницу с других сайтов'
		,'files'=>'Галерея файлов страницы'
		,'catDel'=>array(
				'Удалить страницу и всё связанное с ней'
				,'Удалить страницу?\nВ том числе вложенные страницы (если их больше тысячи, то прежде удалите их!),\nфайлы и связи с др.таблицами'
				,'Удалить'
			)
		,'subpages'=>array(
				'Вложенные страницы'
				,'Удалить вложенные страницы (лимит 1000)'
				,'Удалить'
			)
		,'subV'=>array(
				'статус на'
				,'скрытые сделать публичными'
				,'публичный'
				,'публичные сделать скрытыми'
				,'скрыт'
			)
		,'OpenPage'=>array('Открыть страницу','Если страница не публичная — включите режим редактирования')
	);
}else if($langA=='uk'){
	$L=array(
		'parent'=>'Належить (parent)'
		,'status'=>'Статус'
		,'v0'=>'Прихований'
		,'v1'=>'Публічний'
		,'v2'=>'Особливий (товар замовлений)'
		,'v3'=>'(товар продано)'
		,'ord'=>'Черговість'
		,'date'=>'Дата'
		,'event'=>'Подія'
		,'d'=>'Дата сторінки (публікації, початку акції…)'
		,'d1'=>'Інша дата (події, закінчення акції…)'
		,'root'=>'Кореневій сторінці'
		,'final'=>'тип'
		,'final0'=>'Розділ'
		//,'final-1'=>'Категорія товару (-1)'
		//,'final1'=>'Список товарів (1)'
		//,'final2'=>'Товар (2)'
		//,'final3'=>'Публікація (3)'
		//,'final11'=>'Виробник'
		,'final31'=>'Вибір одного зі списку (31)'
		,'final32'=>'Множинний вибір зі списку (32)'
		,'final33'=>'Вибір одного зі списку з полем введення (33)'
		,'final34'=>'Множинний вибір зі списку з полями введення (34)'
		,'final40'=>'Поле введення (40)'
		,'final41'=>'Поле введення + (41)'
		,'final42'=>'Число з діапазону (42)'
		,'final43'=>'Числа мін. - Макс. (43)'
		,'imgDel'=>'Відзначити для видалення'
		,'adt'=>'Анонс'
		,'text'=>'Опис'
		,'url'=>array('створити','простий','ієрархічний')
		,'symbols'=>'Кількість символів'
		,'meta1'=>'Опис'
		,'meta2'=>'Ключові слова'
		,'meta4'=>'Код всередину header (для кожної мови)'
		,'updated subpages number'=>'Оновлено кількість вкладених сторінок'
		,'visitorsLog'=>'Журнал переходів на цю сторінку з інших сайтів'
		,'files'=>'Галерея файлів сторінки'
		,'catDel'=>array(
				'Видалити сторінку і все пов\'язане з нею'
				,'Видалити сторінку?\nУ тому числі вкладені сторінки\n(якщо їх більше тисячі, то спочатку видаліть їх!),\nфайли та зв`язки з іншими таблицями'
				,'Вилучити'
			)
		,'subpages'=>array(
				'Вкладені сторінки'
				,'Видалити вкладені сторінки (ліміт 1000)'
				,'Вилучити'
				)
		,'subV'=>array(
				'статус на'
				,'приховані зробити публічними'
				,'публічніій'
				,'публічні зробити прихованими'
				,'прихований'
			)
		,'OpenPage'=>array('Відкрити сторінку','Якщо сторінка не публічна — включить режим редагування')
	);
}else{
	$L=array(
		'parent'=>'Parent'
		,'status'=>'Status'
		,'v0'=>'Hidden'
		,'v1'=>'Public'
		,'v2'=>'Special (item ordered)'
		,'v3'=>'(item sold)'
		,'ord'=>'Order'
		,'date'=>'Date'
		,'event'=>'Event'
		,'d'=>'Date of the page (publications, start of actions…)'
		,'d1'=>'Second date (events, the end of the promotion…)'
		,'root'=>'Root'
		,'final'=>'type'
		,'final0'=>'Section'
		//,'final-1'=>'Product category (-1)'
		//,'final1'=>'Product list (1)'
		//,'final2'=>'Item (2)'
		//,'final3'=>'Publication (3)'
		//,'final11'=>'Manufacturer'
		,'final31'=>'Select one from the list (31)'
		,'final32'=>'Multiple selection from list (32)'
		,'final33'=>'Select one from list with input field (33)'
		,'final34'=>'Multiple selection from a list with input fields (34)'
		,'final40'=>'Input field (40)'
		,'final41'=>'Input field + (41)'
		,'final42'=>'Number from range (42)'
		,'final43'=>'Numbers min. - max. (43)'
		,'imgDel'=>'Mark for deletion'
		,'adt'=>'Announcement'
		,'text'=>'Description'
		,'url'=>array('create','simple','hierarchical')
		,'symbols'=>'Number of symbols'
		,'meta1'=>'Description'
		,'meta2'=>'Keywords'
		,'meta4'=>'Code inside header (for each language)'
		,'updated subpages number'=>'Updated the number of subpages'
		,'visitorsLog'=>'Log of visitors to this page from other sites'
		,'files'=>'Page file gallery'
		,'catDel'=>array(
				'Delete the page and everything related to it'
				,'Delete a page?\nIncluding subpages (if there are more than a thousand, delete them first!),\nfiles and links to other tables'
				,'Delete'
			)
		,'subpages'=>array(
				'Subpages'
				,'Delete nested pages (limit 1000)'
				,'Delete'
				)
				,'subV'=>array(
				'status to'
				,'hidden make public'
				,'public'
				,'public make hidden'
				,'is hidden'
			)
		,'OpenPage'=>array('Open page','If page is not public — turn on edit mode')
	);
}

echo
'<input name="core_catEdit" value="'.$row['id'].'" type=hidden>'
.'<input name=update type=hidden'				//при наличии записи в `url` и пустых полях формы для этих записей
	.(is_null($row['url'])?'':' value="2"')			//onsubmit "value=2" изменяется на "value=1" для удаления записи
.'>'
.'<input name=lang value="'.$lang.'" type=hidden>'

.'<input name=name value="'.htmlspecialchars($row['name']).'" style="display:block;width:100%"'
	.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}"'
.'>'

.'<div style=float:right title="owner"><a onclick="ajx(event,\'core_catEdit\',\''.$row['owner'].'&owners=\',parentNode)">'.(isset($ownerName)?$ownerName:'owner').'</a></div>'

.'<tt title="id">'.$row['id'].'</tt> <small class=parentCat>'.$L['parent'].':</small>'
.'<div>'
	.'<a onclick="ajx(event,\'core_catEdit\',\''.$row['id'].'&parents='.$row['parent'].'\',parentNode)"> '
		.($row['parent']?$row['parent'].': ':'').(isset($parentName)?$parentName:$L['root'])
	.'</a>'
.'</div>'

.'<small>'.$L['status'].':</small> <select name=v style="max-width:150px">'
	.'<option value=0'.($row['v']==0?' selected':'').'>0 '.$L['v0']
	.'<option value=1'.($row['v']==1?' selected':'').'>1 '.$L['v1']
	.'<option value=2'.($row['v']==2?' selected':'').'>2 '.$L['v2']
	.'<option value=3'.($row['v']==3?' selected':'').'>3 '.$L['v3']
.'</select>'

.' <select name=final style="max-width:150px" title="'.$L['final'].': '.$row['final'].'">';
	if($row['parent']==-9){	//персоны в разделе "Регистрация"
		$q='select id,'.DB::qL('name').' from cat where parent=-10';	//Вход	//-112=Тип пользователя
		$r=DB::q($q);
		echo '<option value=0>New';
		while($row1=DB::f($r)){echo '<option value='.$row1['id'].($row['final']==$row1['id']?' selected':'').'>'.$row1['name'].' ('.$row1['id'].')';}
	}else{
		echo
		'<option value=0'.($row['final']==0?' selected':'').'>'.$L['final0']
		//.'<option value=-1'.($row['final']==-1?' selected':'').'>'.$L['final-1']
		//.'<option value=1'.($row['final']==1?' selected':'').'>'.$L['final1']
		//.'<option value=2'.($row['final']==2?' selected':'').'>'.$L['final2']
		//.'<option value=3'.($row['final']==3?' selected':'').'>'.$L['final3']
		//.'<option value=11'.($row['final']==11?' selected':'').'>'.$L['final11']
		.'<option value=31'.($row['final']==31?' selected':'').'>'.$L['final31']
		.'<option value=32'.($row['final']==32?' selected':'').'>'.$L['final32']
		.'<option value=33'.($row['final']==33?' selected':'').'>'.$L['final33']
		.'<option value=34'.($row['final']==34?' selected':'').'>'.$L['final34']
		.'<option value=40'.($row['final']==40?' selected':'').'>'.$L['final40']
		.'<option value=41'.($row['final']==41?' selected':'').'>'.$L['final41']
		.'<option value=42'.($row['final']==42?' selected':'').'>'.$L['final42']
		.'<option value=43'.($row['final']==43?' selected':'').'>'.$L['final43'];
	}
echo
'</select>'


.'<div style="margin:5px 0">'
	.'<small>'.$L['ord'].':</small> <input name=ord value="'.$row['ord'].'" size=2 style="text-align:center">
	<a href="/'.sUrl($row['id']).'" target=_blank title="'.$L['OpenPage'][1].'">'.$L['OpenPage'][0].'</a>'
.'</div>'
.(empty($row['ct'])?'':' <small>Table `cat` updated '.$row['ct'].'</small>')
.'<div>'
	.'<input name=d value="'.$row['d'].'"><a title="'.$L['d'].'" data-v="'.$row['d'].'" onclick="calendar(this,1,3)"> '.$L['date'].'</a><div class=calendar></div>'
	.'<div style=height:3px></div>'
	.'<input name=d1 value="'.$row['d1'].'"><a title="'.$L['d1'].'" data-v="'.$row['d1'].'" onclick="calendar(this,1,3)"> '.$L['event'].'</a><div class=calendar></div>'
.'</div>'

.'<fieldset style="margin:5px 0;border:solid 1px #ddd">'
	.'<legend>Page picture</legend>'
	.($row['img']?
		'<a href="'.$host.'/i/cat/'.$row['img'].'" target=_blank>'
			.'<img src="'.$host.'/?img=/i/cat/'.$row['img'].'&w=50" style="text-align:absmiddle;background-color:#ddd">'
		.'</a>'
	:'');


	if($row['img']){
		$t=substr($row['img'],strrpos($row['img'],'.'));
		echo
		' <input name=chk_Del_cat class=v type=checkbox value="-1">'	//value=-1 для css
		.'<a onclick="chk(this)" title="'.$L['imgDel'].'">&times;</a>';
		//if(in_array($t,array('.css','.js','.svg'))){
			echo
			' <a title="Edit file" onclick="'
			.'ajx(event,\'core_files\',\'&edit='.$row['img'].'\''
			.',0,`div.style.width=\'90%\';div.style.height=\'90%\';div.style.textAlign=\'left\'`,0,`<a onclick=\'screenfull.toggle(parentNode.parentNode)\' title=\'Screenfull\'>File editor ⤢</a>`'
			.')">'.$row['img'].'</a>';
		//}
	}
	echo
	'<input name=hdn_cat value="'.$row['img'].'" type=hidden>'

	.' <div class=upload>'
		.'<span style="font-size:90%">Upload</span>'
		.'<small></small><input name="file_cat" type="file" title="Drag local file here to upload on server after completing the form. '
			."\n".'Or click to select file from list"'
		.' ondragover="parentNode.style.backgroundColor=\'yellow\'"'
		.' ondragleave="parentNode.style.backgroundColor=\'#eee\'"'
		.' onchange="previousSibling.innerHTML=(value?\'<br>\'+files[0].name+\'<br><small>\'+(files[0].size/1000)+\' Kb</small>\':\'\');'
			.'parentNode.nextSibling.style.display=(value?\'inline\':\'none\');'
			.'ondragleave()">'
	.'</div>'
	.'<a onclick="var e=previousSibling.lastChild;e.value=null;e.onchange()" style="margin:5px;display:none">&times;</a>' //отменить выбор файла

	.'<fieldset style="margin:10px 0">'
		.'<legend>From URL</legend>'
		.'<span contenteditable style="display:inline-block;vertical-align: middle;width: calc(100% - 40px);border:inset 1px;background-color: #fff;"></span>'
		.'<a onclick="var e=previousSibling,t=e.textContent;if(t.length<5){e.focus();return}ajx(event,\'core_catEdit\',\''.$_POST['catEdit'].'&newfile=\'+t,this,'
			.'[\'var e=div.parentNode.parentNode.parentNode;console.log(e);e=e.querySelector(\\\'a.refresh\\\');e.onclick();div=0\']'
		.')" title="Save'.($row['img']?'. To see the changed image, first clear the browser cache':'').'"> OK</a>'
	.'</fieldset>'

	.'<select name=vimg>
		<option value=0>Display everywhere
		<option value=-1'.($row['vimg']==-1?' selected':'').'>Display in list only'
		//<option value=1'.($row['vimg']==1?' selected':'').'>Справа на странице
		//<option value=2'.($row['vimg']==2?' selected':'').'>Слева на странице
	.'</select>'
.'</fieldset>';

echo
($Langs[0]==$lang?
	'<tt style=float:right>'.$lang.'</tt>':
	'<div style="float:right;cursor:help" title="Тексты, не указанные для языка: отображаются тексты основного языка для редактирования">'
	.'<tt></tt>'
	.'<input type=button'
		.' onclick="ajx(event,\'core_catEdit\',\''.$_POST['catEdit'].'&lang=\'+value,previousSibling'
		.',\'var e=div.nextSibling.form.elements,i=0,A=txt.split(\\\'\t\\\');for(i;i<A.length;i++){if(e[A[i]]){e[A[i]].style.color=\\\'red\\\'}}\''	//изменить цвет найденных текстов
		.')"'
		.' value="'.$lang.'">'
	.'</div>'
);
/*
if($row['parent']==-1){	//товар
	require $root.'/1/item/curRate.php';	//запрашиваем курсы валют
	require $root.'/1/item/itemForm.php';
	itemForm1($row['id'],$itemRow);
	$q='select d from item where id='.$row['id'];
	$row1=DB::f(DB::q($q));
	echo '<div>Дата изменения товара: '.$row1['d'].'</div>';
	//echo '<div style="font-size:12px;color:red;margin-bottom:5px">*Сохранение цен, валюты и артикула товара<br>здесь ещё не сделано — пока только в самом товаре (public)</div>';
}else 
*/
if($row['parent']==-9){	//персоны
	echo '<table>'
		.'<tr><td align="right">mail:<td><input name=mail value="'.$personRow['mail'].'"'
			.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}">'
/*
		.'<tr><td align="right">Доступные средства:<td>'
			.'<input name="available" value="'.$personRow['available'].'" type=number'
			.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}">'
		.'<tr><td align="right">Замороженные средства:<td>'
			.'<input name="frozen" value="'.$personRow['frozen'].'" type=number'
			.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}">'
		.'<tr><td align="right">Бонус:<td>'
			.'<input name="bonus" value="'.$personRow['bonus'].'" type=number'
			.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}">'
*/
	.'</table>';
}

/*
$ckeJS='ckeditor_4/ckeditor.js';	//чтобы не повторять файлы ckeditor на каждом сайте — только при надобности. А локально размещать - чтобы можно было работать без интернета
if(file_exists($ckeJS)){
	$ckeJS='/'.$ckeJS;
//}else if($_SERVER["REMOTE_ADDR"]=='127.0.0.1'){
//	$ckeJS='//eridon/ckeditor_4/ckeditor.js';
}else{
	$ckeJS='https://cdn.ckeditor.com/4.10.0/standard/ckeditor.js';
}
*/

echo
'<small>Note</small>
<textarea name=note style="display:block;width:100%;white-space:pre"'
	.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}"'
	.'>'.$row['note']
.'</textarea>'

.'<div style="margin:5px 0">'
	.'<div style="text-align:center"><select id=CKEdit style="font-size:11px" title="Text editor version">'
		.'<option value=4>CKEditor 4<option value=5>CKEditor 5'
	.'</select></div>'
	.'<a onclick="getTextarea(this,parentNode.parentNode,\'adt\')">'.$L['adt'].'</a>'
	/*.' <select id=CKEdit style="font-size:11px">'
		.'<option value=4>CKEditor 4<option value=5>CKEditor 5'
	.'</select>'*/
	.' <a style="display:none;margin-right:1em;border:solid 1px #999;line-height:0;padding:8px 2px 12px;font-size:24px"'
		.' onclick="screenfull.toggle(parentNode)">⤢</a>'
	.'<a style=display:none onclick="CKEditor(this,\'adt\')">CKEditor</a>'
	.'<button style="width:auto;float:right;">Save</button>'
	.'<textarea name=adt style="display:none;width:100%;white-space:pre;height:calc(100% - 30px);"'
	.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}"'
	.'></textarea>'
.'</div>';


echo
(is_null($row['url'])?
'<a onclick="var e=nextSibling.style;e.display=(e.display==\'none\'?\'block\':\'none\')"'
.' title="show/hide">&dArr;</a>'
.'<div style=display:none>'

:'<div style="margin:15px 0">')
	.'<div style="margin:5px 0">'
		.'<a onclick="getTextarea(this,parentNode.parentNode.parentNode,\'text\')">'
		.$L['text'].'</a>'
		.' <a style="display:none;margin-right:1em;border:solid 1px #999;line-height:0;padding:8px 2px 12px;font-size:24px"'
			.' onclick="screenfull.toggle(parentNode)">⤢</a>'
		.'<a style=display:none onclick="CKEditor(this,\'text\')">CKEditor</a>'
		.'<button style="width:auto;float:right;clear: both;margin: 2px 0;">Save</button>'
		.'<textarea name=text style="display:none;width:100%;white-space:pre;height:calc(100% - 30px);"'
		.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}"'
		.'></textarea>'
	.'</div>';	

	echo
	'<div style=font-size:80%'.(is_null($row['url'])?' onclick="var e=lastChild;if(!e.value){e.disabled=!e.disabled};e.focus()"':'').'>'
		.'Url ('.$L['url'][0]	//создать
		.': <a onclick="var e=parentNode.lastChild,t=e.form.elements[\'name\'].value;'
		.'e.disabled=false;e.focus();e.value=translit(t.toLowerCase())">'.$L['url'][1].'</a>'	//сначала focus() для dataset прежнего состояния, потом value=
		.' | <a onclick="var e=parentNode.lastChild,t=e.form.elements[\'name\'].value;t=translit(t.toLowerCase());'
		.'ajx(event,\'core_catEdit\',\''.$_POST['catEdit'].'&setUrl=\'+t,e,[\'div.focus();div.value=txt;\'],1)">'.$L['url'][2].'</a>)'
		.'<input name=url value="'.$row['url'].'" style="display:block;width:100%"'
			.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}"'
			.' onblur="if(value){value=value.toLowerCase();ajx(event,\'core_catEdit\',\''.$_POST['catEdit'].'&testUrl=\'+encodeURIComponent(value),this,[\'if(txt){div.value=\\\'\\\';div.focus();div=0}\'],0,\'URL существует\')}"'
			.(is_null($row['url'])?' disabled':'')
		.'>'
	.'</div>';

	
	if(empty($row['meta'])){$A=array('','','','');}else{$A=explode("\n",$row['meta']);}
	echo
	'<div'.(is_null($row['meta'])?	//если нет таблицы url
			' onclick="var e=lastChild;if(!e.value){e.disabled=!e.disabled}if(!e.disabled){e.focus()}"'
		:'')
		.'><small>Meta1: '.$L['meta1'].'</small><tt style="float:right" title="'.$L['symbols'].'"></tt><textarea name=meta1 style="display:block;width:100%"'
			.(is_null($row['meta'])?' disabled':'')
			.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}"'
			.' oninput="previousSibling.innerHTML=value.length"'
			.'>'.$A[0].'</textarea>'
	.'</div>'
	.'<div'.(is_null($row['meta'])?' onclick="var e=lastChild;if(!e.value){e.disabled=!e.disabled}if(!e.disabled){e.focus()}"':'')
		.'><small>Meta2: '.$L['meta2'].'</small><tt style="float:right" title="'.$L['symbols'].'"></tt><textarea name=meta2 style="display:block;width:100%" rows=1'
			.(is_null($row['meta'])?' disabled':'')
			.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}"'
			.' oninput="previousSibling.innerHTML=value.length"'
			.'>'.(empty($A[1])?'':$A[1]).'</textarea>'
	.'</div>'

	.'<div'.(is_null($row['meta'])?' onclick="var e=lastChild;if(!e.value){e.disabled=!e.disabled}if(!e.disabled){e.focus()}"':'')
		.'><small>Meta3: title</small><tt style="float:right" title="'.$L['symbols'].'"></tt><textarea name=meta3 style="display:block;width:100%" rows=1'
			.(is_null($row['meta'])?' disabled':'')
			.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}"'
			.' oninput="previousSibling.innerHTML=value.length"'
			.'>'.(empty($A[2])?'':$A[2]).'</textarea>'
	.'</div>'
	.'<div'.(is_null($row['meta'])?' onclick="var e=lastChild;if(!e.value){e.disabled=!e.disabled}if(!e.disabled){e.focus()}"':'')
		.'><small>Meta4: '.$L['meta4'].'</small><tt style="float:right" title="'.$L['symbols'].'"></tt><textarea name=meta4 style="display:block;width:100%" rows=1'
			.(is_null($row['meta'])?' disabled':'')
			.' onfocus="if(typeof(dataset.i)==\'undefined\'){dataset.i=value.hashCode()}"'
			.' oninput="previousSibling.innerHTML=value.length"'
			.'>'.(empty($A[3])?'':$A[3]).'</textarea>'
	.'</div>'
	.'<textarea name=meta style=display:none>'.$row['meta'].'</textarea>'
	.'<div style="font-size:12px;color:#999">Table `url` updated '.$row['t'].'</div>'
.'</div>';

$q='select count(*) as c from cat where parent='.$_POST['catEdit'];
$row1=DB::f(DB::q($q));

if($row['c']!=$row1['c']){
	$q='update cat set c='.$row1['c'].' where id='.$_POST['catEdit'];DB::q($q);
	echo '<div>'.$L['updated subpages number'].'</div>';
}

echo
'<div style="word-spacing:10px;margin-top:10px">'
	.'<input type=submit value="Save">'

	.' <a class=refresh onclick="'
		//.'delete(CKEDITOR);'
		.'ajx(event,\'core_catEdit\','.$_POST['catEdit'].',parentNode.parentNode)" title="Refresh"></a>';

	//if(!isset($_POST['ae'])){echo '<a onclick="var e=parentNode.parentNode;e.parentNode.removeChild(e)" style="float:right;font-size:24px">&times;</a>';}

	echo
	'<button type="button" style="width: auto;float:right;margin:5px;line-height:0;padding:8px 2px 12px;font-size:24px;font-family:-webkit-pictograph;"'
	.' onclick="screenfull.toggle(parentNode.parentNode.parentNode)" title="Screenfull">⤢</button>'
	
	.' <a onclick="var e=parentNode.parentNode.nextSibling;ajx(event,\'log\',\''.$_POST['catEdit'].'\',e)"'
		.' title="'.$L['visitorsLog'].'">Log</a>'
	
	.' <a title="'.$L['files'].'"'
		.' onclick="var e=parentNode.parentNode.nextSibling;ajx(event,\'core_files\',\''.$_POST['catEdit'].'&t='.rawurlencode($row['name']).'\',e)"'
		.'><tt class=sym>&#10048;</tt></a>'
	
	.' <button type="button" style="width:auto" title="'.$L['catDel'][0].'"'
		.' onclick="
			if(confirm(\''.$L['catDel'][1].'\')){
				ajx(event,\'core_catDel\','.$_POST['catEdit'].')
			}
		">'
		.$L['catDel'][2].' <tt style="vertical-align:middle;font-family:sans-serif;font-size:22px;line-height:0">&times;</tt>'
	.'</button>'
.'</div>';

if($row1['c']){
	echo
	'<fieldset data-id="'.$_POST['catEdit'].'" style="clear: both;margin:5px 0;border:solid 1px #ddd">'
		.'<legend>'
			.'<a onclick="'
					.'var e=parentNode.nextSibling;
					ajxTo(this,e,function(){ajx(event,`core_cat`,'.$_POST['catEdit'].',e,[ajxBtns,catOrdEvt],2)} )'

			.'">'.$L['subpages'][0].'</a> ('.$row1['c'].')'
		.'</legend>'
		.'<div class="ajxSibling" style="display:none"></div>'
		.'• <a title="'.$L['subpages'][1].'" onclick="
			if(confirm(title+\'?\')){
				ajx(event,\'core_catDel\',\''.$_POST['catEdit'].'&childs=\',parentNode)
			}">'.$L['subpages'][2].'</a>'
		.'<br>• '.$L['subV'][0].' <a onclick="ajx(event,\'core_catEdit\',\''.$_POST['catEdit'].'&childV=1\')" title="'.$L['subV'][1].'">"'.$L['subV'][2].'"</a>'
		.' | <a onclick="ajx(event,\'core_catEdit\',\''.$_POST['catEdit'].'&childV=0\')" title="'.$L['subV'][3].'">"'.$L['subV'][4].'"</a>'
	.'</fieldset>';
}
echo '<div style="clear:both"></div>';
if(!isset($_POST['v'])){
	echo
	'</form><div style="background-color:#fff"></div>';
}