<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$w=$_POST['slider'];
//if(!$w || $w>1220){$w=1220;}

$q='select img,'.DB::qL('adt').' from cat where parent=16 and v=1';	//HOME/Слайдер
$r=DB::q($q);
$n=DB::num_rows($r);
if($n){
	$i=0;
	while($row=DB::f($r)){
		echo '<div data-n='.$i;
		if($i==0){$i=1;echo ' style="transform:scaleX(1)"';}
		echo '>'
			.'<img src="/?img=/i/cat/'.$row['img'].'&w='.$w.'" style="">'
			.'<div style="">'.$row['adt'].'</div>'
		.'</div>';
	}
	echo '<nav onclick="slider1(event)">';
		for($i=1;$i<=$n;$i++){
			echo '<a>'.$i.'</a>';	//класс "a" (активная ссылка) устанавливается функцией "f" в функции "slider1"
		}
	echo '</nav>';
}