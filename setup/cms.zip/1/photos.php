<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

function photos($id,$tit='First image',$w=500,$h=375){	//4:3
	global $host,$catImg,$catImgV,$compCount;
	$S=array();
	$q='select name,'.DB::qL('text').',if(ord<0,999-ord,ord) as n from files where v=1 and cat='.$id.' order by n';
	$r=DB::q($q);
	$n=DB::num_rows($r);
	$A=array();
	if($n){	
		while($row=DB::f($r)){$row['name']=$id.'/'.rawurlencode($row['name']);$A[]=$row;}
	}
	if(!empty($catImg) && $catImgV!=-1){	//есть картинка страницы и её видимость не только для списка
		array_unshift($A,array('name'=>$catImg,'text'=>$tit));	//добавить в начало массива
		$n++;
	}
	if(!empty($A)){
		$count=count($A);
		$S[]=
			//'<script src="'.$host.'/js/ScrolBox.js"></script>'.
			'<img src="'.$host.'/?img=/i/cat/'.$A[0]['name'].($count>1?'&w='.$w.'&h='.$h.'&m&z':'&w='.$w).'"'
				.' data-file="'.$A[0]['name'].'"'
				.' title="'.$A[0]['text'].'"'
				.' alt="'.$A[0]['text'].'"'
				.' onclick="if(document.body.clientWidth>800){showImg1(this,\'/i/cat/\'+dataset.file)}"'	//ScrolBox.js
				.($host?' data-host="'.$host.'"':'')
				.' style="" onload="style.opacity=1">';
		if($count>1){
			$S[]=
			'<div class=block>'
				.'<div style="width:'.($n*121-1).'px;position:relative;cursor: pointer"'
					.' onclick="`use strict`;'
					.'if(dataset.m!=1){'	//после нажатия не было перемещения курсора
						.'var e=event.target,'
						.'n=parentNode.previousSibling;'	//img, куда поместить выбранную картинку
						.'if(e.dataset.file){'
							.'n.style.opacity=.0;'
							.'window.ajxPointer=[n,e];'
							.'window.setTimeout(\'ajxPointer[0].src=\\\''.$host.'/?img=/i/cat/\\\'+ajxPointer[1].dataset.file+\\\'&w='.$w.'&h='.$h.'&m&z\\\';ajxPointer[0].title=ajxPointer[1].title;ajxPointer[0].dataset.file=ajxPointer[1].dataset.file\',100)}'
					.'}"'
					.' onmousedown="ScrolBoxMD(event,this)" ontouchstart="ScrolBoxMD(event,this,1)"'
					.' onmouseup="ScrolBoxMU(event,this)" ontouchend="ScrolBoxMU(event,this)"'
					.' onmousemove="ScrolBoxMM(event,this)" ontouchmove="ScrolBoxTM(event,this)">';

					foreach($A as $row){
						$S[]='<img data-file="'.$row['name'].'"'
						.' src="'.$host.'/?img=/i/cat/'.$row['name'].'&w=120&h=90&m&z"'
						.' title="'.$row['text'].'">';
					}
				$S[]=
				'</div>'
			.'</div>';
		}
	}
	return implode('',$S);
}