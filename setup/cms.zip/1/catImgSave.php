<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

function catImgSave($id){
	global $root;
	$aPath=$root.'/i/cat';
	if(!file_exists($aPath)){mkdir($aPath);}
	$aPath.='/';
	$Result = '';
	if (isset($_POST['chk_Del_cat']) && isset($_POST['hdn_cat'])){	// если выставлен чекбокс удаления, то удаляем старый файл
		$s=$aPath.$_POST['hdn_cat'];
		if(file_exists($s)){unlink($s);}
		foreach(glob($s.'*.tmp') as $f){unlink($f);}
		return 'Deleted';
	}

	if (is_uploaded_file($_FILES['file_cat']["tmp_name"])){		// если был аплоад
		if (!empty($_POST['hdn_cat']) and !isset($_POST['chk_Del_cat'])){		// удаляем старый файл ,если еще не удалили его по чекбоксу
			$s=$aPath.$_POST['hdn_cat'];
			unlink($s);
			foreach(glob($s.'*.tmp') as $f){unlink($f);}
		}

		$t=$_FILES['file_cat']["name"];
		$t=substr($t, strrpos($t,'.'));	//расширение файла
		$tmpDstFile=$id.$t;
		
		if (move_uploaded_file($_FILES['file_cat']["tmp_name"], $aPath.$tmpDstFile)){
			$Result = $tmpDstFile;
		}else{$E=error_get_last();echo('Файл не скопирован: '.$E['message']);}
	}else if (isset($_POST['hdn_cat']) and !isset($_POST['chk_Del_cat'])){
		// аплоада не было - оставляем старое значение
		//$Result = $_POST['hdn_cat'];
	}
	return $Result;
}