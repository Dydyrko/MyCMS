<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$max=20;	//20;
$s=DB::esc($_GET['q']);

if(empty($_POST['row'])){$_POST['row']=array(0,0);}
else if(empty($_POST['row'][0])){$_POST['row'][0]=0;}
else if(empty($_POST['row'][1])){$_POST['row'][1]=0;}

$A=array();

$q='select A.id,A.name'.($lang==$Langs[0]?'':'_'.$lang).' as name'
.',P.name'.($lang==$Langs[0]?'':'_'.$lang).' as pName'
.',A.img'
.' from (cat A join url on A.id=url.id) join cat P on P.id=A.parent'
.' where A.v>0 and ('
.'A.name'.($lang==$Langs[0]?'':'_'.$lang).' like "%'.$s.'%"'
.' or url.text'.($lang==$Langs[0]?'':'_'.$lang).' like "%'.$s.'%"'
.' or A.adt'.($lang==$Langs[0]?'':'_'.$lang).' like "%'.$s.'%"'
.')'
//.(empty($_POST['cat'])?'':' and A.parent in ('.$_POST['cat'].')')	//для списка разделов
;
$q.=' order by P.ord,name'
.' limit 0'
//.(empty($_POST['row'][0])?'0':intval($_POST['row'][0]))
.','.$max
;

$r=DB::q($q);
$n=DB::num_rows($r);	
if($n){
	$p='';
	while($row=DB::f($r)){
		if($p!=$row['pName']){
			$p=$row['pName'];
			$A[]='<dt style=color:#e42438>'.$row['pName'];
		}
		$A[]='<dt style="'
		.'min-height:40px;padding-left:40px;background:url(/?img=/i/'.($row['img']?'cat/'.$row['img']:'0.jpg').'&w=32&h=32) no-repeat 0 0'
		.'"><a href="/'.sUrl($row['id']).'">'.$row['name'].'</a>';
	}
	if($n==$max){$A[]='<dt><a style="padding:10px" onclick="ajx(event,\'qSearch\',\''.rawurlencode($s)
		.'&cat='	//.rawurlencode($_POST['cat'])
		.'&row[0]='.($_POST['row'][0]+$n).'\',parentNode)">…</a></dt>';}
}
echo implode('',$A);