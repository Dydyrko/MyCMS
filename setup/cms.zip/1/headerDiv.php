<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(!empty($_POST['store'])){
	$A=explode("\t",$_POST['store']);
	$Fav=json_decode($A[0],true);
	$Cart=json_decode($A[1],true);
	$Comp=json_decode($A[2],true);

	if(!is_array($Fav)){$cFav=0;}else{$cFav=count($Fav);}
	if(is_array($Cart)){
		//$cCart=count($Cart);
		$cCart=0;
		foreach($Cart as $v){$cCart+=$v;}
	}else{$cCart=0;}
	if(is_array($Comp)){
		//$cComp=count($Comp);
		$cComp=0;
		foreach($Comp as $v){$cComp+=count($v);}
	}else{$cComp=0;}
}

	if(isset($_SESSION['user']['id'])){echo ' ';}	//для выполнения аякс в ".headerInfo"
	echo
	'<div class="login" style="position:relative;display:inline-block">';
			if(isset($_SESSION['user']['id'])){
				echo
				'<a onclick="var e=nextSibling;return ajxTo2(this,e'
						.',function (){
						ajx(event,\'login\',\'&personMenu=\',e)
						}'
					.')" title="'.$_SESSION['user']['name'].'">'
					//.'<img src="'.$host.'/?img=/i/'.($_SESSION['user']['img']?'cat/'.$_SESSION['user']['img']:'person.jpg').'&w=46&h=49" style="height:49px">'
					.'<img src="'.$host.'/i/cat/-30/user.png"> '
					.$_SESSION['user']['name']
					//.'<br>ID: '.$_SESSION['user']['id']
				.'</a>';
			}else{
				echo
				'<a href="/'.sUrl(-9).'" title="Вход или регистрация"'
					.' onclick="ajx(event,\'login\',\'&regUrl=\'+href,0,
							\'div.getElementsByTagName(\\\'input\\\')[0].focus()\');return false">'
					.'<img src="'.$host.'/i/cat/-30/user.png" style=padding:12px>'
					//.'<span class="loginLabel">'
					//	.($lang=='ru'?' Личный<br>кабинет':'Entrance<br>Registration')
					//.'</span>'
				.'</a>';
			}
			echo
			'<div class=loginDiv'
			.' style="transform:scaleY(0);transform-origin:top;transition:all .5s"></div>'
	.'</div>';
if(!empty($_POST['store'])){
	echo ' <a id="compCounter"'
		//.($cComp<1?' style="display:none"':'')
	.' href="/'.sUrl(-14).'" data-href="/'.sUrl(-14).'" onclick="
		var i=localStorage.getItem(\'compare\');if(!i){return false}
		href=dataset.href+\'?i=\'+encodeURIComponent(i)
	"><img src="'.$host.'/i/compare-white.svg"> <sup>'.($cComp?$cComp:'').'</sup></a>';


	echo ' <a id="favCounter"'
		//.($cFav<1?' style="display:none"':'')
		.' href="/'.sUrl(-15).'"'
		.' data-href="/'.sUrl(-15).'"'
		.' onclick="var i=localStorage.getItem(\'favorites\');if(!i || i==\'[]\'){return false}href=dataset.href+\'?i=\'+encodeURIComponent(i)"'
	.'><img src="'.$host.'/i/izbrannoe.svg"> <sup>'.($cFav?$cFav:'').'</sup></a>';

	echo ' <a id="cartCounter" title="Оформить заказ"'
		//.($cCart?'':' style="display:none"')
		.' href="/'.sUrl(-17).'"'
		.' data-href="/'.sUrl(-17).'"'
		.' onclick="var i=localStorage.getItem(\'cart\');if(!i){Alert(\'<h2>\'+title+\'</h2><div style=width:300px>'
			.'Для помещения товара в корзину нажмите на его цену'
		.'</div>\');return false}href=dataset.href+\'?i=\'+encodeURIComponent(i)"'
	.'><img src="'.$host.'/i/korzina.svg"> <sup>'.($cCart?$cCart:'').'</sup></a>';
}