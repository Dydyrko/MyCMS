<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(isset($_SESSION['user']['id'])){echo ' ';}	//авторизован - дать инфо

if($lang=='uk'){
	$s='Вхід або реєстрація';
}else if($lang=='ru'){
	$s='Вход или регистрация';
}else{
	$s='Login or registration';
}

echo
'<div class="login">';
		if(isset($_SESSION['user']['id'])){
			echo
			'<a onclick="var e=nextSibling;return ajxTo2(this,e'
					.',function (){ajx(event,\'core_personMenu\',0,e)}'
				.')" title="'.$_SESSION['user']['name'].'">'
				//.'<img src="'.$host.'/?img=/i/'.($_SESSION['user']['img']?'cat/'.$_SESSION['user']['img']:'person.jpg').'&w=46&h=49" style="height:49px">'
				.'<svg><use href="/i/cat/-30/user.svg#a"></use></svg> '
				.$_SESSION['user']['name']
				//.'<br>ID: '.$_SESSION['user']['id']
			.'</a>';
		}else{
			echo
			'<a href="/'.sUrl(-9).'" title="'.$s.'"'
				.' onclick="ajx(event,\'core_login\',\'&regUrl=\'+href,0,
						\'div.getElementsByTagName(\\\'input\\\')[0].focus()\');return false">'
				.'<svg><use href="/i/cat/-30/user.svg#a"></use></svg> '
			.'</a>';
		}
		echo
		'<div class=loginDiv'
		.' style="transform:scaleY(0);transform-origin:top;transition:all .5s"></div>'
.'</div>';

//if(!empty($_POST['store'])){}	//localStore: избранное, сравнение товаров, корзина