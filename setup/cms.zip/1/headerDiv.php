<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(isset($_SESSION['user']['id'])){echo ' ';}	//ответ начинается с пробела: авторизован - дать инфо

echo
'<div class="login">';
		if(isset($_SESSION['user']['id'])){
			echo
			'<a onclick="var e=nextSibling;return ajxTo2(this,e'
					.',function (){ajx(event,\'core_personMenu\',0,e)}'
				.')" title="'.$_SESSION['user']['name'].'">'
				.'<img src="/i/cat/-30/user.png"> '
				.$_SESSION['user']['name']
			.'</a>';
		}else{
			echo
			'<a href="/'.sUrl(-9).'" title="Вход или регистрация"'
				.' onclick="ajx(event,\'core_login\',\'&regUrl=\'+href,0,
						\'div.getElementsByTagName(\\\'input\\\')[0].focus()\');return false">'
				.'<img src="'.$host.'/i/cat/-30/user.png">'
			.'</a>';
		}
		echo
		'<div class=loginDiv'	//personMenu
		.' style=""></div>'
.'</div>';

//if(!empty($_POST['store'])){}	//localStore: избранное, сравнение товаров, корзина