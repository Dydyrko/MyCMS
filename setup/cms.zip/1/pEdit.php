<?php
if(__file__==$_SERVER['SCRIPT_FILENAME']){header($_SERVER["SERVER_PROTOCOL"].' 404 Not Found');exit('404 Not found');};

if(isset($_POST['pEdit']) && $_POST['pEdit']=='setUrl'){
	if(empty($_POST['n'])){
		$q='select cat.id,cat.name,transliterate_func(cat.name) as t'
		.' from url join cat on url.id=cat.id and cat.v>0'
		.' where url.url'.($lang==$Langs[0]?'':'_'.$lang).' is null';	// limit '.intval($_POST['m']).',100';
		$r=DB::q($q);
		$n=DB::num_rows($r);
		if($n){
			echo'<style>'
				.'.emptyUrl{border-collapse:collapse;width:100%;border-color:#ddd}'
				.'.emptyUrl td,.emptyUrl th{border-color:#ddd;padding: 5px;}'
				.'.emptyUrl th{color:#999}'
			.'</style>'
			.'<h2>Pages without friendly URLs ('.$n.')</h2>'
			.'<table class=emptyUrl border style="">'
			.'<tr><th>id<th>Name<th>Name transliteration — or link <br>to a page already with this URL';
			while($row=DB::f($r)){
				$q='select cat.id,cat.name from url join cat on url.id=cat.id where url'.($lang==$Langs[0]?'':'_'.$lang).'="'.$row['t'].'"';
				$r1=DB::q($q);
				if(DB::num_rows($r1)){
					$row1=DB::f($r1);
					$t=$row1['id'];
				}else{$t='';}
				echo '<tr><td>'.$row['id'].'<td>'.$row['name']
				.($t?'<th><a href=/'.$row['t'].' target=_blank title="'.$t.'">'.$row1['name'].'</a>'
				:'<td>'.$row['t'])
				;
			}
			echo '</table>';
		}else{
			echo '<h2>There are no missing URLs</h2><p>OK';
		}
	}else{
		$q='update IGNORE cat join url on cat.id=url.id and cat.v>0'
		.' set url.url'.($lang==$Langs[0]?'':'_'.$lang).'= transliterate_func(cat.name)'	//транслит имени основного языка, так как других могут быть пустые
		.' where url.url'.($lang==$Langs[0]?'':'_'.$lang).' is null and cat.id < '.intval($_POST['n']);
		//echo $q;
		DB::q($q);
		echo '<h2>Insert URL ('.DB::affected_rows().')</h2>'.'<br>'.DB::info();
	}
	exit;
}

$L=array();
if($lang=='ru'){
	$L['position']='Расположение списка';
	$L['positionV']='Под текстом';
	$L['Url']='транслит имени страницы — где отсутствует';
	$L['insertUrl']='Вставить до id';
}else if($lang=='uk'){
	$L['position']='Розташування списку';
	$L['positionV']='Під текстом';
	$L['Url']='трансліт імені сторінки — де відсутній';
	$L['insertUrl']='Вставити до id';
}else{
	$L['position']='List position';
	$L['positionV']='Under text';
	$L['Url']='transliterated page name — where missing';
	$L['insertUrl']='Insert up to page id';
}

	echo
	'<link rel="stylesheet" type="text/css" href="/css/checkbox.css">'
	.'<div style="clear:both;background-color:#eee;padding:5px;position: relative;z-index: 1;text-align: center">';

		if(!empty($_GET['p'])){
			echo
			'<div style="display:inline-block;vertical-align: top;margin:5px">'
				.'<button title="Add subpages to this page"'
				.' onclick="var n=nextSibling,t=n.value,e=parentNode.lastChild;if(t){ajx(event,\'pubs\',\''.$_GET['p'].'&add=\'+encodeURIComponent(t),e)}else{n.focus()}"'
				.'>Add pages</button>'
				.'<textarea style="display:block;width:100%" title="Article names line by line'."\n".' To execute, click the link above the input field"></textarea>'
				.'<div title="Added pages: id name"></div>'	//сюда результат
			.'</div>'
			.'<fieldset style="display:inline-block;vertical-align: top;margin:5px;min-width: 100px;">'
				.'<legend title="This page name">'.$catName.'</legend>'
				.'<button onclick="
				var e=window.open(\''
					.'/'.$lang	//указывать ли язык ?
					.'/?css&p='.$_GET['p']
					//.'&t='.htmlspecialchars($catName)
					.'\',\'css_'.$_GET['p'].'\',\'resizable,scrollbars,status\');
				e.focus();">CSS</button>'
				.'<b style="display:inline-block;width:2%"></b>'
				.'<button style="width:42%" onclick="
				var e=window.open(\'/'.$lang.'/?js&p='.$_GET['p']
					//.'&t='.htmlspecialchars($catName)
					.'\',\'js_'.$_GET['p'].'\',\'resizable,scrollbars,status\');
				e.focus();">JS</button>'
			.'</fieldset>'
			;
		}

		if(!empty($cVis)){	//количество видимых внутренних страниц
			echo
			'<fieldset style="display:inline-block;vertical-align: top;margin:5px">'
				.'<legend>Subpages</legend>'
				.'<button onclick="
				var e=window.open(\'/'.$lang.'/?css&p='.$_GET['p']
					//.'&t='.htmlspecialchars($catName)
					.'&child='.$cVis.'\',\'css_'.$_GET['p'].'\',\'resizable,scrollbars,status\');
				e.focus();">CSS</button>'
				.'<b style="display:inline-block;width:2%"></b>'
				.'<button style="width:42%" onclick="
				var e=window.open(\'/'.$lang.'/?js&p='.$_GET['p']
					//.'&t='.htmlspecialchars($catName)
					.'&child='.$cVis.'\',\'js_'.$_GET['p'].'\',\'resizable,scrollbars,status\');
				e.focus();">JS</button>'
			.'</fieldset>';

			echo
			'<fieldset style="display:inline-block;vertical-align:top;margin:5px;text-align:left">'
				.'<legend>Page list options</legend>'
				.'<form onsubmit="return ajxFormData(event,this,0,lastChild)">'	//adt списка страниц 
					.'<input name="core_css" value="note" type=hidden>'	//
					.'<input name=p value="'.$_GET['p'].'" type=hidden>'
					.'<table>'
					.'<tr><th>'.$L['position'].':<td><input name=underText value="'.(empty($LstParam['underText'])?'':$LstParam['underText']).'" type=hidden>'
						.'<input type=checkbox class=v value="1"'.(empty($LstParam['underText'])?'':' checked').'>'
						.'<a onclick="var e=previousSibling;e.checked=!e.checked;parentNode.firstChild.value=e.checked?1:0">'.$L['positionV'].'</a>'

					.'<tr><th>sort:<td><input name=ord list=ordList value="'.(empty($LstParam['ord'])?'':$LstParam['ord']).'"'
						.' title="You can list, in order of importance, the desired column names of the "cat" table, separated by commas:'
						.' «ord, name, id, d, d1», for reverse sorting — to any column after space: «desc»,'
						.' default value — «ord,d desc»">'
						.'<datalist id="ordList">'
							.'<option value="ord,name">'
							.'<option value="d desc">'
						.'</datalist>'
					.'<tr><th>limit:<td><input name=by value="'.(empty($LstParam['by'])?'':$LstParam['by']).'">'
					.'<tr><th>image width:<td><input name=w value="'.(empty($LstParam['w'])?'':$LstParam['w']).'">'
					.'<tr><th>image height:<td><input name=h value="'.(empty($LstParam['h'])?'':$LstParam['h']).'">'
					.'<tr><th>image transform:<td><select name=z>'
							.'<option value="">crop'
							.'<option value="top"'.(isset($LstParam['z']) && $LstParam['z']=='top'?' selected':'').'>crop to top'
							.'<option value="m&z"'.(isset($LstParam['z']) && $LstParam['z']=='m&z'?' selected':'').'>fit to size'
							.'<option value="m"'.(isset($LstParam['z']) && $LstParam['z']=='m'?' selected':'').'>fit'
						.'</select>'
					.'<tr><th><td><input type=submit value="Save">'
					.'</table>'
					.'<div></div>'
				.'</form>'
			.'</fieldset>'
			;
		}

		if(file_exists($root.'/favicon.svg')){$favicon='favicon.svg';}
			else if(file_exists($root.'/favicon.png')){$favicon='favicon.png';}
			else{$favicon='favicon.ico';}
		echo
		'<fieldset style="display:inline-block;vertical-align: top;margin:5px">'
			.'<legend>Favicon</legend>'
			.'<form onsubmit="ajxFormData(event,this)">'
				.'<a href="/'.$favicon.'" target=_blank><img src="/'.$favicon.'" height=48> '.$favicon.'</a> '
				.'<input name=file type=file accept="image/svg+xml,image/x-png,.ico" onchange="form.onsubmit()">'	//"image/*","image/x-png"
				.'<input name=cat type=hidden>'
				.'<input name=favicon type=hidden>'
			.'</form>'
		.'</fieldset>';

		echo
		'<fieldset style="display:inline-block;vertical-align: top;margin:5px">'
			.'<legend title="Search Engine Optimization">SEO</legend>'
			.'<button title="Edit text to HEAD tag HTML"'
				.' style="vertical-align:top;margin: 10px;"'
				.' onclick="var e=window.open(\'/?inHead\',\'inHead\',\'resizable,scrollbars,status\');e.focus();"'
			.'>inHead.txt</button>'
			.'<button title="Edit text at the beginning of the BODY tag HTML"'
				.' style="vertical-align:top;margin: 10px;"'
				.' onclick="var e=window.open(\'/?inBody\',\'inBody\',\'resizable,scrollbars,status\');e.focus();"'
			.'>inBody.txt</button>'
			.'<button style="vertical-align:top;margin: 10px;"'
				.' title="Edit robots.txt.'."\n"
				.' If the file is missing or the size is less than 30 bytes — the site visitor requires authorization (login: 1 and password: 1)'
				.' — so that search engines do not index the site for sure"'
				.' onclick="var e=window.open(\'/?robots\',\'robots\',\'resizable,scrollbars,status\');e.focus();"'
			.'>robots.txt</button>'
		.'</fieldset>';

		echo
		'<fieldset style="display:inline-block;vertical-align: top;margin:5px">'
			.'<legend title="Friendly URL">Url: '.$L['Url'].'</legend>'
			.'<a onclick="ajx(0,\'pEdit\',\'setUrl\')" class=btn>Show</a>'
			.'   <a onclick="var n=nextSibling.value;ajx(0,\'pEdit\',\'setUrl&n=\'+n)">'.$L['insertUrl'].':</a>'
			.'<input value=90000 type=number min=1000 step=1000 size=8>'

		.'</fieldset>';
	echo
	'</div>';