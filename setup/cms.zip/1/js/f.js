'use strict';

function Confirm(txt,f,L,a,modal,instead){
	if(!L){L=['Да','Нет']}
	txt='<center><div onclick="event.stopPropagation()" style="padding:15px">'
	+txt+'</div><button style="width:40%">'+L[0]+'</button> <button style="width:40%">'+L[1]+'</button><a class=close>&times;</a></center>';

	var div=showDiv(txt,a,modal,instead);
	var e=div.getElementsByTagName("button");
	e[0].addEventListener('click',f);
	e[0].focus();
	//e[0].addEventListener('keyDown',f);
	return false
}

function Alert(txt,a,modal,instead){	//a.focus()
	txt=txt+'<a class=close>&times;</a>';
	var div=showDiv(txt,a,modal,instead);
	return false
}

function openWin(a){	//href в окно браузера (target) и перевести на него фокус
	var	s="resizable,scrollbars=yes,status=1"
		,e=window.open(a.href,a.target,s);
	e.focus();
	window.setTimeout(f,999);
	function f(){e.focus()}
}

function pagerLI(evt,txt,div){
	var A=txt.split("\n"),e,n,i=0;
	for(i;i<A.length-1;i++){
		e=document.createElement("LI");
		e.innerHTML=A[i];
		div.appendChild(e);
	}
	e=div.parentNode;
	n=div.nextSibling;
	e.removeChild(n);
	n=document.createElement("DIV");
	n.innerHTML=A[A.length-1];
	e.appendChild(n);

	while(e=e.parentNode){
		if(e.className=="ajxAlert"){
			e=e.firstChild;
			n=(document.body.clientHeight-e.offsetHeight)/2;
			if(n<0){n=0}
			e.style.top=n+"px";
			break;
		}
	}
}

function jsAppend(a,b,f,c,host){	//a=имя скрипта без .js; b если нужно удалить скрипт, если уже загружался; f=функция на onload; c='js/filename.php?get'
	var n=g("js"+a);
	if(b && n){n.parentNode.removeChild(n);n=0;}
	//console.log(n,typeof(f),f);
	if(n){
		if(typeof(f)=='function'){f()}
		return true
	}else{
		var e=document.createElement("SCRIPT");
		e.async=false;
		e.src=(host?host:"")+"/"+(c?c:"js/"+a+".js");
		e.id="js"+a;
		document.head.appendChild(e);
		if(typeof(f)=='function'){
			e.onload=f	//top.setTimeout(f,999)
		}
		return e
	}
}

function ajxTo(a,e,f,f1){	//выполнить js в блок e из a
	e.style.display=(e.style.display=='none'?(e.dataset && e.dataset.s?e.dataset.s:''):'none');
	if(e.innerHTML.length<9 || e.firstChild.nodeName=='IMG'){	//пусто или картинка загрузки
		f()
	}else if(f1){
		f1()
	}
	return false
}
function ajxTo2(a,e,f,f1){	//выполнить js в блок e из a (использование: headerDiv.php personMenu)
	if(e.style.transform!='scaleY(1)'){e.style.transform='scaleY(1)'}else{e.style.transform='scaleY(0)'}
	if(e.innerHTML.length<9 || e.firstChild.nodeName=='IMG'){f()}else if(f1){f1()}
	return false
}
function ajxTo3(a,e,f,f1){	//выполнить js в блок e из a
	if(e.offsetHeight<e.scrollHeight){e.style.height=e.scrollHeight+'px'}else{e.style.height=0}
	if(e.innerHTML.length<9 || e.firstChild.nodeName=='IMG'){f()}else if(f1){f1()}
	return false
}

function nn(n){
	if(n<10){n='0'+n;}
	return n
}
function FormatDate(d){
	if(!d || !d.getDate){d=new Date();}
	return d.getFullYear()+'-'+nn(d.getMonth()+1)+'-'+nn(d.getDate());
}
function FormatNumber(s){	//между тысячами вставляет #160
	s=String(s);
	var A=[],j=0,i=s.length-1;
	for(i;i>=0;i--){
	 j++;
	 A.push(s[i]);
	 if(j%3==0){A.push(' ')}
	}
	A.reverse();
	return A.join('').trim()
}

function g(a){return document.getElementById(a)}

function chk(a,b){
	var e=a.previousSibling;e.checked=!e.checked;
	if(e.onclick){e.onclick()}
	if(b){e.form.onsubmit()}
}

function exp(a){	/* развернуть/свернуть блок после указанного в аргументе с классом 'exp' */
 var e=a.nextSibling;
 if(a.className!='exp a'){
  a.className='exp a';e.style.height=e.scrollHeight+'px'
 }else{
  a.className='exp';e.style.height=0
 }
}

function ScrollTop(){
	return document.documentElement.scrollTop || document.body.scrollTop
}

function Scroll(a,b){	//элемент,предыдущее значение scrollTop
	var rect = a.getBoundingClientRect(),y=rect.top,st=document.documentElement.scrollTop || document.body.scrollTop;
	if(y>50 && (!b || b<st)){	//пока scrollTop увеличивается
		document.documentElement.scrollTop=50+st;
		document.body.scrollTop=50+st;
		window.setTimeout(f,30);
	}
	function f(){Scroll(a,st)}
}

	//http://werxltd.com/wp/2010/05/13/javascript-implementation-of-javas-string-hashcode-method/
	//http://www.queryadmin.com/1611/java-hashcode-php-javascript/	//php not for UTF-8
String.prototype.hashCode = function(){
	var hash=0,i=0,char;
	if(this.length==0){return hash}
	for(i;i<this.length;i++){
		char=this.charCodeAt(i);
		hash=((hash<<5)-hash)+char;
		hash=hash & hash;	//Convert to 32bit integer
	}
	return hash;
};


function ajxDisabled(e){
	if(e){
		if(typeof(e.dataset.i)=='undefined' || e.dataset && e.dataset.i && e.value.hashCode()==e.dataset.i){e.disabled=true}
	}
}

function dateStr(d){return d.getFullYear()+'-'+nn(d.getMonth()+1)+'-'+nn(d.getDate())}

function notify(Title,Body,Tag,Time,Func,Icon){
	if(location.protocol!="https:" || !("Notification" in window)){return false}
	if(Notification.permission=="granted"){
		if(!Tag){Tag=""}
		var n = new Notification(Title, {
			tag : Tag,
			body : Body,
			icon : Icon?Icon:""	//"/i/logo.png"
		});
		
		if(Time){
			setTimeout(n.close.bind(n), Time*1000)
		}else{
			n.onclick=Func?Func:function(){Alert("<h2>"+this.title+"</h2>"+this.body)}
		}
	}else if(Notification.permission=="denied"){
		return "denied";
	}else{
		Alert("<h2>"+Title+"</h2>"+Body+"<hr><a onclick='\
		Notification.requestPermission().then(function(result) {\
			console.log(`Notification status:`,result);\
			if(result==`granted`){notify(`"+Title+"`,`"+Body+"`,`"+Tag+"`,`"+Time+"`,0,`"+Icon+"`);}\
			var n=document.querySelector(`.ajxAlert`);\
			if(n){n.click();}\
		});\
		'>Enable notifications</a>");
		return 0;
	}
	return true;
}

function getCookie(name) {
  var matches = document.cookie.match(new RegExp(
    "(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
  ));
  return matches ? decodeURIComponent(matches[1]) : undefined;
}

function Url(href){
	var s=href.toString();
	return s.substring(0,s.indexOf('?'))
}

function setD(a,target) {
	if(!target){target=a.nextSibling}
	var d=new Date();target.value=d.getFullYear()+'-'+(d.getMonth()+1)+'-'+d.getDate()+' '+d.getHours()+':'+d.getMinutes()+':'+d.getSeconds()
}

function bH(b){
	document.body.style.height=(b?document.documentElement.clientHeight:document.body.scrollHeight)+'px'
}

function pswClick(a,f){
	if(event.target==a){	//div.psw содержит input, нажали не на input, а :before или :after
		var	e=a.firstChild,		//input
			rect=event.target.getBoundingClientRect(),x=event.clientX-rect.left;
			//можно бы проще: x=event.offsetX || event.layerX; Но offsetX и layerX не стандартные свойства (Firefox — только layerX)
		if(x<50){
			if(e.type!='text'){
				e.type='text';a.className='psw t'
			}else{
				e.type='password';a.className='psw'
			}
		}else{
			f()	//qNewPsw
		}
	}
}
function qNewPsw(){
	ajx(0,'core_login','newPsw',0,
		'var e=document.querySelector(".LogIn form"),n=document.querySelector("form.newPsw");\
		n.elements["core_login"].value=e.elements["core_login"].value;n.elements["captcha"].focus()'
	)
}

function youtube(v){
	Alert("<h2>Youtube</h2><iframe style=\'width:90vw;height:80vh\' src=\'https://www.youtube.com/embed/"
	+v+"?hl="+document.documentElement.lang
	+"\' title=\'YouTube video player\' frameborder=0 allow=\'accelerometer;autoplay;clipboard-write;encrypted-media;gyroscope;picture-in-picture\' allowfullscreen></iframe>");
}