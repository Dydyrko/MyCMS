	//<input value="2016-06-05" type=hidden onblur="alert(value)"><a onclick="calendar(this,60,0,20)" title="Дата рождения">05.06.2016</a><div class=calendar></div>
	//lang_ru.js

'use strict';

function calendar(a,y1,y2,y0){	//this [, от лет назад, до лет вперёд, лет назад по-умолчанию]
	var i,t=new Date();
	if(typeof(a.length)=='undefined'){	//не массив
		var	e=a.nextSibling,
			D=a.previousSibling,
			title=a.title?a.title:'';
		if(D && D.value){
			D=D.value.split('-');
		}else if(y0){
			D=[t.getFullYear()-y0,1,1];			//лет назад по-умолчанию (1 января) для дня рождения
		}else{
			D=[t.getFullYear(),t.getMonth()+1,t.getDate()]	//сегодня
		}
	}else{

		var	D=a,	//массив [y,m,d,e]
			e=a[3],		//блок календаря
			title=a[4]
	}
	show(D[0],parseInt(D[1]),parseInt(D[2]));

	function show(y,m,d){
		var M=Lang.M,W=Lang.W;
		if(typeof(y1)!='number'){y1=10}	//y1=false
		if(typeof(y2)!='number'){y2=10}
		var y01=t.getFullYear()-y1,y02=t.getFullYear()+y2;

		if(y01>y){y01=y}
		if(y02<y){y02=y}

		var A=['<a class=close onclick="parentNode.innerHTML=\'\'" title="Close">&times;</a>'];
		if(title){title=title.replace(/\n/g,'<br>');A.push('<h1>'+title+'</h1>')}
		A.push('<table><thead><tr>');

		A.push('<td colspan=2><select onchange="calendarYearSelect(this,'+y+','+m+','+d+',\''+title+'\','+y1+','+y2+','+y0+')" style="width:100%">');

			A.push('<option value="-" title="'+Lang['calendarExtend']+'" style="text-align:center">–');

			for(i=y01;i<=y02;i++){A.push('<option'+(i==D[0]?' selected':'')+'>'+i)}

			A.push('<option value="+" title="'+Lang['calendarExtend']+'" style="text-align:center">+');

		A.push('</select>');
		A.push('<td class=null style="font-size:100%" title="Today" onclick="calendarDate(event,0,1)">Now');
		A.push('<td class="null" title="Empty" onclick="calendarDate(event,0,0)">&times');
		A.push('<td colspan=3><select onchange="calendar(['+y+',(parseInt(value)+1),'+d+',parentNode.parentNode.parentNode.parentNode.parentNode,\''+title+'\'],'+y1+','+y2+','+y0+')" style="width:100%">');
			for(i in M){A.push('<option value="'+i+'"'+(i==parseInt(D[1])-1?' selected':'')+'>'+M[i])}
		A.push('</select><tr>');

		for(i in W){A.push('<th width=30>'+W[i])}	

		t.setYear(y);t.setMonth(m-1);t.setDate(1);
		var t1=t.getDay();if(t1==0){t1=7};	//день недели 1 числа
		t.setMonth(m);t.setDate(1);	//день 1 числа следующего месяца
		var nn=t.getTime()-3600*24*1000;t=new Date(nn);nn=t.getDate();	//последний день месяца
		var n=1;	//1 число месяца
		A.push('<tbody onclick="calendarDate(event,'+y+','+m+')"><tr>');
		for(i=0;i<42;i++){
			if(t1>i+1){
				A.push("<th>&nbsp;</th>");
			}else{
				if(n<=nn){
					A.push('<td');
					if(n==d){A.push(' class="d"')}
					A.push(">"+n+"</td>")
				}else{
					A.push("<th>&nbsp;</th>")
				}
				if((n>=nn)&&(i==34)){break};
				if((i+1)%7==0){A.push('</tr><tr>')};
				n++
			}
		}	
		A.push('</tbody></table>');	
		e.innerHTML=A.join('');
	}

}
function calendarDate(evt,y,m){
	var e=evt.target;
	if(e.nodeName!='TD'){return false}
	var d=nn(e.innerHTML);
	if(m){m=nn(m)}
	e=e.parentNode.parentNode.parentNode.parentNode;
	e.innerHTML='';
	e=e.previousSibling;		//a
	var	n=e.previousSibling;	//input
	if(y){
		if(n.type=='hidden'){e.innerHTML=Lang.dFormat(y,m,d)}		//в <a> может быть картинка календаря
		var t=y+'-'+m+'-'+d;
		if(n && n.value!=t){
			n.value=t
		}else{return}
	}else if(m){
		//console.log('m=',m);
		var t=new Date();
		n.value=t.getFullYear()+'-'+(t.getMonth()+1)+'-'+t.getDate()+' '+t.getHours()+':'+t.getMinutes()
	}else{
		if(n.value!=''){
			n.value=''
		}else{return}
	}
	if(n.onblur){n.onblur()}
	function nn(a){if(a<10){a='0'+a}return a}
}

function calendarYearSelect(a,y,m,d,title,y1,y2,y0){
	calendar(
		[(parseInt(a.value)?a.value:y),m,d,a.parentNode.parentNode.parentNode.parentNode.parentNode,title],
		(a.value=='-'?(y1+50):y1),
		(a.value=='+'?(y2+50):y2),
		y0
	)
}