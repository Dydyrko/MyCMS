"use strict";

window.addEventListener("scroll",ScrollToUp);
function ScrollToUp(){
	var y=document.documentElement.scrollTop || document.body.scrollTop;
	var e=g("scrollUp");
	if(!e){
		e=document.createElement("A");
		e.style="opacity:0;transition: all 1s ease 0s";
		e.id="scrollUp";
		//e.onclick="ScrollUp();return false";
		e.addEventListener("click",function(){ScrollUp();return false},false);
		e.textContent="Вверх";
		document.body.appendChild(e);
	}
	e.style.opacity=(y>300?1:0);
	//document.body.firstChild.className=(y>300?"fixed":"");
}
function ScrollUp(b){	//прокрутить страницу вверх
	var st=document.documentElement.scrollTop || document.body.scrollTop,y;
	if(st>0 && (!b || b<st)){	//92
		y=st-(st/5+5);
		document.documentElement.scrollTop=y;
		document.body.scrollTop=y;
		window.setTimeout(f,20);
	}
	function f(){ScrollUp(b)}
}