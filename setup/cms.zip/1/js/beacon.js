'use strict';
function beacon(data){	//FormData or array. <input type=file> if(n.files){formData.append('userfile',n.files);}
	if(data.length && data.length==2){	//example: data=['core_editMode',p.checked]
		var formData=new FormData();
		formData.append(data[0],data[1]);
	}
	var lang=document.documentElement.lang,s=(lang?"/"+lang:"")+"/?ajx";
	return navigator.sendBeacon(s,data);	
}