'use strict';

function checkPassword(p) {
	var
	a = "abcdefghijklmnopqrstuvwxyz",
	b = "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
	d = "0123456789",
	s = "!@#$%^&*()_+-=[]{}|?/,.",
	ai = false,
	bi = false,
	di = false,
	si = false;
	for(var i=0; i<p.length;i++){
		if(a.indexOf(p[i]) != -1){ai=true}
		else if(b.indexOf(p[i]) != -1){bi=true}
		else if(d.indexOf(p[i]) != -1){di=true}
		else{si = true;}
	}
	if(p.length >7 && ai && bi && di && si){return 3}else{return 0}
}

function randomPassword() {
	var
	A2Z = "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
	a2z = "abcdefghijklmnopqrstuvwxyz",
	zero2nine = "0123456789",
	specials = "!@#$%^&*()_+-=[]{}|?/,.",
	chars=zero2nine + A2Z + a2z + specials,
	rs = [].concat(
		[specials[Math.floor(Math.random() * specials.length)]],
		[A2Z[Math.floor(Math.random() * A2Z.length)]],
		[a2z[Math.floor(Math.random() * a2z.length)]],
		[zero2nine[Math.floor(Math.random() * zero2nine.length)]],
		[
			chars[Math.floor(Math.random() * chars.length)],
			chars[Math.floor(Math.random() * chars.length)],
			chars[Math.floor(Math.random() * chars.length)],
			chars[Math.floor(Math.random() * chars.length)]
		]
	);
	return rs.sort(
		function(){return Math.random() > Math.random()}
	).join('');
}