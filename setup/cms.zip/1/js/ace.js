'use strict';	//вариант редактирования textarea в ace. Применяется для редактирования файла в галерее страницы

jsAppend("aceAPI",0,ace0,"js/ace/src-min-noconflict/ace.js");

function ace0(){
	jsAppend("aceExt",0,ace1,"js/ace/src-min-noconflict/ext-language_tools.js");
}

function ace1(){
	var e=g("aceEditor"),t=e.dataset.t?e.dataset.t:"html";

	ace.require("ace/ext/language_tools");

	var editor = ace.edit("aceEditor");
	editor.setTheme("ace/theme/terminal");
	editor.getSession().setMode("ace/mode/"+t);

	editor.setOptions({
		enableBasicAutocompletion: true,
		enableSnippets: true,
		enableLiveAutocompletion: true
	});

	var n=document.createElement("DIV");
	n.style="position:absolute;z-index:1;top:0;right:0;left:0;height:25px;background-color:rgba(200,200,200,1)";

	n.innerHTML=
	`<button
	 onclick="
		var editor = ace.edit('aceEditor');
		form.elements['text'].value=editor.getValue();
		nextSibling.focus()
	">Применить</button><button style="margin-left:10px" title="Закрыть редактор (если потребуется сохранить изменения — прежде «Применить»)"
	 onclick="var n=parentNode;n.parentNode.removeChild(n.previousSibling);n.parentNode.removeChild(n)">`
	+e.parentNode.elements['aceBtn'].nextSibling.textContent+` &times;</button>
	<select id="aceTheme" title="aceTheme" style=float:right>
		<option>crimson_editor
		<option>kuroir
		<option>terminal
	</select>`;

	e.parentNode.appendChild(n);

	e=document.getElementById('aceTheme');
	e.addEventListener('change',function(){
		var editor=ace.edit('aceEditor');editor.setTheme("ace/theme/"+this.value);
		localStorage.setItem('aceTheme',this.value);
	});
	n=localStorage.getItem('aceTheme');
	if(!n){n='crimson_editor'}
	e.value=n;
	editor.setTheme("ace/theme/"+n);
}