'use strict';	//редактор ACE файлов подключается при AJX списка файлов (кнопка F в шапке админки dev). Без промежуточного TEXTAREA

jsAppend("aceAPI",0,ace0,"js/ace/src-min-noconflict/ace.js");

function ace0(){
	jsAppend("aceExt",0,0,"js/ace/src-min-noconflict/ext-language_tools.js");
}

function ace1(a,fileName){
	var A=fileName.split('.'),t=A.pop(),	//расширение файла
	dir=a.previousSibling.dataset.dir;

	var e=document.createElement("DIV");
	e.style="position:absolute;top:0;right:0;left:0;background-color:#fafafa";
	e.title=dir+fileName;
	a.appendChild(e);

	var n=document.createElement("INPUT");
	n.type="text";
	//n.style="position:absolute;top:0;left:0;width:200px";
	n.value=n.dataset.v=fileName;
	n.title="Имя файла: возможность сохранить под другим именем.\n Иначе прежний файл переименовывается в *.bak";
	n.addEventListener('input',function(){this.style.backgroundColor=(this.value==this.dataset.v?'':'yellow')});
	e.appendChild(n);

	n=document.createElement("BUTTON");
	n.id='aceSave';
	n.style.backgroundColor="orange";
	n.style.margin="0 10px";
	n.innerHTML="Save";
	n.title="Сохранить файл под прежним именем с созданием «*.bak»\n или изменённым (фон поля тогда жёлтый)\n[F2]";
	n.addEventListener('click',function(){
		var editor=ace.edit('aceEditor'),t=editor.getValue();
		//console.log(t);
		if(confirm('Сохранить файл «'+this.previousSibling.value+'»?')){
			ajx(0,'sql','files&saveFile='+encodeURIComponent(dir+this.previousSibling.value)+'&t='+encodeURIComponent(t))
		}
	});
	e.appendChild(n);

	n=document.createElement("SELECT");
	n.id='aceTheme';
	n.title="Выбор темы оформления. Сохраняется в localStorage";
	A=[
		'crimson_editor',
		'kuroir',
		'terminal',
	];
	var i=0,m;
	for(i;i<A.length;i++){
		m=document.createElement("OPTION");
		m.text=A[i];
		n.appendChild(m);
	}
	n.addEventListener('change',function(){
		var editor=ace.edit('aceEditor');editor.setTheme("ace/theme/"+this.value);
		localStorage.setItem('aceTheme',this.value);
	});
	e.appendChild(n);

	n=document.createElement("BUTTON");
	n.id='aceClose';
	n.title="Закрыть редактор файла [Shift+Esc]";
	n.style.backgroundColor="lightgreen";
	n.style.margin="0 10px";
	n.innerHTML="Close «"+dir+fileName+"» &times;";
	n.addEventListener('click',function(){this.parentNode.parentNode.innerHTML=""});
	e.appendChild(n);

	n=document.createElement("DIV");
	n.id="aceEditor";
	n.dataset.t=t;
	n.style="position:absolute;z-index:1;top:25px;bottom:0;right:0;left:0";
	a.appendChild(n);

	a.addEventListener('keyup',function(ev){
		//console.log(ev.keyCode);
		var closeBtn=g('aceClose');
		if(!closeBtn){return}
		if(ev.keyCode==113){g('aceSave').click()}
		if(ev.keyCode==27 && ev.shiftKey){closeBtn.click()}
	});
}

function ace2(evt,txt,div){	//callback ajx после получения текста файла — отображение в редакторе
	var t=div.dataset.t;
	if(!t || t=='txt'){t='text'}
	else if(t=='js'){t='javascript'}
	else if(t=='htm'){t='html'}

	var i=0,b,A=['php','javascript','css','text','xml'];
	for(i;i<A.length;i++){if(t==A[i]){b=1}}
	if(!b){t='text'}
	//console.log(t);

	ace.require("ace/ext/language_tools");
	var editor = ace.edit("aceEditor");
	editor.getSession().setMode("ace/mode/"+t);


	t=localStorage.getItem('aceTheme');
	if(!t){t='crimson_editor'}
	g('aceTheme').value=t;
	editor.setTheme("ace/theme/"+t);

	//console.log(editor);

	editor.setOptions({
		enableBasicAutocompletion: true,
		enableSnippets: true,
		enableLiveAutocompletion: true
	});
	editor.setValue(txt)
}