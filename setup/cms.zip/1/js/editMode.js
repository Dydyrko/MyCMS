'use strict';
function editBarMD(a,touch){	//a=this, onmousedown | ontouchstart
	if(touch){document.body.style.overflow='hidden';}
	var	top=a.style.top,
		y=touch?event.changedTouches[0].clientY:event.clientY;
	if(!top){top=document.documentElement.clientHeight-a.offsetHeight-parseInt(a.style.bottom);a.style.bottom=null;a.style.top=top+'px'}
	a.dataset.y=y-parseInt(a.style.top);
}

function editBarSave(a){
	var m=a.parentNode.parentNode,e=m.parentNode.nextSibling,n=e.querySelectorAll('.noedit'),i;
	if(n){
		for(i in n){
			if(n[i].nodeName){n[i].textContent=(n[i].dataset.t?'{'+n[i].dataset.t+'}':'')}
		}
	}
	n=e.querySelector('input.tel[data-i="1"]');
	if(n){n.removeAttribute('data-i')}
	a.nextSibling.innerHTML='';
	var A=[
		m.dataset.id,
		(m.dataset.adt?'&adt=':'&text='),
		encodeURIComponent(m.parentNode.nextSibling.innerHTML)
	],
	t=A.join('');
	console.log(t.length);
	ajx(event,'core_editBar',t,a.nextSibling)
}

function imgSrc(a){
	var lang=document.documentElement.lang,L={'ru':[],'uk':[],'en':[]},s;
	if(!lang){lang=='en'}
	L['ru'][0]='<p>Повторите до сообщения «ОК».<p>Сохраните текст страницы';
	L['uk'][0]='<p>Повторіть до повідомлення «ОК».<p>Збережіть текст сторінки';
	L['en'][0]='<p>Repeat until "OK".<p>Don\'t forget to save the page text';

	L['ru'][1]='<h2>Проверка картинок</h2><p>Картинок нет';
	L['uk'][1]='<h2>Перевірка зображень</h2><p>Зображень нема';
	L['en'][1]='<h2>Checking pictures</h2><p>No pictures';

	L['ru'][2]='<h2>Файлы</h2><p>Картинка сохранена с сервера «';
	L['ru'][3]='» в галерею файлов страницы<p>';

	L['uk'][2]='<h2>Файли</h2><p>Зображення збережено з сервера «';
	L['uk'][3]='» до галереї файлів сторінки<p>';

	L['en'][2]='<h2>Files</h2><p>Image saved from server «';
	L['en'][3]='» to the gallery of page files<p>';

	L['ru'][4]='<h2>Файлы</h2><p>Изображение перемещено из текста в галерею файлов страницы<p>';
	L['uk'][4]='<h2>Файли</h2><p>Зображення переміщено з тексту в галерею файлів сторінки<p>';
	L['en'][4]='<h2>Files</h2><p>Image moved from text to page file gallery<p>';

	L['ru'][5]='<h2>Проверка картинок ';
	L['ru'][6]=' Изменений: ';

	L['uk'][5]='<h2>Перевірка картинок ';
	L['uk'][6]=' Змін: ';

	L['en'][5]='<h2>Checking images ';
	L['en'][6]=' Changes: ';

	var	note=L[lang][0];
	var	editBar=a;while(editBar){if(editBar.className=='editBar'){break;}else{editBar=editBar.parentNode}}
	var	id=editBar.dataset.id,e=editBar.parentNode.nextSibling,n=e.querySelectorAll('.noedit'),i;
	if(n){
		for(i in n){
			if(n[i].nodeName){n[i].innerHTML=''}
		}
	}

	n=e.getElementsByTagName('IMG');
	var	m=n.length,
		c=0,	//счетчик изменений src
		t,A;

	if(!m){
		Alert(L[lang][1]);return;
	}
	for(i=0;i<m;i++){
		t=n[i].attributes.src.value;
		A=t.split('/');			//https: / / domen
		if(A.length>3 && A[1]==''){	//есть «//»
			if(A[2]==location.hostname){
				A.splice(0,2);		//удаляем 2 первых элемента массива
				A[0]='';		//пусто вместо домена
				n[i].src=A.join('/');	//путь от корня сайта
				c++;
				console.log(c,n[i].src,n[i].attributes);
			}else{
				ajx(event,'core_files',id+'&new=URL&name='+encodeURIComponent(t)+'&dataimg=',
				n[i],['if(txt[0]=="/"){div.src=txt;div.innerText="";div=0;txt=L[lang][2]+ A[2]+L[lang][3]+txt+"'+note+'"}else{div=0}']
				);
				return;
			}
		}
		if(t.indexOf('base64')>0){
			ajx(event,'core_files',id+'&new=b&dataimg='+encodeURIComponent(t),
			n[i],['if(txt[0]=="/"){div.src=txt;div.innerText="";div=0;txt="'+L[lang][4]+'"+txt+"'+note+'"}else{div=0}']
			);
			return;
		}
		if(c || i==m-1){			
			Alert(L[lang][5]+(i+1)+'/'+m+'</h2>'+(c?L[lang][6]+c+note:'OK'));
		}
	}
}

function imgTool(){	//кнопка IMG в editTools.php
	var s=document.getSelection(),n=s.focusOffset,src="",img;

	if(n){
		console.log(n,s.focusNode);
		img=s.focusNode.childNodes[n-1];
	}else{
		img=s.anchorNode.firstElementChild;
	}

	if(!img){
		img=s.anchorNode.nextSibling;
		console.log('anchorNode.nextSibling',img);
	}

	if(img && img.nodeName=="IMG" && img.attributes["src"] && img.attributes["src"].value.length){
		src=img.src
	}else{
		img=0;	//img без src картинкой не считается
	}
	
	if(src){
		console.log(img,src);
		var t=location.origin.length;
		src=src.substr(t);
		console.log(src);
	}
	
	var t=prompt(
		(s.type=="Range"?"Выделено: «"+s+"»\n\n":"")+"Укажите ALT и SRC "+(img?"существующей":"новой")+" картинке через два символа равенства\n (в поле ввода — пример)",
		(img?img.alt:"Пример картинки")+"=="+(src && src!=""?src:"/i/t.gif")
	);

	if(t===null){return}
	if(t==""){return}
	t=t.replace(/"/g,"`");
	if(img){
		var A=t.split("==");
		if(A[0]!=""){img.alt=A[0]}
		if(A[1]!=""){img.src=A[1]}
	}else{
		var A=t.split("=="),B={alt:"",src:""};
		if(A[0]!=""){B.alt=A[0]}
		if(A[1]!=""){B.src=A[1]}

		t="<img alt=\""+B.alt+"\" src=\""+B.src+"\" />";
		document.execCommand("insertHTML",false,t)
	}
}
/*
function fileClick(a){
	var s=document.getSelection(),err='<h2>'+a.title+'</h2><p>Включите редактирование текста и установите в нём курсор</p><div></div>';
	if(!s || !s.focusNode){Alert(err);return}	//не установлен курсор
	n=s.focusNode.parentNode;
	while(n){
		console.log(n.contentEditable,n);
		if(n.className=='pText' && n.contentEditable=='true'){n=1;break}
		n=n.parentNode;
	}
	if(n!=1){Alert(err);return}	//вставлять img не требуется

	var n=s.focusOffset,timg;	//targetImg
	if(n && s.focusNode.childNodes.length){
		console.log(n,s.focusNode);
		timg=s.focusNode.childNodes[n-1];
	}else{
		timg=s.anchorNode.firstElementChild;
	}
	if(!timg){timg=s.anchorNode.nextSibling;}
	console.log(timg);

	var img=a.parentNode.querySelector('IMG');
	if(timg && timg.nodeName=='IMG'){
		if(confirm(
			'Set src to image?\n'
			+(timg.attributes['src']?'SRC: '+timg.attributes['src'].value:'ALT: '+timg.alt)
			+'\nto SRC: '+img.attributes['src'].value
		)){
			timg.src=img.attributes['src'].value
		}
	}else{
		img.alt=a.parentNode.querySelector('INPUT[name^=\'name\']').value;
		if(confirm('focusNode: «'+s.focusNode.textContent+'»\nInsert image?\n'+img.outerHTML)){
			document.execCommand('insertHTML',false,img.outerHTML);
		}
	}
}
*/