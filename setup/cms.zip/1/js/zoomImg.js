'use strict';
function zoomImg(){
	var e=document.querySelectorAll(".zoomImg img"),i=0,t,n=document.getElementById("zoomImgDiv"),m;
	if(!e){return}
	for(i;i<e.length;i++){
		e[i].style.cursor="zoom-in";
		e[i].addEventListener('click',function(ev){
			//console.log(ev);
			var e=ev.target,t=e.src.split('=');
			if(t[1]){
				t=t[1];
				t=t.substr(0,t.indexOf("&"));	//имя файла
			}else{t=e.src}

			m=t.substr(t.length-4);
			if(m.toLowerCase()=='.pdf'){
				m=window.open(t,'_blank','resizable=yes');m.focus()
			}else{

				if(!n){
					n=document.createElement("div");
					n.id="zoomImgDiv";
					n.style.position="fixed";
					n.style.zIndex=99;
					n.style.left=0;
					n.style.top=0;
					n.style.right=0;
					n.style.bottom=0;
					n.style.backgroundColor="rgba(200,200,200,.9)";
					n.style.transition="all 0.5s";
					n.addEventListener('click',function(ev){zoomImgClose(this)});
					n.style.cursor="zoom-out";
					document.body.appendChild(n);
				}else{n.style.display="block";n.style.opacity=1;}
				n.innerHTML='<div style="position:absolute;z-index:1;right:20px;top:0px;font-size:42px;color:#fff;text-shadow: 0 0 3px black;">&times;</div>';
				if(e.alt){
					n.innerHTML+='<div style="position:relative;z-index:1;text-align:center"><b style="padding:0 5px;text-shadow: 0 0 3px #fff;">'+e.alt+'<b></div>';
				}
	
				m=document.createElement("div");
				m.style.position="absolute";
				m.style.left=0;
				m.style.top=0;
				m.style.right=0;
				m.style.bottom=0;
				m.style.backgroundImage="url("+t+")";
				m.style.backgroundRepeat="no-repeat";
				m.style.backgroundSize="contain";
				m.style.backgroundPosition="center";
	
				m.style.transform="scale(0)";
				m.style.transformOrigin=ev.clientX+"px "+ev.clientY+"px";
				m.style.transition="all 0.5s";
		
				n.appendChild(m);
				window.setTimeout(f,99);
				function f(){m.style.transform="scale(1)";}
			}
		});
	}
}
function zoomImgClose(a){
	a.lastChild.style.transform='scale(0)';a.style.opacity=0;
	window.setTimeout(f,500);
	function f(){a.innerHTML='';a.style.display='none'}
}
zoomImg();