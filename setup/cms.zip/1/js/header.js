'use strict';

function loginSubmit(event,a){
	ajxFormData(event,a,
		[
			'var t=txt.substr(-1,1);			/* Последний символ результата */\
			if(t=="?"){div=form.lastChild.firstChild}	/* текст вопроса поместить над кнопкой входа */\
			else if(txt=="dev"){t=document.documentElement.lang;top.location="/"+(document.documentElement.dataset.lang==t?"":t+"/")+"admin"}	/* разработчику открыть админку */\
			else{document.location.reload(true)}'		//перегрузить с очисткой кэша
		],
		document.querySelector('.login')	//блок авторизации в шапке
	);
	return false
}
function headerDiv(){
	var e=g("headerDiv");
	if(e){
		ajx(
			0,"login","headerDiv&store=",e,
			"if(txt[0]==' ' && window.screen.width>=680){headerInfo()}"	//инфо для авторизованного посетителя (при широком экране)
		)
	};
}
function headerInfo(){
	var e=document.querySelector("header .info");if(e){ajx(0,"login","headerInfo",e)}
}

window.addEventListener("load",headerDiv,false);

window.addEventListener("scroll",function(){
	var e=e=g("arrowUp");if(!e){return}
	e.className=window.scrollY>100?"a":"";
},false);