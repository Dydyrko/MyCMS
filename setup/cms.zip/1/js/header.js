'use strict';

function loginSubmit(event,a){
	ajxFormData(event,a,
		[
			'var t=txt.substr(-1,1);			/* Последний символ результата */\
			if(t=="?"){div=form.lastChild.firstChild}	/* текст вопроса поместить над кнопкой входа */\
			else if(txt=="dev"){t=document.documentElement.lang;top.location="/"+(document.documentElement.dataset.lang==t?"":t+"/")+"admin"}	/* разработчику открыть админку */\
			else{document.location.reload(true)}'		//перегрузить с очисткой кэша
		],
		document.querySelector('.login')	//блок авторизации в шапке
	);
	return false
}
function headerDiv(){
	var e=g("headerDiv");
	if(e){
		ajx(
			0,"headerDiv","&store=",e
			//,"if(txt[0]==' '){headerInfo()}"	//инфо для авторизованного посетителя
		)
	};
}

window.addEventListener("load",headerDiv,false);

window.addEventListener("scroll",function(){
	var e=e=g("arrowUp");if(!e){return}
	e.className=window.scrollY>100?"a":"";
},false);

window.addEventListener("load",function(){	//управлять фиксацией шапки свайпом вверх-вниз (нажать — переместить курсор — отпустить)
	var e=document.querySelector("header");
	if(!e){return}
	var s=sessionStorage.getItem("headerFix");
	if(s===null || s=="1"){e.className="fix";}	//fix по умолчанию или если указано
	e.style.cursor="row-resize";
	e.addEventListener("mousedown",function(){
		this.dataset.y=event.clientY
	});
	e.addEventListener("mouseup",function(){
		var y=event.clientY-this.dataset.y;
		if(Math.abs(y)>2){
			this.className=(y>0?'fix':'');
			sessionStorage.setItem('headerFix',(y>0?'1':'0'));
		}
	});
	e.addEventListener("touchstart",function(){
		this.dataset.y=event.touches[0].clientY
	});
	e.addEventListener("touchmove",function(){
		var y=event.touches[0].clientY-this.dataset.y;
		if(Math.abs(y)>2){
			this.className=(y>0?'fix':'');
			sessionStorage.setItem('headerFix',(y>0?'1':'0'));
		}
	});
});