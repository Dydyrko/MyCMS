'use strict';
function catEditSubmit(a){
	var elements=a.elements,e=elements['text'];
	if(typeof(CKEDITOR)!='undefined' && CKEDITOR.instances && CKEDITOR.instances.text){e.value=CKEDITOR.instances.text.getData()}
	ajxDisabled(e);

	e=elements['adt'];
	if(typeof(CKEDITOR)!='undefined' && CKEDITOR.instances && CKEDITOR.instances.adt){e.value=CKEDITOR.instances.adt.getData()}
	ajxDisabled(e);

	e=elements['name'];ajxDisabled(e);
	e=elements['note'];ajxDisabled(e);
	e=elements['url'];ajxDisabled(e);

	e=elements['meta'];
	e.dataset.i=e.value.hashCode();	//до изменения
	if(
		elements['meta1'].value || elements['meta2'].value || elements['meta3'].value || elements['meta4'].value
	){
		e.value=elements['meta1'].value.replace(/\n/g,' ')
		+'\n'+elements['meta2'].value.replace(/\n/g,' ')
		+'\n'+elements['meta3'].value.replace(/\n/g,' ')
		+'\n'+elements['meta4'].value.replace(/\n/g,' ')
	}else{e.value=''}
	ajxDisabled(e);
	elements['meta1'].disabled=true;
	elements['meta2'].disabled=true;
	elements['meta3'].disabled=true;
	elements['meta4'].disabled=true;

	if(elements['update']==2){	//если есть запись в таблице url, то при пустых полях удалить запись
		elements['update'].value=(
			elements['text'].value==''
			&& elements['url'].value==''
			&& elements['meta'].value==''
			?1:''	//если 1, то удалить запись из таблицы url
		);
	}

	a.lastChild.innerHTML='<img class=ajxT src="/i/t.gif">';
	return ajxFormData(event,a,
		'var e=form.elements,i;\
		for(i in e){\
			if(e[i].dataset && typeof(e[i].dataset.i)!="undefined"){\
				e[i].dataset.i=e[i].value.hashCode()\
			}\
		}',a.lastChild
	)
}

function adminDiv(evt,a){	//управление шириной блока навигации
	var n=parseInt(100*evt.clientX/a.offsetWidth);
	var e=a.nextSibling;e.style.width=n+"%"
}

function ajxBtns(evt,txt,div,p){	//callback при отображении списка страниц аяксом: кнопки "обновить" и "скрыть"
	var m=document.createElement('DIV');
	m.className="noselect";
	m.style="position:absolute;top:0;right:5px";
	m.innerHTML='<a onclick="var e=parentNode.parentNode,p=e.parentNode;ajx(event,\'core_cat\',p.getAttribute(\'data-id\')+\'&order=\'+p.querySelector(\'dl.cat\').getAttribute(\'data-ord\'),e,[ajxBtns,catOrdEvt],1)" class="refresh" title="Refresh"></a>'
	+'<a onclick="parentNode.parentNode.style.display=\'none\'" style="margin-left:15px" title="Hide">&times</a>';
	div.innerHTML=txt;
	//console.log(div);
	var t=div.appendChild(m);
	//console.log(t.parentNode,t);
	//console.log(m);
}

function catOrdEvt(ev,txt,div){	//для передачи аргументом в ajx(): ev и txt для порядка, хоть не используются
	if(div && div.dataset && div.dataset.next){
		div=div.parentNode;
	}
	var e=div.querySelectorAll('input.ord'),i;
	for(i in e){
		if(!e[i].tagName){continue}	//функции…		
		e[i].addEventListener(
			'input',
			function (evt){
				this.focus();	//для нажатий на стрелки (type=number)
				this.style.backgroundColor=(this.value==this.dataset.v?'':'yellow')
			}
		);
		e[i].addEventListener(
			'blur',
			function (evt){
				ajx(evt,'core_cat',this.parentNode.dataset.id+'&ord='+this.value,this,['if(txt){div=0}else{div.dataset.v=div.value;div.style.backgroundColor=""}'])
			}
		);
	}
}

window.addEventListener("load",function(){
	catOrdEvt(0,0,document);	//для корневых страниц
	document.body.addEventListener(
		'click',
		function (evt){
			var m=evt.target;
			//console.log(m);
			if(m.className=='sym'){m=m.parentNode}	//символ
			if(m.tagName=='svg'){
				m=m.parentNode
			}else if(m.tagName=='use'){
				m=m.parentNode.parentNode
			}
			var p=m.parentNode;
			if(!p){return}
			var n=p.className,e=g('content');
			if(n=='cat'){	//шапка
				if(m.className=='add sym'){
					ajx(evt,'core_catAdd','0&t=Root',e)
				}else if(m.className=='exit sym'){
					ajx(evt,'core_login','unset&all=',0,'document.location.replace("/"+(document.documentElement.lang==document.documentElement.dataset.lang?"":document.documentElement.lang+"/"))')
				}else if(m.className=='editMode sym'){
					p=m.previousSibling;p.checked=!p.checked;
					ajx(evt,'core_editMode',p.checked)
				}else if(m.className=='debug'){
					p=m.previousSibling;p.checked=!p.checked;
					ajx(evt,'core_editMode',p.checked+'&debug=')
				}else if(m.className=='testFiles sym'){
					ajx(evt,'core_testFiles',0,e)
				}else if(m.className=='dblog'){
					ajx(evt,'core_dblog',0,e)
				}else if(m.className=='db'){
					ajx(evt,'core_dblog','db',e)
				}else if(m.className=='errdb'){
					ajx(evt,'core_dblog','db&err=',e)
				}else if(m.className=='log'){
					ajx(evt,'log',0,e)
				}else if(m.className=='mailLog sym'){
					ajx(evt,'log','mail',e)
				}else if(m.className=='sitemap sym'){
					ajx(evt,'core_sitemap1',0,e)	//,['txt="<plaintext>"+txt'])
				}else if(m.className=='refresh'){
					ajx(evt,'core_cat1',0,p.parentNode.lastChild,catOrdEvt)
				}
			}else{	//cat1.php p=<dt>
				n=p.parentNode;if(!n){return}
				n=n.className;
				if(n=='cat' && p.hasAttribute('data-id')){
					var id=p.getAttribute('data-id');
					if(m.className=='catEdit'){
						ajx(
							evt,'core_catEdit',id,e,
							'div.style.marginTop=(div.hasAttribute("data-i")?evt.target.parentNode.offsetTop:ScrollTop())+"px"'
						)
					}else if(m.className=='cat' && m.nodeName=='A'){
						e=m.parentNode.lastChild;
						ajxTo(m,e,function(){ajx(evt,'core_cat',id,e,[ajxBtns,catOrdEvt],2)} )
					}else if(m.className=='files'){
							ajx(
								evt,'core_files',
								id+'&t='+m.previousSibling.innerText,
								e,
								'div.style.marginTop=ScrollTop()+"px"'
							)
					}else if(m.className=='catAdd'){
							ajx(
								evt,'core_catAdd',
								id+'&t='+m.previousSibling.previousSibling.innerText,
								e,
								'div.style.marginTop=ScrollTop()+"px"'
							)
					}else if(m.className=='catDel'){
						if(document.documentElement.lang=='ru'){
							var L=['Удалить страницу','В том числе вложенные страницы (если их больше тысячи, то прежде удалите их!)','файлы и связи с др.таблицами'];
						}else if(document.documentElement.lang=='uk'){
							var L=['Видалити сторінку','У тому числі вкладені сторінки (якщо їх більше тисячі, то спочатку видаліть їх!)','файли та зв\'язки з ін.таблицями'];
						}else{
							var L=['Delete page','Including subpages (if there are more than a thousand of them, then delete them first!)','files and links to other tables'];
						}
						n=p.querySelector('a.catEdit').innerText;
						if(confirm(L[0]+' «'+n+'»?\n'+L[1]+',\n'+L[2])){
							ajx(evt,'core_catDel',id,m.parentNode,['if(txt[0]=="<"){div.parentNode.removeChild(div)};div=0']
							,3
							)
						}
					}else if(m.className=='v'){
						n=m.previousSibling;n.checked=!n.checked;
						m.parentNode.style.backgroundColor='yellow';
						ajx(evt,'core_cat',id+'&v='+n.checked,m
							,[
								'if(txt[0]=="<" /* HTML */ ){window.ajxPointer=div;div=0}else{div.parentNode.style.backgroundColor="";div.title=txt;div=0;txt=""}',''
							]
							,3
						)
					}
				}
			}
		}
	);
});

function trNext(evt,txt,div,p){	//дозагрузка строк таблицы. Применено в dblog.php
	var	A=txt.split("\n"),
		c=A.pop(),	//строк
		e=div.previousSibling, //<a>
		n=e.previousSibling,	//<table>
		m,i;
	for(i in A){
		m=document.createElement("TR");
		m.innerHTML=A[i];
		n.appendChild(m);
	}
	if(c){
		e.dataset.n=parseInt(e.dataset.n)+parseInt(c)
	}else{
		div.innerHTML=e.dataset.n;e.parentNode.removeChild(e)
	}
}

function divNext(evt,txt,div,p){	//дозагрузка DL.
	var	A=txt.split("\n"),
		c=A.pop(),	//строк
		e=div.previousSibling, //<a>
		n=e.previousSibling,	//<DL>
		m,i,by,B=[];
	//console.log(c);
	c=c.split("\t");
	by=c[1];c=c[0];
	if(c>0){
		B.push(n.innerHTML);
		B.push(A.join(""));
		n.innerHTML=B.join("");

		n.dataset.n=parseInt(n.dataset.n)+parseInt(c)
	}
	if(c<by){
		//console.log(n.dataset.n);
		div.innerHTML=n.dataset.n;e.parentNode.removeChild(e)
	}
}

function sqlTxt(a){
	a.parentNode.parentNode.parentNode.firstChild.value=a.textContent
}

function getTextarea(a,form,txt){
	var e=a.parentNode.lastChild;
	if(e.nodeName=='TEXTAREA' && !e.dataset.i){
		ajx(
			event,'core_catEdit',
			form.elements['core_catEdit'].value+'&getText='+txt+'&t='+(txt=='text'?'url':'cat'),			//запрос по id поля "text" таблицы "url"
			e,
			'div.style.display="block";'						//TEXTAREA
			+'var m=div.previousSibling.previousSibling;m.style.display="inline";'	//ссылка "полный экран"
			+'m.previousSibling.style.display="inline-block";'			//ссылка CKEditor
			+'div.focus()'
		)
	}
}

function CKEditor(a,txt){
		var ver=g('CKEdit');	//выбор версии в админке
		if(!ver){ver=4}else{ver=ver.value}
		var n=a.parentNode,e=n.lastChild;
		if(e.nodeName!='TEXTAREA'){					//выключаем CKEditor
			if(ver==4){
				var t=e.previousSibling;			//TEXTAREA
				t.value=CKEDITOR.instances[txt].getData();
				CKEDITOR.remove(txt);
				delete(window.CKEDITOR.instances[txt]);
			}
			e.parentNode.removeChild(e);				//удаляем блок CKEditor
			e=n.lastChild;
			e.style.display='block';				//TEXTAREA показываем
			e.style.visibility='';
			return
		}
		a.nextSibling.focus();	//для записи data-i
		if(ver==4){
			var js=g('ckEditor');	//тэг script
			if(!js){
				n=document.createElement('SCRIPT');
				n.id='ckEditor';
				n.src='https://cdn.ckeditor.com/4.10.0/standard/ckeditor.js';
				n.onload=function(){CKEditor4(txt)};
				document.head.appendChild(n);
			}else{
				CKEditor4(txt);
			}
		}else{
			var js=g('ckEditor5');	//тэг script
			if(!js){
				n=document.createElement('SCRIPT');
				n.id='ckEditor5';
				n.src='https://cdn.ckeditor.com/ckeditor5/25.0.0/classic/ckeditor.js';
				n.onload=function(){CKEditor5(e)};
				document.head.appendChild(n);
			}else{
				CKEditor5(e);
			}
		}
}

function CKEditor4(txt){
	if(window.CKEDITOR.instances[txt]){
		CKEDITOR.remove(txt);
		delete(window.CKEDITOR.instances[txt]);
	}
	CKEDITOR.replace(
		txt,
		{language: document.documentElement.lang,uiColor: '#bbbbbb'}
	);
}

function CKEditor5(e){
	ClassicEditor.create(
		e,{
			language:document.documentElement.lang
			//,extraPlugins:[MyUploadAdapterPlugin]	//https://ckeditor.com/docs/ckeditor5/latest/framework/guides/deep-dive/upload-adapter.html
		}
		).then(
			editor => {
				window.editor = editor;	      
				editor.model.document.on(
					'change:data',
					(evt,data) => {
						//console.log(data);
						e.value=editor.getData();
					}
				);
			}
		).catch(error => {
			console.error( 'There was a problem initializing the editor.', error );
		}
	);
}
/*
function MyUploadAdapterPlugin(editor){
	editor.plugins.get('FileRepository').createUploadAdapter = function(){
		//this._adapter
		console.log(editor);
	}
}
*/
