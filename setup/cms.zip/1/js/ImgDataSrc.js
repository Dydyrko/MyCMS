"use strict";
var ImgDataSrc;	/*Список img[data-src]*/
function setImgDataSrc(){ImgDataSrc=document.querySelectorAll("img[data-src]")}
function goImgDataSrc(z){	//z=обновить список картинок
	if(z || !ImgDataSrc || ImgDataSrc.length==0){setImgDataSrc()}
	var A=ImgDataSrc,i=0,R,b;
	for(i;i < A.length;i++){
		if(A[i].src!=""){continue}
		R=A[i].getBoundingClientRect();
		b=window.innerHeight-R.top;
		if(b>0){
			A[i].src=A[i].dataset.src;
			//A[i].removeAttribute("data-src");
			//console.log(b,ImgDataSrc[i])
		}
		//console.log(b,ImgDataSrc[i])
	}
}
window.addEventListener("scroll",goImgDataSrc,false);
document.addEventListener("DOMContentLoaded", goImgDataSrc);