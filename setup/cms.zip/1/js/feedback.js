'use strict';

function Feedback(a){
	var e=a.querySelector('.tel');
	if(e && e.className!='tel ok'){e.click();e.select();e.focus();return false}

	e=a.elements['mail'];
	if(e && e.value.indexOf('@')<1){e.click();e.select();e.focus();return false}

	ajxFormData(
		event,a,
		['if(txt[0]!=\' \'){div=0}else{var n=form.elements[\'captcha\'];n.parentNode.lastChild.onclick();n.select();n.focus()}'],
		a.lastChild
	);
	return false
}

function telMask(){
	var n=document.querySelectorAll('.feedback label'),i=0,e;
	for(var i=0;i<n.length;i++){
		e=n[i].firstChild;
		if(!e){console.log(n[i]);continue;}
		e.addEventListener("focus",function(){
				this.nextSibling.className='a';
				if(window.feedTimer){window.clearTimeout(window.feedTimer)} //может с задержкой устанавливаться автофокус на первое поле ввода: отменить это если посетитель уже нажал на любое поле
			}
		);
	}

	n = document.querySelectorAll('.feedback .tel');
	if(!n.length){return}
	for(i=0;i<n.length;i++){
		if(n[i].dataset.i){continue}			//пропустить уже инициализированные
		e=n[i];break
	}

	if(e){
		e.dataset.i=1;					//метка об инициализации
		if(e.autofocus){window.setTimeout(f,99)}	//установить фокус если <input autofocus>
	}else{return}

	var maskOptions = {
	  mask: '+{38\\0} (00) 000-00-00'			//Украина
		,lazy: false
	};

	var mask = new IMask(e, maskOptions);
	mask.on('complete', function () {
		e.className='tel ok';
		e.form.elements['tel'].value=mask.value.replace(/[\+\-\( \)]/g,'');;
		//console.log('complete',mask.value)
		}
	);
	mask.on('accept',function () {
		e.className='tel err';
		e.form.elements['tel'].value='';
		//console.log('accept',mask.value)
		}
	);

	var p=e.form.parentNode.querySelector('h2.p');
	if(p){
		e.click();
		var m=e.form.elements;
		m['mail'].parentNode.style.display='none';
		m=e.form.querySelector('.select');
		if(m){m.style.display='none';}
	}

	/*
	n=document.querySelectorAll('.feedback input[name="date"]');	//дата посещения от "сегодня"
	if(n){
		var d=FormatDate();					//f.js
		for(i=0;i<n.length;i++){n[i].min=d;}			//"datetime-local" пока нет в Firefox	d+"T12:00"
	}
	*/

	function f(){e.click();e.focus();}
}

function goTelMask(){
	jsAppend('imask',0,function(){window.setTimeout(telMask,99)});
}

if(document.readyState=="complete"){	//if ajx
	goTelMask()
}else{					//if HTML
	window.addEventListener("load",goTelMask)
}