'use strict';
var Lang={
	'dFormat':function(y,m,d){	//y=year | Y-m-d
			if(y.length==10){var A=y.split('-');y=A[0];m=A[1];d=A[2]}
			return parseInt(d)+' '+Lang.M1[m-1]+' '+y
		}
	,'W':['Mon','Tue','Wed','Thu','Fri','Sat','Sun']
	,'M':['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
	,'M1':['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
	,'M2':['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
	,'calendarExtend':'Extend year interval'
	,'applyFilter':'Apply filter'
	,'searchEmpty':'Text search result is empty'
}