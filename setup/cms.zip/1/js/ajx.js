'use strict';

	//document.cookie='screen=['+window.screen.width+','+window.screen.height+'];path=/;expires=Fri, 31 Dec 9999 23:59:59 GMT;SameSite=Strict;';

function g(a){return document.getElementById(a)}

function post(url,f,params,type,method,progressBar,Header){	//Header=[["Cache-Control","no-cache"],[…]]
	var d1=Date.now();					//пример: function f(text,status,XML){alert(text+"\n"+status+"\n"+XML)}
	if(!method){method="POST"}
	if(method=="GET"){url+="=&"+params}
	if(!type || type!='formData'){
		type=(type=="xml"?"text/plain;charset=UTF-8":"application/x-www-form-urlencoded");	//text/xml;charset=UTF-8
	}
	if(!progressBar){progressBar=document.querySelector("PROGRESS")}
	var xmlHttp = false;
	if(window.ActiveXObject){
		xmlHttp=new ActiveXObject("Microsoft.XMLHTTP")
	}else if(window.XMLHttpRequest){
		xmlHttp=new XMLHttpRequest()
	}
	xmlHttp.open(method,url,true);
	if(type!='formData'){xmlHttp.setRequestHeader("Content-type", type);}
	if(Header){
		for(var i=0;i<Header.length;i++){
			xmlHttp.setRequestHeader(Header[i][0],Header[i][1]);
		}
	}
	xmlHttp.timeout = 59000;	//ms
	xmlHttp.ontimeout = function(e){
		notify('timeout='+(xmlHttp.timeout/1000)+'s',JSON.stringify(Object.fromEntries(params)));
		console.log(e,"timeout =",xmlHttp.timeout);
		xmlHttp.abort();
		progressBar.value=0;
		f('');
	};

	//progressBar.addEventListener('click',function(){
	//	if(confirm('Request abort?')){xmlHttp.abort();progressBar.value=0;}
	//});

	xmlHttp.onreadystatechange = function(){
		if(xmlHttp.readyState == 4 && xmlHttp.status > 99){
			f(xmlHttp.responseText,xmlHttp.status,xmlHttp.responseXML);
			if(progressBar && progressBar.tagName=="PROGRESS"){
				progressBar.value=0;
				//progressBar.title=progressBar.textContent="";
			}
			var d=Date.now();console.log(d-d1,'ms',params);
		}else if(progressBar && progressBar.tagName=="PROGRESS"){
			progressBar.value=xmlHttp.readyState*1/4;
			//progressBar.title=progressBar.textContent=parseInt(progressBar.value*100)+"%";
		}
	};
	if(progressBar && progressBar.tagName=="PROGRESS" && xmlHttp.upload){
		xmlHttp.upload.onprogress = function (e) {
			var v=e.loaded/e.total;
			progressBar.value = v;
			//progressBar.title=progressBar.textContent=parseInt(v*100)+"%";
		}
	};
	if(xmlHttp.onload){
		xmlHttp.onload=function(e){var d2=Date.now();console.log((d2-d1)+' ms, bytes =',e.loaded,params)};
	}
	xmlHttp.send(params);
	return xmlHttp
}

function ajx(
	evt,
	p,	//имя в массиве POST
	data,	//текст, передаваемый на сервер в поле POST с именем p: «"123&t="+encodeURIComponent(t)»
	div,	//блок: куда помещать ответ сервера (txt) или/и используемый в js
	js,	//скрипт действия типа "alert(txt);div=div.parentNode" или функция типа function f(evt,txt,div,p){div.checked=(txt==1)}
		//или массив, где первый элемент — функция или скрипт для выполнения до помещения txt в div, второй — после.
		//Можно div сохранить в p и обнулить…
	b,	//b=1: ответ сервера не помещать в div, b=2: помещать в div GIF (или SVG) ожидания. b=3: ответ помещать, но не помещать картинку ожидания
	title	//заголовок текста ответа
	,modal,method
	){
	if(!method){method="POST"};
	function f(txt){
		var p;	//pointer
		if(typeof(T)!="undefined"){clearTimeout(T)}	//если не показали GIF ожидания, то уже он и не нужен
		if(js && typeof(js)=='object'){	//js массив из кода для выполнения до помещения txt в div, и кода для выполнения после
			var A=js;
			if(typeof(A[0])=="function"){A[0](evt,txt,div,p)}else{eval(A[0])}
			js=A[1]
		}
		if(!b || b==3){
			if(div && typeof(div)=="object"){
				if(div.tagName=="TEXTAREA"){div.value=txt}else{div.innerHTML=txt}	//чтобы в TEXTAREA вставлять и TEXTAREA
			}else if(txt!=''){
				div=showDiv(
					(title?"<h2>"+title+"</h2>":"")+txt+"<a class=close>&times;</a>",0,modal
				);
			}
		}
		if(js){
			if(typeof(js)=="function"){js(evt,txt,div,p)}else{eval(js)}
		}
	};
	function t(){div.innerHTML="<img class=ajxT src=/i/t.gif>"};	//картинка "ждите" (стиль ajx.css)
	if(div && !b || b==2){var T=window.setTimeout(t,100)}		//с задержкой: не мелькать при быстром ответе
	var lang=document.documentElement.lang,s=(lang?"/"+lang:"")+"/?ajx";
	post(s,f,p+"="+data,0,method,document.querySelector("progress"));
	return false
}

function ajxFormData(evt,form,js,div,b){	//event,форма,скрипт, функция или массив до [и после] вставки txt,куда txt, b=ответ сервера не отображать
	var formData = new FormData(form);
	var lang=document.documentElement.lang,s=(lang?"/"+lang:"")+"/?ajx";
	if(!b){			//нет запрета отображения ответа
		if(div){	//ответ поместить в указанный блок
			div.innerHTML="<img class=ajxT src=/i/t.gif>"
		}else{		//или поместить в форму
			form.innerHTML="<img class=ajxT src=/i/t.gif>"
		}
	}
	function f(txt){
		if(js && typeof(js)=='object'){	//js массив из кода для выполнения до помещения txt в div, и кода для выполнения после
			var A=js;
			if(typeof(A[0])=="function"){A[0](evt,txt,form,div)}else{eval(A[0])}
			js=A[1]		//undefined при отсутствии второго элемента массива
		}
		if(!b){			//нет запрета отображения ответа
			if(div){	//ответ поместить в указанный блок
				div.innerHTML=txt
			}else{		//или поместить в форму
				form.innerHTML=txt
			}
		}
		if(js){		//выполнить js-код или функцию
			if(typeof(js)=="function"){js(evt,txt,form,div)}else{eval(js)}
		}
		var e=form.parentNode;	//если результат в окно "ajxAlert", то центрировать
		if(e && e.parentNode.className && e.parentNode.className=="ajxAlert"){
			var t=(window.innerWidth-e.offsetWidth)/2;
			e.style.width=e.offsetWidth+"px";	//aside
			if(t<0){t=1}
			e.style.left=t+"px";

			var t=(window.innerHeight-e.offsetHeight)/2+window.scrollTop;
			//e.style.height=e.offsetHeight+"px";
			if(t<0){t=1}
			e.style.top=t+"px";

		}
	}
	post(s,f,formData,'formData','POST');
	return false;
};

function showDiv(txt,a,modal,instead){	//txt=блок как в ajx() и showImg(), при закрытии установить фокус на a, закрыть только кнопкой, вместо существующего ".ajxAlert"
	var e=document.querySelector(".ajxAlert"),m,n;
	if(e && instead ){
		m=e.firstChild;n=e.lastChild;
	}else{
		e=document.createElement("DIV");	//ajxAlert
		m=document.createElement("DIV");	//bg
		n=document.createElement("aside");	//CENTER
		document.body.appendChild(e);
		e.appendChild(m);
		e.appendChild(n);
		e.className="ajxAlert";
		//document.body.style.overflow="hidden";	//при touch не прокручивать страницу
	}
	function r(){
		if(e && e.parentNode){e.parentNode.removeChild(e)};
		document.body.removeEventListener('keydown',keydown);
		if(a){a.focus()}
	}
	function f(){e.style.top="-999px";e.style.left="-999px";e.style.opacity=0;window.setTimeout(r,500);document.body.style.overflow="auto";}
	function op(){
		var t=(document.documentElement.clientHeight-n.offsetHeight)/2;
		if(t<10){t=10}
		var top=document.documentElement.scrollTop || document.body.scrollTop,
		left=document.documentElement.scrollLeft || document.body.scrollLeft;
		n.style.top=(top+t)+"px";
		t=(document.documentElement.clientWidth-n.offsetWidth)/2+left;
		if(t<5){t=5;n.style.right=t+"px";}else{n.style.right=""}
		n.style.left=t+"px";
		e.style.opacity=1;
	}

	window.addEventListener('resize', op);

	n.innerHTML=txt;
	window.setTimeout(op,99);	//плавное отображение, без задержки не работает (хоть 0) 
	if(!modal){e.addEventListener('click',f);}	//закрывать при нажатии на маску

	function sP(evt){evt.stopPropagation()}	
	n.addEventListener('click',sP);

	//if(n.lastChild){n.lastChild.addEventListener('click',f);}	//и на крестик
	//if(txt.indexOf('<h2')<0){n.lastChild.className='close'}
	m=n.querySelectorAll('.close');
	for(var i=0;i<m.length;i++){m[i].addEventListener('click',f);}

	function keydown(evt){if(evt.keyCode==27){f()}}	//и на клавишу [Esc]
	document.body.addEventListener('keydown',keydown);
	return n
}