'use strict';
function regTest(evt,a){
	if(a.value.indexOf('@')<1){
		a.style.borderColor="red";
		return false
	}
	ajx(evt,"reg",
	a.value+"&test=",
	a.nextSibling,
	"var e=div.previousSibling;e.style.borderColor=(txt?'red':'green');regEnabled(e.form)"
	)
}
function regEnabled(form){
	var e=form.elements,n=e['chk'],A=[];
	if(e['mail'].style.borderColor!="green"){A[0]="Укажите корректный адрес почты";}
	if(e['psw'].value!='' && e['psw'].value != e['psw2'].value){A[1]="Пароли не совпадают";}
	n.parentNode.previousSibling.disabled=A.length || !n.checked;
	form.lastChild.innerHTML=A.length?A.join('<br>'):''
}

function validRegForm(form){
 var e=form.elements;
 if(e['mail'].value.indexOf('@')<1){e['mail'].focus();return false}
 if(e['psw'].value!='' && e['psw'].value != e['psw2'].value){e['psw2'].focus();return false}
 return true
}