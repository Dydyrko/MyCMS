'use strict';
function gMap1Initialize() {
	var gMap=document.getElementById("map_canvas"),A=gMap.dataset.pos.split(",");
	var myLatlng = new google.maps.LatLng(A[0],A[1]);
	var myOptions = {
		zoom: 10,
		center: myLatlng,
		mapTypeId: google.maps.MapTypeId.ROADMAP
	};
	var map = new google.maps.Map(gMap, myOptions);
	var marker = new google.maps.Marker(
		{
			position: myLatlng, 
			map: map,draggable:true,title:''
		}
	);
	google.maps.event.addListener(
		marker,
		'position_changed',
		function(){
			var v=marker.getPosition().toString();v=v.substr(1,v.length-2);
			gMap.dataset.pos=v;
			gMap.nextSibling.style.display="inline"
		}
	)
}  
function gMap1LoadScript() {
	var script = document.createElement("script");
	script.type = "text/javascript";
	script.src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCHW53XRV2F9B09ZXgjORf6qVvWNefjc7A&callback=gMap1Initialize&region=UA&language="+document.getElementById("map_canvas").dataset.lang;
	document.body.appendChild(script);
}	
gMap1LoadScript();