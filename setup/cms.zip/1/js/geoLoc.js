'use strict';
function geoLoc(){
	//console.log(navigator.geolocation);
	if(navigator.geolocation){
		window.geoLocation=sessionStorage.getItem("geoLocation");
		if(!window.geoLocation){
			navigator.geolocation.getCurrentPosition(function(position) {
				window.geoLocation=[position.coords.latitude, position.coords.longitude];
				sessionStorage.setItem("geoLocation",window.geoLocation);
				//console.log("geo=",window.geoLocation);
			});
		}
	}
}
geoLoc()