'use strict';
    var ru_str = ['а','б','в','г','д','е','ё','ж','з','и','й','к','л','м','н','о','п','р','с','т','у','ф','х','ц','ч','ш','щ','ъ','ы'
,'ь','э','ю','я', 'кс'
,'+','(',')','`','і','ї',',','є','ґ',
'"',"'",' ','?','.','$','%','/','\\','&',':','«','»'
,'­'	//#173
];

    var en_str = ['a','b','v','g','d','e','yo','j','z','i','j','k','l','m','n','o','p','r','s','t','u','f','h','c','ch','sh','sch','','y'
,'','e','yu','ya', 'x'
,'plus','','','','i','yi','','e','g',
'','','-','','','usd','procent','','','and','_','',''
,''
];

function translit(org_str) {
	var tmp_str = [];
	for (var i = 0, l = org_str.length; i < l; i++) {
		var s = org_str.charAt(i), n = ru_str.indexOf(s);
		//alert(s+'='+n);
		if(n >= 0) {
			tmp_str[tmp_str.length] = en_str[n];
		}else {
			tmp_str[tmp_str.length] = s;
		}
        }
        return encodeURIComponent(tmp_str.join(""));
}

	//translit("По улице")	//String.fromCharCode(35)