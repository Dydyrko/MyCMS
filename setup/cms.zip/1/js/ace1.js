'use strict';	//вариант редактирования textarea в ace. Применяется для редактирования файла CSS страницы
		//После загрузки "ace//ace.js" функция "ace0" загружает "ace//ext-language_tools.js" и выполняет "ace1"
function ace1(){
	var editor = ace.edit("aceEditor");
	ace.require("ace/ext/language_tools");

	var e=g("aceEditor");
	if(!e.dataset.t){e.dataset.t='html';}

	editor.getSession().setMode("ace/mode/"+e.dataset.t);
	editor.setOptions({
		enableBasicAutocompletion: true,
		enableSnippets: true,
		enableLiveAutocompletion: true
	});

	var n=document.createElement("DIV");
	n.style="position:absolute;z-index:1;top:0;right:0;left:0;height:25px;background-color:rgba(200,200,200,1)";

	n.innerHTML=
	`<input type=button value="Apply" style="margin-right:5px"
	 title="Apply to textarea — to save to file after closing editor"
	 onclick="
		var editor = ace.edit('aceEditor');
		var e=g('aceEditor'),A=[];
		if(e.dataset.a){A[0]=e.dataset.a}	//вернуть первую строку
		A.push(editor.getValue());
		if(e.dataset.b){A.push(e.dataset.b)}	//вернуть последнюю строку
		form.elements['text'].value=A.join('\\n');
		nextSibling.focus()
	"><input type=button value="&times;&nbsp;&nbsp;`+e.parentNode.elements["name"].value+`" title="Закрыть редактор"
	 onclick="var n=parentNode;n.parentNode.removeChild(n.previousSibling);n.parentNode.removeChild(n)" style=float:left>
	<select id="aceTheme" title="aceTheme" style=float:right>
		<option>crimson_editor
		<option>kuroir
		<option>terminal
	</select>`;

	e.parentNode.appendChild(n);
	e.parentNode.style.opacity=1;

	e=document.getElementById('aceTheme');
	e.addEventListener('change',function(){
		var editor=ace.edit('aceEditor');editor.setTheme("ace/theme/"+this.value);
		localStorage.setItem('aceTheme',this.value);
	});
	n=localStorage.getItem('aceTheme');
	if(!n){n='crimson_editor'}
	e.value=n;
	editor.setTheme("ace/theme/"+n);
}

function ace0(){
	jsAppend("aceExt",0,ace1,"js/ace/src-min-noconflict/ext-language_tools.js");
}

jsAppend("aceAPI",0,ace0,"js/ace/src-min-noconflict/ace.js");	//добавить в head скрипт id="jsaceAPI" если не было, выполнить "ace0()"
