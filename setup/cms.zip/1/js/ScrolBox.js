'use strict';

function ScrolBoxMM(a){	//onMouseMove
	if(a.dataset.x>0){
		var	e=a.parentNode,
			k=e.offsetWidth/e.scrollWidth,
			x=event.clientX-a.offsetLeft;
		e.scrollLeft-=event.clientX-a.offsetLeft-a.dataset.x;
		if(a.dataset.x-x){a.dataset.m=1}	//запретить onclick после сдвига
		a.dataset.x=x;
	}
}
function ScrolBoxTM(a){	//ontouchmove
	if(a.dataset.x>0){
		var	e=a.parentNode,
			k=e.offsetWidth/e.scrollWidth,
			x=event.changedTouches[0].clientX-a.offsetLeft;
		e.scrollLeft-=event.changedTouches[0].clientX-a.offsetLeft-a.dataset.x;
		if(a.dataset.x-x){a.dataset.m=1}	//запретить onclick после сдвига
		a.dataset.x=x;
	}
}
function ScrolBoxMD(a,touch){	//onMouseDown, ontouchstart: touch=1
	a.dataset.m=0;	//разрешить onclick
	var e=a.parentNode;
	if(e.offsetWidth<e.scrollWidth){
		if(event){a.dataset.x=(touch?event.changedTouches[0].clientX:event.clientX)-a.offsetLeft;}
		a.style.cursor='move';
		//console.log(a.style.cursor);
		a.parentNode.style.scrollBehavior="auto";
	}
}
function ScrolBoxMU(a){	//onMouseUp
	var	e=a.parentNode,				//контейнер
		w=a.lastChild.offsetWidth,		//ширина item
		margin=a.firstChild.nextSibling,	//первый item для определения отступа справа
		//n=parseInt(e.scrollWidth/w),			//количество item
		//n1=parseInt(e.offsetWidth/w+.5),			//видимых item
		x=a.dataset.x,
		m;		//номер первого видимого item
	margin=window.getComputedStyle(margin).getPropertyValue("margin-right");	//px
	margin=parseInt(margin);
	m=parseInt(e.scrollLeft/(w+margin)+.5);
	a.dataset.x=-1;
	a.dataset.m=0;
	a.style.cursor='';
	a.parentNode.style.scrollBehavior="smooth";
	//if(event.type=="mouseup"){console.log(e.scrollWidth-e.offsetWidth,e.scrollLeft,w+margin,m)}
	if(e.scrollWidth-e.offsetWidth>e.scrollLeft){
		e.scrollLeft=m*(w+margin);
	}
}

function showImg1(a,src){	//Слайдшоу <img src="" title="" onclick="showImg(this,src)">
	if(!src){src=a.src}
	var i=a.parentNode.parentNode.dataset.m;
	if(i!=undefined && i!=0){return}	//скролл
	document.body.style.overflow="hidden";
	var e=a.parentNode.parentNode,j=0;
	top.showImgA=[];
	if(e){
		e=e.getElementsByTagName("IMG");
		for(i=0;i<e.length;i++){
			if(e[i].dataset.file){
				top.showImgA.push(e[i]);
				if("/i/cat/"+e[i].dataset.file==src){j=top.showImgA.length-1}	//{j=i+1;}
			}
		}
	}
	i=top.showImgA.length;
	//console.log(top.showImgA,j);
	e=showDiv(
		"<div class=h onclick='event.stopPropagation()' data-i="+i+" data-j="+j+">"
			+"<a onclick='showImgNext(parentNode,-1)'"+(i>1 && j>0?"":" style=visibility:hidden")+">&larr;</a>"
			+"<a href="+src+" target=_blank title='"+(j*1+1)+"/"+i+"' style='white-space:nowrap'>"+top.showImgA[j].alt+"</a>"
			+"<a onclick='showImgNext(parentNode,1)'"+(i-1>j?"":" style=visibility:hidden")+">&rarr;</a>"
		+"</div>"
		+"<a class=close>&times;</a>"
		+"<div style='position:absolute;top:31px;left:0;right:0;bottom:0;background:#FFF url(/?img="
			+src+"&b=lightgray) no-repeat center /contain;cursor:zoom-in;border-radius: 0 0 15px 15px;'></div>"
	);

	e.lastChild.addEventListener("mousedown",md);
	e.lastChild.addEventListener("touchstart",md);

	e.lastChild.addEventListener("mouseup",mu);
	e.lastChild.addEventListener("touchend",mu);

	e.lastChild.addEventListener("mousemove",mm);
	e.lastChild.addEventListener("touchmove",mm);

	//e.style.transition="width 0s,left 0s,top 0s";
	e.style.padding=0;
	e.style.width="95%";
	e.style.height="calc(100% - 40px)";
	return false;

	function md(){	//mousedown
		e.dataset.b=1;
		e.dataset.moved=0;
		var p=e.lastChild;
		p.style.backgroundSize="auto";
		p.style.cursor="move";

		/*
		var img=new Image,k,w=0,h=0;
		img.src=e.firstChild.firstChild.nextSibling.href;
		var kx=img.width/e.offsetWidth;
		var ky=img.height/e.offsetHeight;
		if(ky>1 && ky>kx){
			k=ky;ky=1;kx=0;
		}else if(kx>1 && kx>ky){
			k=kx;kx=1;ky=0;
		}else{k=kx=ky=0;}
		if(ky){
			w=(e.offsetWidth-(e.offsetWidth/k))/2;	//поле слева от картинки
		}
		console.log(k,kx,ky,w);
		*/

		if(event.changedTouches){
			var x=event.changedTouches[0].clientX;
			var y=event.changedTouches[0].clientY;
		}else{var x=event.clientX;var y=event.clientY;}

		console.log(x-e.offsetLeft,y-e.offsetLeft-p.offsetTop);

		if(isNaN(e.lastChild.dataset.x)){
			p.dataset.x=0;
			p.dataset.y=0;
		}
		p.style.backgroundPosition=e.lastChild.dataset.x+"px "+e.lastChild.dataset.y+"px";
		p.dataset.x0=x;
		p.dataset.y0=y;
	}
	function mu(){	//mouseup
		e.dataset.b=0;
		if(e.dataset.moved==0){
			e.lastChild.style.backgroundSize="contain";
			e.lastChild.style.backgroundPosition="center";
			e.lastChild.style.cursor="zoom-in";
			e.dataset.x=e.dataset.y=0;
		}else{
			e.lastChild.dataset.x=parseInt(e.lastChild.style.backgroundPositionX);
			e.lastChild.dataset.y=parseInt(e.lastChild.style.backgroundPositionY);
		}
	}
	function mm(){	//mousemove
		if(e.dataset.b>0){
			if(event.changedTouches){
				var x=event.changedTouches[0].clientX;
				var y=event.changedTouches[0].clientY;
			}else{
				var x=event.clientX;
				var y=event.clientY;
			}
			//console.log(x,y,e.lastChild.dataset.x,e.lastChild.dataset.y);	//e.lastChild.dataset.y,y+1*e.lastChild.dataset.y+e.offsetTop+e.lastChild.offsetTop);
			if(!isNaN(e.lastChild.dataset.x)){
				x=parseInt(e.lastChild.dataset.x)+(x-e.lastChild.dataset.x0);
				y=parseInt(e.lastChild.dataset.y)+(y-e.lastChild.dataset.y0);
			}
			e.lastChild.style.backgroundPosition=x+"px "+y+"px";
			e.dataset.moved=1;
		}
	}
}
function showImgNext(a,b){
	a.dataset.j=a.dataset.j*1+b;
	a.firstChild.nextSibling.title=""+(a.dataset.j*1+1)+"/"+a.dataset.i;
	var e=a.firstChild;e.style.visibility=(a.dataset.j>0?"visible":"hidden");
	e=e.nextSibling;e.textContent=top.showImgA[a.dataset.j].alt;e.href="/i/cat/"+top.showImgA[a.dataset.j].dataset.file;
	e=e.nextSibling;e.style.visibility=(a.dataset.i-1>a.dataset.j?"visible":"hidden");
	var p=a.parentNode.lastChild,s=p.style;
	s.backgroundImage="url(/?img=/i/cat/"+top.showImgA[a.dataset.j].dataset.file+"&b=lightgray)";
	s.backgroundSize="contain";
	s.backgroundPosition="center";
	s.cursor="zoom-in";
	p.dataset.x=p.dataset.y=0;
}
