'use strict';

function ScrolBoxMM(evt,a){	//onMouseMove
	if(a.dataset.x>0){
		var	e=a.parentNode,
			k=e.offsetWidth/e.scrollWidth,
			x=evt.clientX-a.offsetLeft;
		e.scrollLeft-=evt.clientX-a.offsetLeft-a.dataset.x;
		if(a.dataset.x-x){a.dataset.m=1}	//запретить onclick после сдвига
		a.dataset.x=x;
		e=evt.target.parentNode;
		if(e.nodeName=="A"){e.onclick=function(){var b=(this.parentNode.parentNode.dataset.m!=1);return b}}
	}
}
function ScrolBoxTM(evt,a){	//ontouchmove
	if(a.dataset.x>0){
		var	e=a.parentNode,
			k=e.offsetWidth/e.scrollWidth,
			x=evt.changedTouches[0].clientX-a.offsetLeft;
		e.scrollLeft-=evt.changedTouches[0].clientX-a.offsetLeft-a.dataset.x;
		if(a.dataset.x-x){a.dataset.m=1}	//запретить onclick после сдвига
		a.dataset.x=x;
		e=evt.target.parentNode;
		if(e.nodeName=="A"){e.onclick=function(){var b=(this.parentNode.parentNode.dataset.m!=1);return b}}
	}
}
function ScrolBoxMD(evt,a,touch){	//onMouseDown, ontouchstart: touch=1
	a.dataset.m=0;	//разрешить onclick
	var	e=a.parentNode,
		//n=e.nextSibling.firstChild,
		k=e.offsetWidth/e.scrollWidth;
	if(k<1){
		if(evt){a.dataset.x=(touch?evt.changedTouches[0].clientX:evt.clientX)-a.offsetLeft;}
		a.style.cursor='move';
		console.log(a.style.cursor);
	}
}
function ScrolBoxMU(evt,a){	//onMouseUp
	var	e=a.parentNode,
		k=e.offsetWidth/e.scrollWidth;
	a.dataset.x=-1;
	a.style.cursor='pointer';
}

function showImg1(a,src){	//Слайдшоу <img src="" title="" onclick="showImg(this,src)">
	if(!src){src=a.src}

		var e=a.nextSibling,i=0,j=0;
		top.showImgA=[a];
		if(e){
			e=e.getElementsByTagName("IMG");
			for(i;i<e.length;i++){
				if(e[i].dataset.file){
					top.showImgA.push(e[i]);
					if("/i/cat/"+e[i].dataset.file==src){j=i+1;}
				}
			}
		}
		i=top.showImgA.length;
		console.log(top.showImgA);
		e=showDiv(
			"<div class=h title='Фотографий: "+i+"' onclick='event.stopPropagation()' data-i="+i+" data-j="+j+">"
				/*
				+(i>1 && j>1?"<a title='Предыдущее' onclick='showImgNext(parentNode,-1)' style='font-size:70%;white-space:nowrap'>"+top.showImgA[j-1].title+" &lt;</a> ":"")
				+"<a href="+src+" target=_blank title='Открыть в новом окне' style='white-space:nowrap'>"
				+top.showImgA[j].title
				+"</a>"
				+(i>1?" <small>("+(j)+" из "+(i-1)+")</small>":"")
				+(j<i-1?" <a title='Следующее' onclick='showImgNext(parentNode,1)' style='font-size:70%;white-space:nowrap'> &gt; "+top.showImgA[j+1].title+"</a>":"")
				*/

				+"<a onclick='showImgNext(parentNode,-1)'"+(i>1 && j>1?"":" style=visibility:hidden")+">&larr;</a>"
				+"<a href="+src+" target=_blank title='Открыть в новом окне' style='white-space:nowrap'>"+top.showImgA[j].title+"</a>"
				+"<a onclick='showImgNext(parentNode,1)'"+(i-1>j?"":" style=visibility:hidden")+">&rarr;</a>"
			+"</div>"
			+"<div style='position:absolute;top:40px;left:0;right:0;bottom:0;background:#FFF url("+(a.dataset.host?a.dataset.host:"")+src+") no-repeat center /contain;cursor:zoom-out'>"
			+"<a class=close style='margin-top:-40px'>&times;</a></div>"
		);

	e.style.transition="width 0s,left 0s,top 0s";
	e.style.padding=0;
	e.style.width="90%";
	e.style.height="90%";

	return false
}
function showImgNext(a,b){
	a.dataset.j=a.dataset.j*1+b;
	a.nextSibling.style.backgroundImage="url(/i/cat/"+top.showImgA[a.dataset.j].dataset.file+")";
	var e=a.firstChild;e.style.visibility=(a.dataset.j>1?"visible":"hidden");
	e=e.nextSibling;e.textContent=top.showImgA[a.dataset.j].title;e.href="/i/cat/"+top.showImgA[a.dataset.j].dataset.file;
	e=e.nextSibling;e.style.visibility=(a.dataset.i-1>a.dataset.j?"visible":"hidden");
}

function RmByClassH(a,Class){	//для showImg()
	if(!Class){Class="ajxAlert"}
	var e=a;while(e.className!=Class){e=e.parentNode}e.parentNode.removeChild(e)
}