<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

	if(isset($Parent) && !in_array(-100,$Parents)){	//не в корне и не в кабинете
		echo
		'<link rel="stylesheet" type="text/css" href="'.$host.'/css/crumbs.css">'
		.'<div class="crumbs">'
			.'<ul>'
				.'<li>'.implode('<li>',$Crumb)
	            	.'</ul>'
			.'<div style="clear:both"></div>'
		.'</div>';
	}else{
		echo '<div style=height:10px></div>';
	}

	echo
	'<div>'
		.'<h1>'
			//.'<a href=/'.sUrl($_GET['p']).' style="text-decoration:none">'
				.$catName
			//.'</a>'	//для SEO ссылка страницы на себя под вопросом, хоть полезна для обновления: может курсор такой показывать?
		.'</h1>';
		if(isset($_SESSION['editMode'])){echo '<!-- p.php -->';}	//для верстальщика
		echo '<div style=height:10px></div>';

		if($parent==-9 &&		//в разделе "Регистрация" персоны
			(
				isset($_SESSION['user']['id']) && $_SESSION['user']['id']==$_GET['p']	//авторизованная персона
				|| isset($editMode)							//или админ в режиме редактирования
			)
		){	//Персона в разделе "Регистрация"
			require $root.'/1/core/cabinet.php';return; //Кабинет, вернуться в public.php
		}else if($_GET['p']==-7){	//Поиск после нажатия на кнопку - вывод "быстрого поиска" на страницу
			require $root.'/1/pSearch.php';
		}

		//вложенные страницы
		if(!empty($cVis) && !in_array($_GET['p'],array(-9,-17))){	//есть видимые вложенные страницы и не регистрация, не корзина
			$q='select note from cat where id='.$_GET['p'];
			$row=DB::f(DB::q($q));
			if(!empty($row['note']) && $row['note'][0]=="\t"){	//первый символ - табуляция: параметры списка вложенных страниц
				$A=explode("\n",$row['note']);
				$LstParam=array();
				foreach($A as $i=>$v){
					$B=explode("\t",$v);
					if($B[0]==''){continue;}
					$B[1]=trim($B[1]);
					$LstParam[$B[0]]=$B[1];
				}
				//var_dump($LstParam);
			}
		
			if(!empty($LstParam['underText'])){		//не указано, что список вложенных страниц под текстом
				echo '<div>';
					require $root.'/1/pText.php';
					echo pText($_GET['p']);
				echo '</div>';
			}

			echo '<div class=pubs data-id="'.$_GET['p'].'">';
				$_POST['pubs']=$_GET['p'];
				require $root.'/1/pubs.php';
			echo '</div>';
		}

	echo
	'</div>';


	if(!in_array($_GET['p'],array(
		3,	//Не каталог товаров (3),
		-14,	//не сравнение (-14),
		-15,	//не избранное (-15),
		-17	//не корзина
		))
	 && (!isset($topParent) || !in_array($topParent,array(3,-100)))	//не страницы "Каталога товаров" и не "внутренние страницы сайта"
	){						//фотогалерея, тэги, комментарии

		//if($catImg){echo '<img src="/?img=/i/cat/'.$catImg.'&h=40">';}

		if($owner){
			$q='select '.DB::qL('name').' from cat where id='.$owner;
			$row=DB::f(DB::q($q));
			echo '<span style="margin:1em 0;color:#aaa">Бренд: '.$row['name'].'</span>';
		}
		//echo '<span style="float:right;color:#aaa" title="Дата публикации: '.$catDate.'">'.D1($catDate,'',1).'</span>';

		echo '<div style="clear:both"></div>';

		require $root.'/1/photos.php';	//Фотогалерея
		$Photos=photos($_GET['p'],$catName,800,600);	//w,h
		if($Photos){echo '<div class=photos ondragstart="return false">'.$Photos.'</div>';}
	}

	if(empty($LstParam['underText'])){
		echo '<div>';
			require $root.'/1/pText.php';
			echo pText($_GET['p']);
		echo '</div>';
	}

pubNext();

	if(isset($_SESSION['editMode'])){	// Раздел в Инфо, Проекты
		require $root.'/1/pEdit.php';
	}



function pubNext($v='=1',$ord='ord'){	//для публикации: следующая или предыдущая по id ( или d, или name), $v='>0' если показывать и со статусом 2
		global $Page;	//$parent,$catDate,$catName;

		$q='select id,ord,'.DB::qL('name').' from cat where parent='.$Page['parent'].' and v'.$v;

		if($ord=='ord'){$q.=' and IF(ord='.$Page['ord'].',id < "'.$_GET['p'].'",ord < '.$Page['ord'].')';}
		if($ord=='id'){$q.=' and id < "'.$_GET['p'].'"';}
		if($ord=='d'){$q.=' and d < "'.$Page['d'].'"';}
		if($ord=='name'){$q.=' and name_'.$_SESSION['lang'].' > "'.$Page['name'].'"';}

		$q.=' order by ';
		if($ord=='ord'){$q.='ord desc,id desc';}
		if($ord=='id'){$q.='id desc';}
		if($ord=='d'){$q.='d desc';}
		if($ord=='name'){$q.='name';}

		$q.=' limit 0,1';
		$r=DB::q($q);
		if(DB::num_rows($r)){
			$row1=DB::f($r);$next=array($row1['id'],$row1['name']);
		}

		$q='select id,'.DB::qL('name').' from cat where parent='.$Page['parent'].' and v'.$v;

		if($ord=='ord'){$q.=' and IF(ord='.$Page['ord'].',id > "'.$_GET['p'].'",ord > '.$Page['ord'].')';}
		if($ord=='id'){$q.=' and id > "'.$_GET['p'].'"';}
		if($ord=='d'){$q.=' and d > "'.$Page['d'].'"';}
		if($ord=='name'){$q.=' and name_'.$_SESSION['lang'].' < "'.$Page['name'].'"';}

		$q.=' order by ';
		if($ord=='ord'){$q.='ord,id';}
		if($ord=='id'){$q.='id';}
		if($ord=='d'){$q.='d';}
		if($ord=='name'){$q.='name desc';}

		$q.=' limit 0,1';
		$r=DB::q($q);
		if(DB::num_rows($r)){
			$row1=DB::f($r);$pre=array($row1['id'],$row1['name']);
		}

		if(isset($pre) || isset($next)){
			echo
			'<style>
				.pubNext{text-align:center;border-top:solid 1px #ccc}
				.pubNext>a{display:inline-block}
				.pubNext>a:first-of-type{margin-right: 65px;}
				.pubNext>a:first-of-type:after{content:" <"}
				.pubNext>a:last-of-type:before{content:"> "}
				.pubNext>a:first-of-type:empty:after{content:""}
				.pubNext>a:last-of-type:empty:before{content:""}
			</style>'.
		        '<div class="pubNext">'
		            .(isset($next)?'<a href="/'.sUrl($next[0]).'" title="Previous">'.$next[1].'</a>':'<a></a>')
	
		            .(isset($pre)?'<a href="/'.sUrl($pre[0]).'" title="Next">'.$pre[1].'</a>':'<a></a>')
	
		        .'</div>';
		}
}