<?php	//cms
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

$now=date('Y-m-d H:i:s');

//header('Access-Control-Allow-Origin: *');
header('X-Frame-Options: SAMEORIGIN');	//разрешить открывать в iframe только на своём домене
header('X-UA-Compatible: IE=edge');

if(!empty($_GET['userLink']) && !empty($_GET['c'])){	//подтвержение email нажатием на ссылку в письме после регистрации
	require '1/userLink.php';			//script history.replaceState()
}

echo '<!DOCTYPE html><html data-id="'.$_GET['p'].'" data-lang='.$Langs[0].' lang="'.$lang.'">'	//js: document.documentElement.lang
.'<head>'
.'<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">'
.(empty($headerStr)?'':$headerStr)	//<meta name=robots content=none>, <link rel=canonical href=""> …;
;


$pTitle=isset($Page['name'])?$Page['name']:'';
if(empty($Page['meta'])){
	echo '<title>'.(empty($pTitle)?'':$pTitle.' — ').$Conf['TITLE'].'</title>';
}else{
	$B=explode("\n",$Page['meta']);
	echo '<meta name="description" content="'.$B[0].'">';
	$n=mb_strpos($B[0],'.',0,'UTF-8');if(!$n){$n=60;}
	echo '<meta name="abstract" content="'.mb_substr($B[0],0,$n,'UTF-8').'">';
	if(!empty($B[1])){echo '<meta name="keywords" content="'.$B[1].'">';}
	if(empty($B[2])){
		echo '<title>'.(empty($pTitle)?'':$pTitle.' — ').$Conf['TITLE'].'</title>';
	}else{
		echo '<title>'.$B[2].' — '.$Conf['TITLE'].'</title>';
	}
}

$file=$root.'/1/core/a/inHead.txt';
if(file_exists($file) && !isset($_GET['w3'])){readfile($file);}

echo
'<meta name="viewport" content="width=device-width, initial-scale=1" />'
.'<meta property="og:type" content="website" />'
.'<meta property="og:title" content="'.(empty($pTitle)?'':$pTitle.' — ').$Conf['TITLE'].'" />'

.'<meta property="og:image" content="'.(empty($catImg)?
	$host.'/i/cat/-30/logo.png'
	:$host.'/i/cat/'.$catImg).'" />'

.'<link type="image/png" rel="shortcut icon" href="'.$host.'/favicon.png" />'
//.'<link type="image/x-icon" rel="shortcut icon" href="'.$host.'/favicon.ico" />'
;

if(!empty($Conf['geoLoc']) && !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']=='on'){
	echo '<script src="/js/geoLoc.js"></script>';	//помещает геолокацию в sessionStorage, есть вероятность успеть выполнить для отображения города в товаре
}

$q='select s from r where r=-55 and b=0'	//подключение CSS страницы
	.' and a in (-30,-31,'			//header,footer
	.($_GET['p']?$_GET['p']:-8)		//-8 для home
	.') order by a desc, c';			//сначала header, c=очерёдность
$r=DB::q($q);
if(DB::num_rows($r)){
	while($row=DB::f($r)){
		echo '<link rel="stylesheet" type="text/css" href='.$host.'/css/'.$row['s'].'>';
	}
}
if(!empty($Page['parent'])){			//подключение CSS, указанных родительской страницей
	$q='select s from r where r=-55 and b=-1 and a='.$Page['parent'].' order by c';
	$r=DB::q($q);
	if(DB::num_rows($r)){
		while($row=DB::f($r)){
			echo '<link rel="stylesheet" type="text/css" href='.$host.'/css/'.$row['s'].'>';
		}
	}
}

//require '1/search.php';	//блок текстового поиска class=search
//$search=search();

$q='select id,'.DB::qL('adt').',note from cat where id in (-30,-31)';	//header, footer
$r=DB::q($q);
while($row=DB::f($r)){
	if($row['id']==-30){	//header
		if(count($Langs)>1){	//отобразить блок переключения языка
			require '1/langSwitch.php';
			$langSwitch=langSwitch();
			$headInfo=str_replace('{langSwitch}',$langSwitch,$row['adt']);
		}else{$headInfo=$row['adt'];}
	}else{
		$footerInfo=$row['adt'];	//footer
	}
}

echo
(empty($B[3])?'':$B[3])	//текст (CSS, JS…) из META
.'</head>'

.'<body>';
	$file=$root.'/1/core/a/inBody.txt';
	if(file_exists($file) && !isset($_GET['w3'])){readfile($file);}

	echo
	'<div style="position:relative;min-height:100%;">'
		.'<header>';
			require $root.'/1/header.php';
		echo
		'</header>'
		.'<main>';
			if($_GET['p']==0){
				require $root.'/1/home.php';
			}else{
				echo
				'<div class=container>';
					require $root.'/1/p.php';
				echo
				'</div>';
			}
		echo
		'</main>'
		.'<footer>';
			require $root.'/1/footer.php';
		echo
		'</footer>'
		.'<PROGRESS value=0></PROGRESS>'
	.'</div>';

	$q='select s from r where r=-56 and b=0'	//подключение JS страницы
		.' and a in ('
		.'-30,-31,'				//header,footer
		.($_GET['p']?$_GET['p']:-8)		//-8 для home
		.') order by c';			//c=очерёдность
	$r=DB::q($q);
	if(DB::num_rows($r)){
		while($row=DB::f($r)){
			echo '<script src="/js/'.$row['s'].'"></script>';
		}
	}
	if(!empty($Page['parent'])){
		$q='select s from r where r=-56 and b=-1 and a='.$Page['parent'].' order by c desc';		//подключение CSS, указанных родительской страницей
		$r=DB::q($q);
		if(DB::num_rows($r)){
			while($row=DB::f($r)){
				echo '<script src="/js/'.$row['s'].'"></script>';
			}
		}
	}
	if(isset($editMode)){echo '<script src="/js/editMode.js"></script>';}	//для editTools

	echo
	'<!--'
	//.print_r($_SESSION['client'],true)

	//.number_format((microtime(true)-$start)*1000,0,',','')
	.number_format((microtime(true)-MICRO_TIME_START)*1000,0,',','')

	.' ms, PHP memory_get_'
	.'--><!--'.memory_get_usage().' usage'
	.'--><!--'.memory_get_peak_usage().' peak_usage'
	.'--><!--'.memory_get_peak_usage(true).' peak_usage(true)'
	.' -->';

	echo '<script>
		if(typeof(console)!="undefined"){console.log(performance.now())}
	</script>'

.'</body></html>';

if($catUrlStart!=$catUrl){	//urlArr.php
	file_put_contents($catUrlFile,json_encode($catUrl,JSON_UNESCAPED_UNICODE));
}