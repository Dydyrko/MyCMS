<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

function pText($id){
	global $root,$host,$lang,$editMode,
	$noedit,$pageId,$catName;	//для editBar.php

	$q='select '.DB::qL('text').' from url where id='.$id;	//отображение описания
	$r=DB::q($q);
	if(DB::num_rows($r)){	//есть id в таблице url
		$row=DB::f($r);
		if(isset($editMode)){
			require $root.'/1/core/editBar.php';
		}
		return
		'<div class=pText'.(isset($editMode)?
			' onkeyup="if(event.keyCode==113){
			event.stopPropagation();event.preventDefault();
			previousSibling.querySelector(\'.Save\').onclick();
			return false}"'
			.' onkeydown="if(event.keyCode==113){
			event.stopPropagation();event.preventDefault();
			previousSibling.querySelector(\'.Save\').nextSibling.innerHTML=\'\';
			return false}"'
			:'').'>'
			.$row['text']
		.'</div>';
	}else{return false;}
}