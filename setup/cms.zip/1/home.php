<?php
if(empty($root)){require $_SERVER['DOCUMENT_ROOT'].'/1/core/404.php';};

if(isset($editMode)){
	$editBarId=-8;
	unset($editBarAdt);
	$editBarTitle="Home";
	$editBarPos='position:fixed;top:130px';
	require $root.'/1/core/editBar.php';
}
echo
'<div class=home'
	.(isset($_SESSION['editMode'])?
		' onkeyup="if(event.keyCode==113){
		event.stopPropagation();event.preventDefault();	
		previousSibling.querySelector(\'.Save\').onclick();
		return false}"'	
		.' onkeydown="if(event.keyCode==113){
		event.stopPropagation();event.preventDefault();
		previousSibling.querySelector(\'.Save\').nextSibling.innerHTML=\'\';
		return false}"'
		:''
	).'>'
	.$text
.'</div>';

if(isset($_SESSION['editMode'])){
	require $root.'/1/pEdit.php';
}
